import { useCallback, useEffect, useState } from "react";
import { api } from "./api/backend";
import type { Workspace, WorkspaceSummary } from "./types/workspace";
import { Badge, Button, EmptyState } from "./components/ui";
import { MonitorPreview } from "./components/MonitorPreview";
import { SaveDialog } from "./components/SaveDialog";
import { RestoreView } from "./components/RestoreView";
import { WorkspaceDetail } from "./components/WorkspaceDetail";
import { Settings } from "./components/Settings";
import "./styles/app.css";

export default function App() {
  const [items, setItems] = useState<WorkspaceSummary[]>([]);
  const [previews, setPreviews] = useState<Record<string, Workspace>>({});
  const [chromeConnected, setChromeConnected] = useState(false);

  const [showSave, setShowSave] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [restoring, setRestoring] = useState<WorkspaceSummary | null>(null);
  const [detailId, setDetailId] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    const list = await api.listWorkspaces();
    setItems(list);
    // Düzen önizlemeleri için tam çalışma alanlarını yükle (küçük dosyalar).
    const entries = await Promise.all(
      list.map(async (s) => [s.id, await api.getWorkspace(s.id)] as const)
    );
    setPreviews(Object.fromEntries(entries));
  }, []);

  useEffect(() => {
    refresh();
    const poll = () =>
      api.chromeStatus().then(setChromeConnected).catch(() => setChromeConnected(false));
    poll();
    const t = setInterval(poll, 3000);
    return () => clearInterval(t);
  }, [refresh]);

  function flash(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 3200);
  }

  async function onImport() {
    const id = await api.importWorkspace();
    if (id) {
      await refresh();
      flash("Çalışma alanı içe aktarıldı.");
    }
  }

  async function onExport(s: WorkspaceSummary) {
    const ok = await api.exportWorkspace(s.id, s.name);
    if (ok) flash(`“${s.name}” dışa aktarıldı.`);
  }

  async function onDelete(s: WorkspaceSummary) {
    if (!confirm(`“${s.name}” silinsin mi? Bu işlem geri alınamaz.`)) return;
    await api.deleteWorkspace(s.id);
    await refresh();
    flash("Çalışma alanı silindi.");
  }

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark" aria-hidden>
            ▚
          </span>
          <div>
            <h1>Workspace Buddy</h1>
            <p className="tagline">Düzeninizi kaydedin. Tek tıkla geri yükleyin.</p>
          </div>
        </div>
        <div className="topbar-actions">
          <span className="chrome-chip" title="Chrome yardımcı eklenti durumu">
            {chromeConnected ? (
              <Badge tone="good">Chrome bağlı</Badge>
            ) : (
              <Badge tone="warn">Chrome bağlı değil</Badge>
            )}
          </span>
          <Button onClick={() => setShowSettings(true)}>Ayarlar</Button>
          <Button variant="accent" onClick={() => setShowSave(true)}>
            Geçerli çalışma alanını kaydet
          </Button>
        </div>
      </header>

      <div className="toolbar">
        <Button onClick={onImport}>Yedeği içe aktar</Button>
      </div>

      <main className="content">
        {items.length === 0 ? (
          <EmptyState
            title="Henüz çalışma alanı yok"
            body="Uygulamalarınızı, pencerelerinizi ve tarayıcınızı istediğiniz gibi düzenleyin, ardından ilk çalışma alanınızı kaydedin."
            action={
              <Button variant="accent" onClick={() => setShowSave(true)}>
                Geçerli çalışma alanını kaydet
              </Button>
            }
          />
        ) : (
          <ul className="ws-grid">
            {items.map((s) => {
              const full = previews[s.id];
              return (
                <li key={s.id} className="ws-card">
                  <div className="ws-card-preview">
                    {full ? (
                      <MonitorPreview monitors={full.monitors} apps={full.apps} />
                    ) : (
                      <div className="mon-preview mon-preview-empty">…</div>
                    )}
                  </div>
                  <div className="ws-card-body">
                    <h3 className="ws-name">{s.name}</h3>
                    <p className="ws-sub">
                      {new Date(s.saved_at).toLocaleString("tr-TR")} ·{" "}
                      {s.monitor_count} monitör
                    </p>
                    <div className="ws-stats">
                      <span>{s.app_count} uygulama</span>
                      <span>{s.teams_count} Teams</span>
                      <span>
                        {s.chrome_window_count > 0
                          ? `${s.chrome_window_count} Chrome`
                          : "Chrome yok"}
                      </span>
                    </div>
                  </div>
                  <div className="ws-card-actions">
                    <Button variant="accent" onClick={() => setRestoring(s)}>
                      Geri yükle
                    </Button>
                    <Button onClick={() => setDetailId(s.id)}>Ayrıntılar</Button>
                    <div className="ws-card-more">
                      <Button onClick={() => onExport(s)} title="Dosyaya dışa aktar">
                        Dışa aktar
                      </Button>
                      <Button variant="danger" onClick={() => onDelete(s)}>
                        Sil
                      </Button>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </main>

      <SaveDialog
        open={showSave}
        onClose={() => setShowSave(false)}
        onSaved={() => {
          refresh();
          flash("Çalışma alanı kaydedildi.");
        }}
      />

      <Settings open={showSettings} onClose={() => setShowSettings(false)} />

      {restoring && (
        <RestoreView workspace={restoring} onClose={() => setRestoring(null)} />
      )}

      {detailId && (
        <WorkspaceDetail
          id={detailId}
          onClose={() => setDetailId(null)}
          onChanged={() => {
            refresh();
            flash("Değişiklikler kaydedildi.");
          }}
        />
      )}

      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}
