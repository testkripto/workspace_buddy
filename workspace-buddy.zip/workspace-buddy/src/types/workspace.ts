// Types mirror the Rust model in src-tauri/src/model.rs. Keep them in sync.

export type WindowState = "normal" | "maximized" | "minimized";

export interface MonitorInfo {
  number: number;
  /** GDI device name (\\.\DISPLAY1). Stable key for matching monitors. */
  device_id: string;
  is_primary: boolean;
  /** Effective DPI; 96 = 100% scaling. */
  dpi: number;
  x: number;
  y: number;
  width: number;
  height: number;
  work_x: number;
  work_y: number;
  work_width: number;
  work_height: number;
}

export interface WindowGeometry {
  title: string;
  class_name: string;
  /** Restored ("normal") rect in true screen coordinates. */
  x: number;
  y: number;
  width: number;
  height: number;
  monitor: number;
  monitor_device: string;
  state: WindowState;
  z_order: number;
}

export interface AppEntry {
  exe_path: string;
  process_name: string;
  windows: WindowGeometry[];
  skip_launch: boolean;
  /** Chrome: opened by the companion extension, positioned by the Win32 pass. */
  is_browser: boolean;
}

export interface TeamsLink {
  id: string;
  name: string;
  url: string;
}

export interface ChromeTab {
  url: string;
  title?: string | null;
  pinned: boolean;
  group_id: number;
  active: boolean;
  index: number;
}

export interface ChromeGroup {
  id: number;
  title?: string | null;
  color?: string | null;
  collapsed: boolean;
}

export interface ChromeProfile {
  client_id: string;
  label: string;
  incognito_allowed: boolean;
  window_count: number;
  incognito_window_count: number;
}

/** A Chrome profile currently talking to the bridge. */
export interface ChromeClientInfo {
  client_id: string;
  label: string;
  incognito_allowed: boolean;
}

export interface ChromeWindow {
  client_id: string;
  profile?: string | null;
  incognito: boolean;
  active_tab_title?: string | null;
  focused: boolean;
  left?: number | null;
  top?: number | null;
  width?: number | null;
  height?: number | null;
  state?: string | null;
  tabs: ChromeTab[];
  groups: ChromeGroup[];
}

export interface ChromeState {
  captured: boolean;
  incognito_allowed?: boolean;
  profiles: ChromeProfile[];
  windows: ChromeWindow[];
}

export interface RestoreOptions {
  launch_teams: boolean;
  open_teams_links: boolean;
  launch_apps: boolean;
  restore_chrome: boolean;
  restore_positions: boolean;
  teams_link_delay_ms: number;
  app_launch_delay_ms: number;
  window_wait_timeout_ms: number;
  position_settle_delay_ms: number;
  chrome_restore_timeout_ms: number;
  position_retries: number;
}

export interface Workspace {
  schema_version: number;
  name: string;
  saved_at: number;
  monitors: MonitorInfo[];
  apps: AppEntry[];
  teams: TeamsLink[];
  chrome: ChromeState;
  restore_options: RestoreOptions;
}

export interface WorkspaceSummary {
  id: string;
  name: string;
  saved_at: number;
  app_count: number;
  teams_count: number;
  chrome_window_count: number;
  chrome_tab_count: number;
  chrome_incognito_count: number;
  monitor_count: number;
  /** Saved before the screen-coordinate fix; geometry is only approximate. */
  legacy_geometry: boolean;
}

export interface RestoreProgress {
  phase:
    | "teams"
    | "teams-links"
    | "apps"
    | "chrome"
    | "positions"
    | "done"
    | "error"
    | "paused";
  message: string;
  fraction: number;
}

export const defaultRestoreOptions = (): RestoreOptions => ({
  launch_teams: true,
  open_teams_links: true,
  launch_apps: true,
  restore_chrome: true,
  restore_positions: true,
  teams_link_delay_ms: 1500,
  app_launch_delay_ms: 800,
  window_wait_timeout_ms: 15000,
  position_settle_delay_ms: 1500,
  chrome_restore_timeout_ms: 20000,
  position_retries: 3,
});
