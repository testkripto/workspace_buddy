// Types mirror the Rust model in src-tauri/src/model.rs. Keep them in sync.

export type WindowState = "normal" | "maximized" | "minimized";

export interface MonitorInfo {
  number: number;
  is_primary: boolean;
  x: number;
  y: number;
  width: number;
  height: number;
  work_x: number;
  work_y: number;
  work_width: number;
  work_height: number;
}

export interface WindowGeometry {
  title: string;
  x: number;
  y: number;
  width: number;
  height: number;
  monitor: number;
  state: WindowState;
}

export interface AppEntry {
  exe_path: string;
  process_name: string;
  windows: WindowGeometry[];
  skip_launch: boolean;
}

export interface TeamsLink {
  id: string;
  name: string;
  url: string;
}

export interface ChromeTab {
  url: string;
  title?: string | null;
  pinned: boolean;
  group_id: number;
  active: boolean;
}

export interface ChromeGroup {
  id: number;
  title?: string | null;
  color?: string | null;
  collapsed: boolean;
}

export interface ChromeWindow {
  profile?: string | null;
  incognito: boolean;
  focused: boolean;
  left?: number | null;
  top?: number | null;
  width?: number | null;
  height?: number | null;
  state?: string | null;
  tabs: ChromeTab[];
  groups: ChromeGroup[];
}

export interface ChromeState {
  captured: boolean;
  incognito_allowed?: boolean;
  windows: ChromeWindow[];
}

export interface RestoreOptions {
  launch_teams: boolean;
  open_teams_links: boolean;
  launch_apps: boolean;
  restore_chrome: boolean;
  restore_positions: boolean;
  teams_link_delay_ms: number;
  app_launch_delay_ms: number;
  window_wait_timeout_ms: number;
  position_settle_delay_ms: number;
}

export interface Workspace {
  schema_version: number;
  name: string;
  saved_at: number;
  monitors: MonitorInfo[];
  apps: AppEntry[];
  teams: TeamsLink[];
  chrome: ChromeState;
  restore_options: RestoreOptions;
}

export interface WorkspaceSummary {
  id: string;
  name: string;
  saved_at: number;
  app_count: number;
  teams_count: number;
  chrome_window_count: number;
  monitor_count: number;
}

export interface RestoreProgress {
  phase:
    | "teams"
    | "teams-links"
    | "apps"
    | "chrome"
    | "positions"
    | "done"
    | "error"
    | "paused";
  message: string;
  fraction: number;
}

export const defaultRestoreOptions = (): RestoreOptions => ({
  launch_teams: true,
  open_teams_links: true,
  launch_apps: true,
  restore_chrome: true,
  restore_positions: true,
  teams_link_delay_ms: 1500,
  app_launch_delay_ms: 800,
  window_wait_timeout_ms: 15000,
  position_settle_delay_ms: 1200,
});
