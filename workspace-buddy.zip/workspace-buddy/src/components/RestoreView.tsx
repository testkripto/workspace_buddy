import { useEffect, useRef, useState } from "react";
import { api } from "../api/backend";
import type { RestoreProgress, WorkspaceSummary } from "../types/workspace";
import { Button, Modal } from "./ui";

/**
 * Geri yükleme işlemini yürütür ve canlı ilerlemeyi gösterir. Arka uç Teams
 * oturum açma adımına geldiğinde `paused` aşamasını yayar; gerekli istem
 * ("Lütfen Teams'te oturum açın, ardından Devam'a tıklayın") gösterilir ve
 * yalnızca kullanıcı onayladıktan sonra devam edilir — uygulama Teams oturum
 * açma işlemini asla otomatikleştirmez veya atlatmaz.
 */
export function RestoreView({
  workspace,
  onClose,
}: {
  workspace: WorkspaceSummary;
  onClose: () => void;
}) {
  const [progress, setProgress] = useState<RestoreProgress>({
    phase: "apps",
    message: "Başlatılıyor…",
    fraction: 0,
  });
  const [paused, setPaused] = useState(false);
  const [done, setDone] = useState(false);
  const [log, setLog] = useState<string[]>([]);
  const unlisten = useRef<null | (() => void)>(null);

  useEffect(() => {
    let mounted = true;
    api
      .onRestoreProgress((p) => {
        if (!mounted) return;
        setProgress(p);
        setLog((l) => [...l, `${phaseLabel(p.phase)} — ${p.message}`].slice(-40));
        setPaused(p.phase === "paused");
        if (p.phase === "done") setDone(true);
      })
      .then((fn) => {
        unlisten.current = fn;
        // Olay kaybı olmaması için dinleyici bağlandıktan sonra başlat.
        api.startRestore(workspace.id).catch((e) =>
          setLog((l) => [...l, `Hata — ${String(e)}`])
        );
      });

    return () => {
      mounted = false;
      unlisten.current?.();
    };
  }, [workspace.id]);

  async function onContinue() {
    setPaused(false);
    await api.teamsContinue();
  }

  return (
    <Modal
      open
      title={`“${workspace.name}” geri yükleniyor`}
      onClose={done ? onClose : () => {}}
      wide
      footer={
        done ? (
          <Button variant="accent" onClick={onClose}>
            Bitti
          </Button>
        ) : (
          <span className="foot-note">
            Geri yükleme bitene kadar bu pencereyi açık tutun.
          </span>
        )
      }
    >
      {paused ? (
        <div className="teams-pause">
          <div className="teams-pause-icon" aria-hidden>
            👤
          </div>
          <h3>Lütfen Teams'te oturum açın, ardından Devam'a tıklayın</h3>
          <p>
            Teams başlatıldı. Her zamanki gibi oturum açın. Workspace Buddy
            kimlik bilgilerinize dokunmaz — oturumunuzu açtıktan sonra Devam'a
            tıklayın; kaydettiğiniz sohbetler ve kanallar açılacaktır.
          </p>
          <Button variant="accent" onClick={onContinue}>
            Devam
          </Button>
        </div>
      ) : (
        <>
          <div className="progress-track" aria-hidden>
            <div
              className={`progress-fill ${done ? "is-done" : ""}`}
              style={{ width: `${Math.round(progress.fraction * 100)}%` }}
            />
          </div>
          <p className="progress-current">
            <strong>{phaseLabel(progress.phase)}</strong> {progress.message}
          </p>
          <ol className="restore-log">
            {log.map((line, i) => (
              <li key={i}>{line}</li>
            ))}
          </ol>
        </>
      )}
    </Modal>
  );
}

function phaseLabel(phase: RestoreProgress["phase"]): string {
  switch (phase) {
    case "teams":
      return "Teams";
    case "teams-links":
      return "Teams bağlantıları";
    case "apps":
      return "Uygulamalar";
    case "chrome":
      return "Chrome";
    case "positions":
      return "Pencere düzeni";
    case "done":
      return "Tamamlandı";
    case "error":
      return "Uyarı";
    case "paused":
      return "Bekleniyor";
  }
}
