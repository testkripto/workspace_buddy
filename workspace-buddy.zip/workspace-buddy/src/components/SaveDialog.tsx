import { useEffect, useState } from "react";
import { api } from "../api/backend";
import type { ChromeClientInfo, TeamsLink } from "../types/workspace";
import { Button, Field, Modal } from "./ui";
import { TeamsLinksEditor } from "./TeamsLinksEditor";

/**
 * Geçerli masaüstünü yakalar. Teams bağlantıları şimdi ya da daha sonra
 * çalışma alanının ayrıntı görünümünden eklenebilir. Chrome yakalama isteğe
 * bağlıdır ve yardımcı eklentinin bağlı olmasına dayanır.
 */
export function SaveDialog({
  open,
  onClose,
  onSaved,
}: {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [name, setName] = useState("");
  const [teams, setTeams] = useState<TeamsLink[]>([]);
  const [captureChrome, setCaptureChrome] = useState(true);
  const [profiles, setProfiles] = useState<ChromeClientInfo[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    setName(defaultName());
    setTeams([]);
    setError(null);
    const poll = () =>
      api.chromeProfiles().then(setProfiles).catch(() => setProfiles([]));
    poll();
    const t = setInterval(poll, 2000);
    return () => clearInterval(t);
  }, [open]);

  const chromeConnected = profiles.length > 0;
  const noIncognito = profiles.filter((p) => !p.incognito_allowed);

  async function save() {
    if (name.trim() === "") return;
    setBusy(true);
    setError(null);
    try {
      await api.saveWorkspace(name.trim(), teams, captureChrome && chromeConnected);
      onSaved();
      onClose();
    } catch (e) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open={open}
      title="Geçerli çalışma alanını kaydet"
      onClose={onClose}
      wide
      footer={
        <>
          <Button onClick={onClose} disabled={busy}>
            İptal
          </Button>
          <Button variant="accent" onClick={save} disabled={busy || name.trim() === ""}>
            {busy ? "Yakalanıyor…" : "Çalışma alanını kaydet"}
          </Button>
        </>
      }
    >
      <Field label="Çalışma alanı adı">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Sabah Çalışması"
          autoFocus
        />
      </Field>

      <div className="save-toggle">
        <label className="switch-row">
          <input
            type="checkbox"
            checked={captureChrome && chromeConnected}
            disabled={!chromeConnected}
            onChange={(e) => setCaptureChrome(e.target.checked)}
          />
          <span>
            Chrome sekmelerini yakala
            <span className="switch-sub">
              {chromeConnected
                ? `${profiles.length} Chrome profili bağlı: ${profiles
                    .map((p, i) => p.label || `Profil ${i + 1}`)
                    .join(", ")}. Açık pencereler ve sekmeler yakalanacak.`
                : "Yardımcı eklenti bulunamadı. Sekmeleri yakalamak için eklentiyi yükleyip etkinleştirin."}
            </span>
          </span>
        </label>
      </div>

      {chromeConnected && noIncognito.length > 0 && (
        <p className="inline-warn">
          Şu profillerde gizli pencereler yakalanamayacak:{" "}
          <strong>
            {noIncognito.map((p, i) => p.label || `Profil ${i + 1}`).join(", ")}
          </strong>
          . Chrome, izin verilmeden gizli pencereleri eklentiye hiç bildirmez —
          bu bir Chrome güvenlik kuralıdır. İzin vermek için:{" "}
          <span className="mono">chrome://extensions</span> → Workspace Buddy
          Yardımcısı → Ayrıntılar → “Gizli modda izin ver”.
        </p>
      )}

      <div className="save-section">
        <h4>Teams bağlantıları (isteğe bağlı)</h4>
        <p className="section-note">
          Teams'te oturum açtıktan sonra yeniden açılmasını istediğiniz sohbet ve
          kanalların bağlantılarını ekleyin. Bunları daha sonra da
          yönetebilirsiniz.
        </p>
        <TeamsLinksEditor links={teams} onChange={setTeams} />
      </div>

      {error && <p className="inline-error">{error}</p>}
    </Modal>
  );
}

function defaultName(): string {
  const now = new Date();
  const hour = now.getHours();
  const part = hour < 12 ? "Sabah" : hour < 18 ? "Öğleden Sonra" : "Akşam";
  return `${part} Çalışması`;
}
