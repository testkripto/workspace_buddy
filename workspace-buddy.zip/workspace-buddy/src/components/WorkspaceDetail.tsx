import { useEffect, useState } from "react";
import { api } from "../api/backend";
import type { RestoreOptions, TeamsLink, Workspace } from "../types/workspace";
import { Button, Field, Modal } from "./ui";
import { MonitorPreview } from "./MonitorPreview";
import { TeamsLinksEditor } from "./TeamsLinksEditor";

/** Kayıtlı çalışma alanını görüntüle + düzenle: ad, Teams bağlantıları, zamanlama. */
export function WorkspaceDetail({
  id,
  onClose,
  onChanged,
}: {
  id: string;
  onClose: () => void;
  onChanged: () => void;
}) {
  const [ws, setWs] = useState<Workspace | null>(null);
  const [name, setName] = useState("");
  const [teams, setTeams] = useState<TeamsLink[]>([]);
  const [opts, setOpts] = useState<RestoreOptions | null>(null);
  const [tab, setTab] = useState<"apps" | "teams" | "options">("apps");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.getWorkspace(id).then((w) => {
      setWs(w);
      setName(w.name);
      setTeams(w.teams);
      setOpts(w.restore_options);
    });
  }, [id]);

  async function save() {
    if (!opts) return;
    setSaving(true);
    try {
      await api.updateWorkspaceMeta(id, { name, teams, restoreOptions: opts });
      onChanged();
      onClose();
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      open
      title="Çalışma alanı ayrıntıları"
      onClose={onClose}
      wide
      footer={
        <>
          <Button onClick={onClose}>İptal</Button>
          <Button variant="accent" onClick={save} disabled={saving}>
            {saving ? "Kaydediliyor…" : "Değişiklikleri kaydet"}
          </Button>
        </>
      }
    >
      {!ws || !opts ? (
        <p>Yükleniyor…</p>
      ) : (
        <>
          <Field label="Ad">
            <input value={name} onChange={(e) => setName(e.target.value)} />
          </Field>

          <div className="detail-preview">
            <MonitorPreview monitors={ws.monitors} apps={ws.apps} height={120} />
            <div className="detail-meta">
              <span>{ws.monitors.length} monitör</span>
              <span>{ws.apps.length} uygulama</span>
              <span>{ws.teams.length} Teams bağlantısı</span>
              <span>
                {ws.chrome.captured
                  ? `${ws.chrome.windows.length} Chrome penceresi`
                  : "Chrome verisi yok"}
              </span>
            </div>
          </div>

          <div className="tabs">
            <button
              className={tab === "apps" ? "tab is-active" : "tab"}
              onClick={() => setTab("apps")}
            >
              Uygulamalar
            </button>
            <button
              className={tab === "teams" ? "tab is-active" : "tab"}
              onClick={() => setTab("teams")}
            >
              Teams bağlantıları
            </button>
            <button
              className={tab === "options" ? "tab is-active" : "tab"}
              onClick={() => setTab("options")}
            >
              Geri yükleme zamanlaması
            </button>
          </div>

          {tab === "apps" && (
            <ul className="app-list">
              {ws.apps.map((a, i) => (
                <li key={i}>
                  <div className="app-list-main">
                    <span className="app-name">{a.process_name}</span>
                    <span className="app-path mono">{a.exe_path}</span>
                  </div>
                  <div className="app-windows">
                    {a.windows.map((w, j) => (
                      <span key={j} className="app-window-chip">
                        M{w.monitor} · {w.width}×{w.height} · {w.state}
                      </span>
                    ))}
                  </div>
                </li>
              ))}
              {ws.apps.length === 0 && <li className="muted">Yakalanan uygulama yok.</li>}
            </ul>
          )}

          {tab === "teams" && <TeamsLinksEditor links={teams} onChange={setTeams} />}

          {tab === "options" && (
            <RestoreOptionsForm opts={opts} onChange={setOpts} />
          )}
        </>
      )}
    </Modal>
  );
}

function RestoreOptionsForm({
  opts,
  onChange,
}: {
  opts: RestoreOptions;
  onChange: (o: RestoreOptions) => void;
}) {
  const set = <K extends keyof RestoreOptions>(key: K, value: RestoreOptions[K]) =>
    onChange({ ...opts, [key]: value });

  const toggles: [keyof RestoreOptions, string][] = [
    ["launch_teams", "Teams'i başlat"],
    ["open_teams_links", "Oturum açıldıktan sonra Teams bağlantılarını aç"],
    ["launch_apps", "Uygulamaları başlat"],
    ["restore_chrome", "Chrome sekmelerini geri yükle"],
    ["restore_positions", "Pencere konumlarını geri yükle"],
  ];
  const delays: [keyof RestoreOptions, string, string][] = [
    ["teams_link_delay_ms", "Teams bağlantıları açılmadan önceki gecikme", "Devam'a tıkladıktan sonra"],
    ["app_launch_delay_ms", "Uygulamalar arası başlatma gecikmesi", "her uygulamaya açılma süresi tanır"],
    ["window_wait_timeout_ms", "Pencerenin görünmesi için en fazla bekleme", "devam etmeden önce"],
    ["position_settle_delay_ms", "Konumlandırmadan önce yerleşme gecikmesi", "pencerelerin yüklenmesini tamamlar"],
  ];

  return (
    <div className="options-form">
      <div className="options-toggles">
        {toggles.map(([key, label]) => (
          <label key={key} className="switch-row">
            <input
              type="checkbox"
              checked={opts[key] as boolean}
              onChange={(e) => set(key, e.target.checked as never)}
            />
            <span>{label}</span>
          </label>
        ))}
      </div>
      <div className="options-delays">
        {delays.map(([key, label, hint]) => (
          <Field key={key} label={label} hint={hint}>
            <div className="ms-input">
              <input
                type="number"
                min={0}
                step={100}
                value={opts[key] as number}
                onChange={(e) => set(key, Number(e.target.value) as never)}
              />
              <span className="ms-suffix">ms</span>
            </div>
          </Field>
        ))}
      </div>
    </div>
  );
}
