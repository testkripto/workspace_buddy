import { useEffect, useState } from "react";
import { api } from "../api/backend";
import type { RestoreOptions, TeamsLink, Workspace } from "../types/workspace";
import { Button, Field, Modal } from "./ui";
import { MonitorPreview } from "./MonitorPreview";
import { TeamsLinksEditor } from "./TeamsLinksEditor";

/** Kayıtlı çalışma alanını görüntüle + düzenle: ad, Teams bağlantıları, zamanlama. */
export function WorkspaceDetail({
  id,
  onClose,
  onChanged,
}: {
  id: string;
  onClose: () => void;
  onChanged: () => void;
}) {
  const [ws, setWs] = useState<Workspace | null>(null);
  const [name, setName] = useState("");
  const [teams, setTeams] = useState<TeamsLink[]>([]);
  const [opts, setOpts] = useState<RestoreOptions | null>(null);
  const [tab, setTab] = useState<"apps" | "teams" | "chrome" | "options">("apps");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.getWorkspace(id).then((w) => {
      setWs(w);
      setName(w.name);
      setTeams(w.teams);
      setOpts(w.restore_options);
    });
  }, [id]);

  async function save() {
    if (!opts) return;
    setSaving(true);
    try {
      await api.updateWorkspaceMeta(id, { name, teams, restoreOptions: opts });
      onChanged();
      onClose();
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      open
      title="Çalışma alanı ayrıntıları"
      onClose={onClose}
      wide
      footer={
        <>
          <Button onClick={onClose}>İptal</Button>
          <Button variant="accent" onClick={save} disabled={saving}>
            {saving ? "Kaydediliyor…" : "Değişiklikleri kaydet"}
          </Button>
        </>
      }
    >
      {!ws || !opts ? (
        <p>Yükleniyor…</p>
      ) : (
        <>
          {ws.schema_version < 2 && (
            <p className="legacy-note">
              Bu çalışma alanı, pencere konumu düzeltmesinden önceki bir sürümle
              kaydedilmiş. Konumlar yaklaşık olarak geri yüklenir. Düzeninizi bir
              kez daha kaydederseniz bundan sonra birebir geri yüklenir.
            </p>
          )}

          <Field label="Ad">
            <input value={name} onChange={(e) => setName(e.target.value)} />
          </Field>

          <div className="detail-preview">
            <MonitorPreview monitors={ws.monitors} apps={ws.apps} height={120} />
            <div className="detail-meta">
              <span>{ws.monitors.length} monitör</span>
              <span>{ws.apps.length} uygulama</span>
              <span>{ws.teams.length} Teams bağlantısı</span>
              <span>
                {ws.chrome.captured
                  ? `${ws.chrome.windows.length} Chrome penceresi · ` +
                    `${ws.chrome.windows.reduce((n, w) => n + w.tabs.length, 0)} sekme` +
                    (ws.chrome.windows.some((w) => w.incognito)
                      ? ` · ${ws.chrome.windows.filter((w) => w.incognito).length} gizli`
                      : "")
                  : "Chrome verisi yok"}
              </span>
            </div>
          </div>

          <div className="tabs">
            <button
              className={tab === "apps" ? "tab is-active" : "tab"}
              onClick={() => setTab("apps")}
            >
              Uygulamalar
            </button>
            <button
              className={tab === "teams" ? "tab is-active" : "tab"}
              onClick={() => setTab("teams")}
            >
              Teams bağlantıları
            </button>
            <button
              className={tab === "chrome" ? "tab is-active" : "tab"}
              onClick={() => setTab("chrome")}
            >
              Chrome
            </button>
            <button
              className={tab === "options" ? "tab is-active" : "tab"}
              onClick={() => setTab("options")}
            >
              Geri yükleme zamanlaması
            </button>
          </div>

          {tab === "apps" && (
            <ul className="app-list">
              {ws.apps.map((a, i) => (
                <li key={i}>
                  <div className="app-list-main">
                    <span className="app-name">{a.process_name}</span>
                    <span className="app-path mono">{a.exe_path}</span>
                  </div>
                  <div className="app-windows">
                    {a.windows.map((w, j) => (
                      <span key={j} className="app-window-chip">
                        M{w.monitor} · {w.width}×{w.height} · {w.state}
                      </span>
                    ))}
                  </div>
                </li>
              ))}
              {ws.apps.length === 0 && <li className="muted">Yakalanan uygulama yok.</li>}
            </ul>
          )}

          {tab === "teams" && <TeamsLinksEditor links={teams} onChange={setTeams} />}

          {tab === "chrome" && <ChromeSummary ws={ws} />}

          {tab === "options" && (
            <RestoreOptionsForm opts={opts} onChange={setOpts} />
          )}
        </>
      )}
    </Modal>
  );
}

/** Kaydedilmiş Chrome pencereleri: profil, gizli mod ve sekme adresleri. */
function ChromeSummary({ ws }: { ws: Workspace }) {
  if (!ws.chrome.captured || ws.chrome.windows.length === 0) {
    return (
      <p className="muted">
        Bu çalışma alanında Chrome verisi yok. Kaydederken yardımcı eklentinin
        bağlı olması gerekir.
      </p>
    );
  }
  return (
    <div className="chrome-summary">
      {ws.chrome.profiles.length > 0 && (
        <ul className="profile-list">
          {ws.chrome.profiles.map((p, i) => (
            <li key={p.client_id}>
              <span className="profile-name">
                {p.label || `Chrome profili ${i + 1}`}
              </span>
              <span className="muted">
                {p.window_count} pencere
                {p.incognito_window_count > 0
                  ? ` · ${p.incognito_window_count} gizli`
                  : p.incognito_allowed
                    ? ""
                    : " · gizli moda izin yoktu"}
              </span>
            </li>
          ))}
        </ul>
      )}

      <ul className="app-list">
        {ws.chrome.windows.map((w, i) => (
          <li key={i}>
            <div className="app-list-main">
              <span className="app-name">
                {w.incognito ? "Gizli pencere" : "Pencere"} {i + 1}
                {w.profile ? ` — ${w.profile}` : ""}
              </span>
              <span className="app-path mono">
                {w.tabs.length} sekme
                {w.width != null && w.height != null
                  ? ` · ${w.width}×${w.height}`
                  : ""}
                {w.state && w.state !== "normal" ? ` · ${w.state}` : ""}
              </span>
            </div>
            <div className="app-windows">
              {w.tabs.slice(0, 6).map((t, j) => (
                <span key={j} className="app-window-chip" title={t.url}>
                  {t.pinned ? "📌 " : ""}
                  {t.title || t.url}
                </span>
              ))}
              {w.tabs.length > 6 && (
                <span className="app-window-chip">
                  +{w.tabs.length - 6} sekme daha
                </span>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function RestoreOptionsForm({
  opts,
  onChange,
}: {
  opts: RestoreOptions;
  onChange: (o: RestoreOptions) => void;
}) {
  const set = <K extends keyof RestoreOptions>(key: K, value: RestoreOptions[K]) =>
    onChange({ ...opts, [key]: value });

  const toggles: [keyof RestoreOptions, string][] = [
    ["launch_teams", "Teams'i başlat"],
    ["open_teams_links", "Oturum açıldıktan sonra Teams bağlantılarını aç"],
    ["launch_apps", "Uygulamaları başlat"],
    ["restore_chrome", "Chrome sekmelerini geri yükle"],
    ["restore_positions", "Pencere konumlarını geri yükle"],
  ];
  const delays: [keyof RestoreOptions, string, string][] = [
    ["teams_link_delay_ms", "Teams bağlantıları açılmadan önceki gecikme", "Devam'a tıkladıktan sonra"],
    ["app_launch_delay_ms", "Uygulamalar arası başlatma gecikmesi", "her uygulamaya açılma süresi tanır"],
    ["window_wait_timeout_ms", "Pencerenin görünmesi için en fazla bekleme", "devam etmeden önce"],
    ["position_settle_delay_ms", "Konumlandırmadan önce yerleşme gecikmesi", "pencerelerin yüklenmesini tamamlar"],
    [
      "chrome_restore_timeout_ms",
      "Chrome eklentisi için en fazla bekleme",
      "pencereler konumlandırılmadan önce sekmelerin açılmasını bekler",
    ],
  ];

  return (
    <div className="options-form">
      <div className="options-toggles">
        {toggles.map(([key, label]) => (
          <label key={key} className="switch-row">
            <input
              type="checkbox"
              checked={opts[key] as boolean}
              onChange={(e) => set(key, e.target.checked as never)}
            />
            <span>{label}</span>
          </label>
        ))}
      </div>
      <div className="options-delays">
        <Field
          label="Konumu yeniden uygulama sayısı"
          hint="birçok uygulama açılışta kendini bir kez yeniden boyutlandırır"
        >
          <div className="ms-input">
            <input
              type="number"
              min={1}
              max={10}
              step={1}
              value={opts.position_retries}
              onChange={(e) =>
                set("position_retries", Math.max(1, Number(e.target.value)) as never)
              }
            />
            <span className="ms-suffix">kez</span>
          </div>
        </Field>
        {delays.map(([key, label, hint]) => (
          <Field key={key} label={label} hint={hint}>
            <div className="ms-input">
              <input
                type="number"
                min={0}
                step={100}
                value={opts[key] as number}
                onChange={(e) => set(key, Number(e.target.value) as never)}
              />
              <span className="ms-suffix">ms</span>
            </div>
          </Field>
        ))}
      </div>
    </div>
  );
}
