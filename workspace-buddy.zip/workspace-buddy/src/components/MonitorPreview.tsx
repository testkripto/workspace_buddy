import { useMemo } from "react";
import type { AppEntry, MonitorInfo } from "../types/workspace";

/**
 * Kaydedilen monitör düzeninin ölçekli şematik önizlemesi; her pencere,
 * bulunduğu monitörün üzerinde küçük bir dikdörtgen olarak çizilir. Bu,
 * signature element: at a glance you can see the shape of the workspace you are
 * about to restore.
 */
export function MonitorPreview({
  monitors,
  apps,
  height = 132,
}: {
  monitors: MonitorInfo[];
  apps: AppEntry[];
  height?: number;
}) {
  const geom = useMemo(() => computeBounds(monitors), [monitors]);

  if (!monitors.length) {
    return <div className="mon-preview mon-preview-empty">Monitör verisi yok</div>;
  }

  const scale = height / geom.h;
  const width = Math.max(60, Math.round(geom.w * scale));

  const windows = apps.flatMap((a) =>
    a.windows.map((w) => ({ w, name: a.process_name }))
  );

  return (
    <svg
      className="mon-preview"
      viewBox={`0 0 ${width} ${height}`}
      width={width}
      height={height}
      role="img"
      aria-label={`${monitors.length} monitör genelinde düzen önizlemesi`}
    >
      {monitors.map((m) => {
        const x = (m.x - geom.minX) * scale;
        const y = (m.y - geom.minY) * scale;
        const w = m.width * scale;
        const h = m.height * scale;
        return (
          <g key={m.number}>
            <rect
              x={x}
              y={y}
              width={w}
              height={h}
              rx={4}
              className={`mon-screen ${m.is_primary ? "is-primary" : ""}`}
            />
            <text x={x + 6} y={y + 15} className="mon-label">
              {m.number}
              {m.is_primary ? " ★" : ""}
            </text>
          </g>
        );
      })}

      {windows.map(({ w }, i) => {
        const mon =
          (w.monitor_device
            ? monitors.find((m) => m.device_id === w.monitor_device)
            : undefined) ??
          monitors.find((m) => m.number === w.monitor) ??
          monitors[0];
        // For maximized windows, fill the monitor; otherwise use saved rect.
        const isMax = w.state === "maximized";
        const rx = isMax ? mon.x : w.x;
        const ry = isMax ? mon.y : w.y;
        const rw = isMax ? mon.width : w.width;
        const rh = isMax ? mon.height : w.height;
        return (
          <rect
            key={i}
            x={(rx - geom.minX) * scale}
            y={(ry - geom.minY) * scale}
            width={Math.max(6, rw * scale)}
            height={Math.max(5, rh * scale)}
            rx={2}
            className={`mon-window state-${w.state}`}
          />
        );
      })}
    </svg>
  );
}

function computeBounds(monitors: MonitorInfo[]) {
  if (!monitors.length) return { minX: 0, minY: 0, w: 1, h: 1 };
  let minX = Infinity,
    minY = Infinity,
    maxX = -Infinity,
    maxY = -Infinity;
  for (const m of monitors) {
    minX = Math.min(minX, m.x);
    minY = Math.min(minY, m.y);
    maxX = Math.max(maxX, m.x + m.width);
    maxY = Math.max(maxY, m.y + m.height);
  }
  return { minX, minY, w: maxX - minX, h: maxY - minY };
}
