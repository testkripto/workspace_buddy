import { useState } from "react";
import type { TeamsLink } from "../types/workspace";
import { Button, Field } from "./ui";

/**
 * Microsoft Teams bağlantılarını ekler / düzenler / kaldırır.
 *
 * Uygulama Teams oturum açma işlemini asla otomatikleştirmez — bunlar yalnızca
 * kullanıcının kendi oturumunu açtıktan sonra yeniden açılmasını istediği
 * bağlantılardır.
 *
 * Hem kurumsal (teams.microsoft.com) hem de Teams (ücretsiz / teams.live.com)
 * bağlantıları desteklenir.
 */
export function TeamsLinksEditor({
  links,
  onChange,
}: {
  links: TeamsLink[];
  onChange: (links: TeamsLink[]) => void;
}) {
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);

  const valid = name.trim() !== "" && isTeamsLink(url.trim());

  function commit() {
    if (!valid) return;
    if (editingId) {
      onChange(
        links.map((l) =>
          l.id === editingId ? { ...l, name: name.trim(), url: url.trim() } : l
        )
      );
    } else {
      onChange([
        ...links,
        { id: `tl_${Date.now()}`, name: name.trim(), url: url.trim() },
      ]);
    }
    setName("");
    setUrl("");
    setEditingId(null);
  }

  function edit(link: TeamsLink) {
    setEditingId(link.id);
    setName(link.name);
    setUrl(link.url);
  }

  function remove(id: string) {
    onChange(links.filter((l) => l.id !== id));
    if (editingId === id) {
      setEditingId(null);
      setName("");
      setUrl("");
    }
  }

  return (
    <div className="teams-editor">
      {links.length > 0 && (
        <ul className="teams-list">
          {links.map((l) => (
            <li key={l.id}>
              <div className="teams-item-main">
                <span className="teams-item-name">{l.name}</span>
                <span className="teams-item-url mono">{l.url}</span>
              </div>
              <div className="teams-item-actions">
                <Button variant="ghost" onClick={() => edit(l)}>
                  Düzenle
                </Button>
                <Button variant="danger" onClick={() => remove(l.id)}>
                  Kaldır
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}

      <div className="teams-form">
        <Field label="Görünen ad">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Proje Alfa Kanalı"
          />
        </Field>
        <Field
          label="Teams bağlantısı"
          hint="teams.live.com, teams.microsoft.com veya msteams: ile başlayan bir bağlantı. Teams'te bir sohbete ya da kanala sağ tıklayıp Bağlantıyı kopyala deyin."
        >
          <input
            className="mono"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="https://teams.live.com/l/channel/…"
          />
        </Field>
        {url.trim() !== "" && !isTeamsLink(url.trim()) && (
          <p className="inline-warn">
            Bu bir Teams bağlantısına benzemiyor. https://teams.live.com/,
            https://teams.microsoft.com/ veya msteams: ile başlayan bir bağlantı
            kullanın.
          </p>
        )}
        <div className="teams-form-actions">
          <Button variant="accent" onClick={commit} disabled={!valid}>
            {editingId ? "Değişiklikleri kaydet" : "Bağlantı ekle"}
          </Button>
          {editingId && (
            <Button
              onClick={() => {
                setEditingId(null);
                setName("");
                setUrl("");
              }}
            >
              İptal
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

/**
 * Kabul edilen biçimler:
 *   https://teams.live.com/...        (Teams — ücretsiz/kişisel)
 *   https://teams.microsoft.com/...   (Teams — kurumsal)
 *   msteams:...                       (Teams protokol bağlantısı)
 */
function isTeamsLink(url: string): boolean {
  return (
    /^https:\/\/teams\.live\.com\//i.test(url) ||
    /^https:\/\/teams\.microsoft\.com\//i.test(url) ||
    /^msteams:/i.test(url)
  );
}
