import { useEffect, useState } from "react";
import { api } from "../api/backend";
import type { ChromeClientInfo } from "../types/workspace";
import { Badge, Button, Modal } from "./ui";

/** Ayarlar: Chrome köprü durumu, bağlı profiller ve gizlilik özeti. */
export function Settings({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [port, setPort] = useState<number | null>(null);
  const [profiles, setProfiles] = useState<ChromeClientInfo[]>([]);

  useEffect(() => {
    if (!open) return;
    api.bridgePort().then(setPort).catch(() => setPort(null));
    const poll = () =>
      api.chromeProfiles().then(setProfiles).catch(() => setProfiles([]));
    poll();
    const t = setInterval(poll, 2000);
    return () => clearInterval(t);
  }, [open]);

  const connected = profiles.length > 0;

  return (
    <Modal open={open} title="Ayarlar" onClose={onClose} wide>
      <section className="settings-block">
        <div className="settings-row">
          <h4>Chrome yardımcı eklentisi</h4>
          {connected ? (
            <Badge tone="good">
              {profiles.length} profil bağlı
            </Badge>
          ) : (
            <Badge tone="warn">Bağlı değil</Badge>
          )}
        </div>

        {connected && (
          <ul className="profile-list">
            {profiles.map((p, i) => (
              <li key={p.client_id}>
                <span className="profile-name">
                  {p.label || `Chrome profili ${i + 1}`}
                </span>
                {p.incognito_allowed ? (
                  <Badge tone="good">gizli mod açık</Badge>
                ) : (
                  <Badge tone="warn">gizli moda izin yok</Badge>
                )}
              </li>
            ))}
          </ul>
        )}

        <p className="section-note">
          Chrome her profilde eklentinin ayrı bir kopyasını çalıştırır ve bir
          profilin diğerinin pencerelerini görmesine izin vermez. Açık tüm
          Chrome oturumlarının kaydedilmesi için eklentinin{" "}
          <strong>her profilde</strong> yüklü olması gerekir; yukarıdaki listede
          hepsinin görünmesi gerekir. Profil adlarını eklenti simgesine tıklayıp
          değiştirebilirsiniz.
        </p>
        <p className="section-note">
          Bir masaüstü uygulaması Chrome sekmelerini doğrudan okuyamaz; bu
          nedenle Workspace Buddy, yardımcı eklentinin{" "}
          <span className="mono">127.0.0.1:{port ?? "…"}</span> üzerinden
          konuştuğu küçük bir yerel köprü çalıştırır. Bu köprü yalnızca yerel
          döngüde çalışır ve bilgisayarınızdan asla dışarı çıkmaz.
        </p>
        <ol className="steps">
          <li>
            Chrome'u açın → <span className="mono">chrome://extensions</span>{" "}
            adresine gidin ve Geliştirici modunu etkinleştirin.
          </li>
          <li>
            <em>Paketlenmemiş öğe yükle</em> düğmesine tıklayın ve bu uygulamayla
            birlikte gelen <span className="mono">chrome-extension</span>{" "}
            klasörünü seçin.
          </li>
          <li>
            Workspace Buddy eklentisini sabitleyin. Otomatik olarak bağlanır ve
            yukarıdaki rozet yeşile döner.
          </li>
          <li>
            <strong>Gizli sekmeler için:</strong> aynı sayfada eklentinin{" "}
            <em>Ayrıntılar</em> bölümüne girip{" "}
            <em>Gizli modda izin ver</em> seçeneğini açın. Bu izin verilmezse
            Chrome, gizli pencereleri eklentiye hiç bildirmez ve
            kaydedilemezler.
          </li>
        </ol>
      </section>

      <section className="settings-block">
        <h4>Neler saklanır</h4>
        <p className="section-note">
          Yalnızca hassas olmayan düzen verileri: uygulama yolları, pencere konum
          ve boyutları, Teams bağlantıları, Chrome sekme adresleri ve
          belirlediğiniz seçenekler.
        </p>
        <ul className="privacy-list">
          <li>
            <span className="ok">✓</span> Uygulama yolları, pencere düzeni,
            monitör düzeni
          </li>
          <li>
            <span className="ok">✓</span> Seçtiğiniz adresler ve Teams
            bağlantıları
          </li>
          <li>
            <span className="no">✕</span> Parolalar, çerezler veya oturum
            anahtarları — asla
          </li>
          <li>
            <span className="no">✕</span> Oturum açma asla otomatikleştirilmez
            veya atlatılmaz
          </li>
        </ul>
      </section>

      <div className="settings-foot">
        <Button variant="accent" onClick={onClose}>
          Kapat
        </Button>
      </div>
    </Modal>
  );
}
