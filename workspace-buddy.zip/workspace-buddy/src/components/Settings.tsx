import { useEffect, useState } from "react";
import { api } from "../api/backend";
import { Badge, Button, Modal } from "./ui";

/** Ayarlar: Chrome köprü durumu, bağlantı bilgisi ve gizlilik özeti. */
export function Settings({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [port, setPort] = useState<number | null>(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    if (!open) return;
    api.bridgePort().then(setPort).catch(() => setPort(null));
    const poll = () => api.chromeStatus().then(setConnected).catch(() => setConnected(false));
    poll();
    const t = setInterval(poll, 2000);
    return () => clearInterval(t);
  }, [open]);

  return (
    <Modal open={open} title="Ayarlar" onClose={onClose} wide>
      <section className="settings-block">
        <div className="settings-row">
          <h4>Chrome yardımcı eklentisi</h4>
          {connected ? (
            <Badge tone="good">Bağlı</Badge>
          ) : (
            <Badge tone="warn">Bağlı değil</Badge>
          )}
        </div>
        <p className="section-note">
          Bir masaüstü uygulaması Chrome sekmelerini doğrudan okuyamaz; bu
          nedenle Workspace Buddy, yardımcı eklentinin{" "}
          <span className="mono">127.0.0.1:{port ?? "…"}</span> üzerinden
          konuştuğu küçük bir yerel köprü çalıştırır. Bu köprü yalnızca yerel
          döngüde çalışır ve bilgisayarınızdan asla dışarı çıkmaz.
        </p>
        <ol className="steps">
          <li>
            Chrome'u açın → <span className="mono">chrome://extensions</span>{" "}
            adresine gidin ve Geliştirici modunu etkinleştirin.
          </li>
          <li>
            <em>Paketlenmemiş öğe yükle</em> düğmesine tıklayın ve bu uygulamayla
            birlikte gelen <span className="mono">chrome-extension</span>{" "}
            klasörünü seçin.
          </li>
          <li>
            Workspace Buddy eklentisini sabitleyin. Otomatik olarak bağlanır ve
            yukarıdaki rozet yeşile döner.
          </li>
          <li>
            <strong>Gizli sekmeler için:</strong> aynı sayfada eklentinin{" "}
            <em>Ayrıntılar</em> bölümüne girip{" "}
            <em>Gizli modda izin ver</em> seçeneğini açın. Bu izin verilmezse
            Chrome, gizli pencereleri eklentiye hiç bildirmez ve
            kaydedilemezler.
          </li>
        </ol>
      </section>

      <section className="settings-block">
        <h4>Neler saklanır</h4>
        <p className="section-note">
          Yalnızca hassas olmayan düzen verileri: uygulama yolları, pencere konum
          ve boyutları, Teams bağlantıları, Chrome sekme adresleri ve
          belirlediğiniz seçenekler.
        </p>
        <ul className="privacy-list">
          <li>
            <span className="ok">✓</span> Uygulama yolları, pencere düzeni,
            monitör düzeni
          </li>
          <li>
            <span className="ok">✓</span> Seçtiğiniz adresler ve Teams
            bağlantıları
          </li>
          <li>
            <span className="no">✕</span> Parolalar, çerezler veya oturum
            anahtarları — asla
          </li>
          <li>
            <span className="no">✕</span> Oturum açma asla otomatikleştirilmez
            veya atlatılmaz
          </li>
        </ul>
      </section>

      <div className="settings-foot">
        <Button variant="accent" onClick={onClose}>
          Kapat
        </Button>
      </div>
    </Modal>
  );
}
