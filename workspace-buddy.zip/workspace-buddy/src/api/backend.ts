// Thin, typed wrapper over Tauri's `invoke` and event system, plus the
// import/export dialogs. Every backend call the UI makes goes through here.

import { invoke } from "@tauri-apps/api/core";
import { listen, type UnlistenFn } from "@tauri-apps/api/event";
import { open as openDialog, save as saveDialog } from "@tauri-apps/plugin-dialog";
import type {
  MonitorInfo,
  RestoreOptions,
  RestoreProgress,
  TeamsLink,
  Workspace,
  WorkspaceSummary,
} from "../types/workspace";

export const api = {
  listWorkspaces(): Promise<WorkspaceSummary[]> {
    return invoke("list_workspaces");
  },

  getWorkspace(id: string): Promise<Workspace> {
    return invoke("get_workspace", { id });
  },

  saveWorkspace(
    name: string,
    teams: TeamsLink[],
    captureChrome: boolean
  ): Promise<WorkspaceSummary> {
    return invoke("save_workspace", { name, teams, captureChrome });
  },

  updateWorkspaceMeta(
    id: string,
    patch: {
      name?: string;
      teams?: TeamsLink[];
      restoreOptions?: RestoreOptions;
    }
  ): Promise<void> {
    return invoke("update_workspace_meta", {
      id,
      name: patch.name ?? null,
      teams: patch.teams ?? null,
      restoreOptions: patch.restoreOptions ?? null,
    });
  },

  deleteWorkspace(id: string): Promise<void> {
    return invoke("delete_workspace", { id });
  },

  startRestore(id: string): Promise<void> {
    return invoke("start_restore", { id });
  },

  teamsContinue(): Promise<void> {
    return invoke("teams_continue");
  },

  restoreChromeOnly(id: string): Promise<void> {
    return invoke("restore_chrome_only", { id });
  },

  chromeStatus(): Promise<boolean> {
    return invoke("chrome_status");
  },

  bridgePort(): Promise<number> {
    return invoke("bridge_port");
  },

  currentMonitors(): Promise<MonitorInfo[]> {
    return invoke("current_monitors");
  },

  async exportWorkspace(id: string, name: string): Promise<boolean> {
    const dest = await saveDialog({
      title: "Export workspace",
      defaultPath: `${sanitize(name)}.workspace.json`,
      filters: [{ name: "Workspace", extensions: ["json"] }],
    });
    if (!dest) return false;
    await invoke("export_workspace", { id, destPath: dest });
    return true;
  },

  async importWorkspace(): Promise<string | null> {
    const src = await openDialog({
      title: "Import workspace",
      multiple: false,
      filters: [{ name: "Workspace", extensions: ["json"] }],
    });
    if (!src || Array.isArray(src)) return null;
    return invoke("import_workspace", { srcPath: src });
  },

  onRestoreProgress(cb: (p: RestoreProgress) => void): Promise<UnlistenFn> {
    return listen<RestoreProgress>("restore://progress", (e) => cb(e.payload));
  },
};

function sanitize(name: string): string {
  return name.replace(/[^a-z0-9-_]+/gi, "_").slice(0, 60) || "workspace";
}
