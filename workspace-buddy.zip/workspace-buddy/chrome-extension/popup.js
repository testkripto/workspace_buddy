/*
 * Workspace Buddy Yardımcısı — açılır pencere (popup).
 * Masaüstü uygulamasıyla bağlantı durumunu, yakalanabilecek pencere/sekme
 * sayısını ve bu Chrome profilinin adını gösterir.
 */

const dot = document.getElementById("dot");
const label = document.getElementById("label");
const winCount = document.getElementById("winCount");
const tabCount = document.getElementById("tabCount");
const incogCount = document.getElementById("incogCount");
const incogWarn = document.getElementById("incogWarn");
const labelInput = document.getElementById("profileLabel");

function render(connected) {
  dot.classList.toggle("on", connected);
  label.textContent = connected
    ? "Workspace Buddy'ye bağlı"
    : "Masaüstü uygulaması bulunamadı";
}

async function renderCounts() {
  try {
    // Gizli pencereler yalnızca gizli modda izin verilmişse listelenir.
    const allowed = await chrome.extension.isAllowedIncognitoAccess();
    const wins = await chrome.windows.getAll({
      populate: true,
      windowTypes: ["normal"],
    });
    const incog = wins.filter((w) => w.incognito);
    const tabs = wins.reduce((n, w) => n + (w.tabs ? w.tabs.length : 0), 0);

    winCount.textContent = String(wins.length);
    tabCount.textContent = String(tabs);
    incogCount.textContent = allowed ? String(incog.length) : "izin yok";
    incogWarn.style.display = allowed ? "none" : "block";
  } catch (e) {
    winCount.textContent = "–";
    tabCount.textContent = "–";
    incogCount.textContent = "–";
  }
}

function check() {
  chrome.runtime.sendMessage("poll-now", (res) => {
    render(res && res.connected);
    if (res && typeof res.label === "string" && labelInput.value === "") {
      labelInput.value = res.label;
    }
  });
  renderCounts();
}

// Ad değişikliğini kaydet; sonraki yoklamada köprüye gider.
let saveTimer = null;
labelInput.addEventListener("input", () => {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    chrome.runtime.sendMessage({ type: "set-label", label: labelInput.value });
  }, 300);
});

document.getElementById("refresh").addEventListener("click", check);

chrome.storage.local.get(["label"]).then((s) => {
  if (s.label) labelInput.value = s.label;
});
check();
