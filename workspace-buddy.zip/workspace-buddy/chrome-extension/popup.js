/*
 * Workspace Buddy Yardımcısı — açılır pencere (popup).
 * Masaüstü uygulamasıyla bağlantı durumunu ve yakalanabilecek pencere/sekme
 * sayısını gösterir.
 */

const dot = document.getElementById("dot");
const label = document.getElementById("label");
const winCount = document.getElementById("winCount");
const tabCount = document.getElementById("tabCount");
const incogCount = document.getElementById("incogCount");
const incogWarn = document.getElementById("incogWarn");

function render(connected) {
  dot.classList.toggle("on", connected);
  label.textContent = connected
    ? "Workspace Buddy'ye bağlı"
    : "Masaüstü uygulaması bulunamadı";
}

async function renderCounts() {
  try {
    const wins = await chrome.windows.getAll({ populate: true });
    const normal = wins.filter((w) => !w.type || w.type === "normal");
    const incog = normal.filter((w) => w.incognito);
    const tabs = normal.reduce((n, w) => n + (w.tabs ? w.tabs.length : 0), 0);

    winCount.textContent = String(normal.length);
    tabCount.textContent = String(tabs);
    incogCount.textContent = String(incog.length);

    // Gizli modda izin verilmemişse gizli pencereler hiç listelenmez.
    const allowed = await chrome.extension.isAllowedIncognitoAccess();
    incogWarn.style.display = allowed ? "none" : "block";
    if (!allowed) incogCount.textContent = "izin yok";
  } catch (e) {
    winCount.textContent = "–";
    tabCount.textContent = "–";
    incogCount.textContent = "–";
  }
}

function check() {
  chrome.runtime.sendMessage("poll-now", (res) => {
    render(res && res.connected);
  });
  renderCounts();
}

document.getElementById("refresh").addEventListener("click", check);
check();
