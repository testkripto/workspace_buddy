/*
 * Workspace Buddy Yardımcısı — arka plan hizmeti (service worker).
 *
 * Masaüstü uygulamasının 127.0.0.1:47615 adresindeki yerel köprüsüyle konuşur.
 * Protokol basit yoklamadan (polling) ibarettir:
 *   - GET  /capture-request?client=ID  -> { capture: true } ise pencere/sekme
 *                                         anlık görüntüsü alınıp /state'e
 *                                         gönderilir
 *   - GET  /pending-restore?client=ID  -> kuyrukta pencere varsa açılır
 *   - POST /restored                   -> sonuç bildirilir
 *
 * ÖNEMLİ — profil yalıtımı: Chrome her profilde eklentinin ayrı bir kopyasını
 * çalıştırır ve bir profilin diğerinin pencerelerini görmesine asla izin vermez.
 * "Açık tüm Chrome oturumlarını al" bu yüzden her profilin ayrı ayrı rapor
 * vermesi demektir. Her kopya bir kereye mahsus bir client_id üretip
 * chrome.storage.local içinde saklar; köprü bunlara göre birleştirme yapar.
 *
 * Yalnızca adresler ve pencere geometrisi okunur ve gönderilir. Çerezlere,
 * depolamaya, parolalara veya oturum anahtarlarına asla erişilmez.
 */

const BRIDGE = "http://127.0.0.1:47615";
const POLL_MS = 1500;

let connected = false;
let identity = null; // { clientId, label }

// ---------------------------------------------------------------------------
// Kimlik: profil başına kalıcı bir kimlik ve kullanıcının düzenleyebildiği ad
// ---------------------------------------------------------------------------
async function getIdentity() {
  if (identity) return identity;
  const stored = await chrome.storage.local.get(["clientId", "label"]);
  let clientId = stored.clientId;
  if (!clientId) {
    clientId = crypto.randomUUID();
    await chrome.storage.local.set({ clientId });
  }
  identity = { clientId, label: stored.label || (await guessLabel()) };
  return identity;
}

/**
 * Chrome, profil dizini adını eklentilere açmaz. Oturum açılmışsa e-posta
 * adresi iyi bir etikettir; identity izni verilmemişse veya oturum yoksa
 * kullanıcı açılır pencereden kendi adını yazabilir.
 */
async function guessLabel() {
  try {
    const info = await chrome.identity.getProfileUserInfo({
      accountStatus: "ANY",
    });
    if (info && info.email) return info.email;
  } catch (_) {
    /* identity izni verilmemiş — sorun değil, kullanıcı ad yazabilir */
  }
  return "";
}

async function setLabel(label) {
  await chrome.storage.local.set({ label });
  if (identity) identity.label = label;
}

// --- Canlı tutma: eşzamansız yoklama döngüsü, masaüstü uygulaması çalışırken
// hizmeti etkin tutar; hizmet geri dönüştürülürse alarm yeniden başlatır.
chrome.runtime.onInstalled.addListener(startLoop);
chrome.runtime.onStartup.addListener(startLoop);
// MV3 hizmet çalışanı 30 sn boşta kalınca durdurulur. Yoklama döngüsündeki
// her fetch bu sayacı sıfırlar, dolayısıyla köprü ayaktayken çalışan da ayakta
// kalır. Köprü kapalıyken çalışan durur; alarm onu geri getirir.
chrome.alarms.create("keepalive", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "keepalive") startLoop();
});

let looping = false;
async function startLoop() {
  if (looping) return;
  looping = true;
  try {
    // Durmadan yokla. Hizmet çalışanı durdurulursa `looping` de sıfırlanır ve
    // alarm döngüyü yeniden başlatır — bu yüzden yapay bir yineleme sınırına
    // gerek yok. Sınır varken, döngü bittikten sonra alarmın gelmesine kadar
    // eklenti bağlantısı kopuk görünüyordu.
    // eslint-disable-next-line no-constant-condition
    while (true) {
      await pollOnce();
      await sleep(POLL_MS);
    }
  } finally {
    looping = false;
  }
}

async function pollOnce() {
  const id = await getIdentity();
  const q = `?client=${encodeURIComponent(id.clientId)}&label=${encodeURIComponent(
    id.label
  )}`;
  try {
    const capReq = await getJson("/capture-request" + q);
    setConnected(true);
    if (capReq && capReq.capture) {
      const state = await captureState(id);
      await postJson("/state", state);
    }

    const pending = await getJson("/pending-restore" + q);
    if (pending && Array.isArray(pending.windows) && pending.windows.length) {
      const report = await restoreState(pending.windows);
      await postJson("/restored", { client_id: id.clientId, ...report });
    }
  } catch (e) {
    setConnected(false);
  }
}

function setConnected(v) {
  connected = v;
  chrome.storage.local.set({ connected: v, lastSeen: Date.now() });
}

// ---------------------------------------------------------------------------
// Yakalama
// ---------------------------------------------------------------------------
/**
 * Bu profildeki açık tüm normal Chrome pencerelerini yakalar. Birden çok
 * pencere ve (izin verilmişse) gizli pencereler dâhildir.
 *
 * Not: Gizli pencerelerin görünmesi için kullanıcının chrome://extensions
 * sayfasından bu eklentiye "Gizli modda izin ver" yetkisini vermesi gerekir.
 * Aksi hâlde Chrome bu pencereleri eklentiye hiç bildirmez.
 */
async function captureState(id) {
  const wins = await chrome.windows.getAll({
    populate: true,
    windowTypes: ["normal"],
  });
  const groupsById = await loadGroups();
  const incognitoAllowed = await isIncognitoAllowed();

  const windows = [];
  for (const w of wins) {
    const tabs = (w.tabs || [])
      .slice()
      .sort((a, b) => a.index - b.index)
      .filter((t) => isRestorableUrl(tabUrl(t)))
      .map((t) => ({
        url: tabUrl(t),
        title: t.title || null,
        pinned: !!t.pinned,
        group_id: typeof t.groupId === "number" ? t.groupId : -1,
        active: !!t.active,
        index: typeof t.index === "number" ? t.index : 0,
      }));

    if (tabs.length === 0) continue;

    const usedGroupIds = [...new Set(tabs.map((t) => t.group_id))].filter(
      (gid) => gid !== -1
    );
    const groups = usedGroupIds.map((gid) => groupsById[gid]).filter(Boolean);

    const activeTab = (w.tabs || []).find((t) => t.active);

    windows.push({
      client_id: id.clientId,
      profile: id.label || null,
      incognito: !!w.incognito,
      focused: !!w.focused,
      // Sınırlar her durumda kaydedilir. Eskiden yalnızca "normal" pencereler
      // için kaydediliyordu; bu yüzden ekranı kaplamış bir pencere geri
      // yüklenirken hangi monitörde olduğu bilinmiyor ve daima birincil
      // monitörde açılıyordu.
      left: numOrNull(w.left),
      top: numOrNull(w.top),
      width: numOrNull(w.width),
      height: numOrNull(w.height),
      state: w.state || null,
      // Chrome, işletim sistemi pencere başlığına etkin sekmenin başlığını
      // yazar. Masaüstü tarafı bir chrome.windows penceresini HWND'siyle
      // ancak bu sayede eşleştirebiliyor.
      active_tab_title: activeTab ? activeTab.title || null : null,
      tabs,
      groups,
    });
  }

  return {
    client_id: id.clientId,
    label: id.label || "",
    incognito_allowed: incognitoAllowed,
    windows,
  };
}

// Bir sekme henüz yüklenmediyse gerçek adresi pendingUrl alanında olur.
function tabUrl(t) {
  return t.url || t.pendingUrl || "";
}

async function loadGroups() {
  const byId = {};
  try {
    const groups = await chrome.tabGroups.query({});
    for (const g of groups) {
      byId[g.id] = {
        id: g.id,
        title: g.title || null,
        color: g.color || null,
        collapsed: !!g.collapsed,
      };
    }
  } catch (_) {
    // tabGroups bazı sürümlerde bulunmayabilir; gruplar isteğe bağlıdır.
  }
  return byId;
}

async function isIncognitoAllowed() {
  try {
    return await chrome.extension.isAllowedIncognitoAccess();
  } catch (_) {
    return false;
  }
}

// ---------------------------------------------------------------------------
// Geri yükleme
// ---------------------------------------------------------------------------
async function restoreState(savedWindows) {
  // Geri yüklemeden önce var olan pencereleri not al; sonunda içi boş yeni
  // sekme penceresi kaldıysa kapatılır (Chrome'u biz başlattıysak açılan
  // karşılama penceresi budur).
  const before = await chrome.windows.getAll({
    populate: true,
    windowTypes: ["normal"],
  });
  const beforeIds = new Set(before.map((w) => w.id));

  const incognitoAllowed = await isIncognitoAllowed();
  const wantsIncognito = savedWindows.some((w) => w.incognito);

  let opened = 0;
  let failed = 0;
  const errors = [];

  if (wantsIncognito && !incognitoAllowed) {
    errors.push(
      "Gizli pencereler açılamadı: bu eklentiye gizli modda izin verilmemiş. " +
        "chrome://extensions → Ayrıntılar → 'Gizli modda izin ver'."
    );
  }

  for (const w of savedWindows) {
    if (w.incognito && !incognitoAllowed) {
      failed++;
      continue;
    }
    try {
      await restoreWindow(w);
      opened++;
    } catch (e) {
      failed++;
      const msg = String((e && e.message) || e);
      if (errors.length < 5) errors.push(msg);
      console.warn("Workspace Buddy: bir pencere geri yüklenemedi", e);
    }
  }

  await closeLeftoverBlankWindows(beforeIds);
  return { opened, failed, errors };
}

async function restoreWindow(w) {
  const savedTabs = (w.tabs || []).filter((t) => isRestorableUrl(t.url));
  if (savedTabs.length === 0) return;

  // Pencereyi her zaman "normal" olarak, sınırlarıyla birlikte oluştururuz.
  // chrome.windows.create, state ile left/top/width/height'ı bir arada kabul
  // etmez; bu yüzden önce doğru monitörde konumlandırıp durumu sonra veririz.
  // Eskiden ekranı kaplamış pencerelerde sınırlar hiç verilmiyordu ve pencere
  // her zaman birincil monitörde kaplıyordu.
  const createOpts = {
    url: savedTabs.map((t) => t.url),
    incognito: !!w.incognito,
    focused: false,
  };
  if (w.left != null) createOpts.left = Math.round(w.left);
  if (w.top != null) createOpts.top = Math.round(w.top);
  if (w.width != null) createOpts.width = Math.max(200, Math.round(w.width));
  if (w.height != null) createOpts.height = Math.max(150, Math.round(w.height));

  let created;
  try {
    created = await chrome.windows.create(createOpts);
  } catch (e) {
    // Chrome, görünür ekran alanının dışında kalan sınırları reddeder
    // (monitör düzeni değişmişse olur). Sınırsız yeniden dene.
    const retry = {
      url: createOpts.url,
      incognito: createOpts.incognito,
      focused: false,
    };
    created = await chrome.windows.create(retry);
  }
  if (!created || created.id == null) throw new Error("pencere oluşturulamadı");

  // Sınırları bir kez daha uygula: Chrome, oluşturma sırasında verilen
  // sınırları zaman zaman kendi "kademeli açılma" mantığıyla kaydırır.
  const bounds = {};
  if (w.left != null) bounds.left = Math.round(w.left);
  if (w.top != null) bounds.top = Math.round(w.top);
  if (w.width != null) bounds.width = Math.max(200, Math.round(w.width));
  if (w.height != null) bounds.height = Math.max(150, Math.round(w.height));
  if (Object.keys(bounds).length > 0) {
    try {
      await chrome.windows.update(created.id, bounds);
    } catch (_) {}
  }

  await applyTabDetails(created, savedTabs, w);

  // Durum en sonda: pencere artık doğru monitörde, dolayısıyla orada kaplar.
  if (w.state && w.state !== "normal") {
    try {
      await chrome.windows.update(created.id, { state: w.state });
    } catch (_) {}
  }
  if (w.focused) {
    try {
      await chrome.windows.update(created.id, { focused: true });
    } catch (_) {}
  }
}

/**
 * Sabitleme, gruplama ve etkin sekmeyi yeniden uygular. Sekmeler kaydedilen
 * adres sırasıyla oluşturulduğu için sıraya göre eşleştirilir.
 */
async function applyTabDetails(createdWindow, savedTabs, savedWindow) {
  const liveTabs = (createdWindow.tabs || [])
    .slice()
    .sort((a, b) => a.index - b.index);
  const n = Math.min(liveTabs.length, savedTabs.length);

  // Önce sabitlenmiş sekmeler. Soldan sağa sırayla sabitlemek, Chrome'un
  // sabitlenmiş sekmeleri başa taşıma davranışıyla birlikte özgün sırayı
  // korur.
  for (let i = 0; i < n; i++) {
    if (savedTabs[i].pinned) {
      try {
        await chrome.tabs.update(liveTabs[i].id, { pinned: true });
      } catch (_) {}
    }
  }

  // Grupları yeniden oluştur: canlı sekme kimliklerini kaydedilen grup
  // kimliğine göre topla, sonra grupla ve başlık/renk uygula.
  const buckets = new Map();
  for (let i = 0; i < n; i++) {
    const gid = savedTabs[i].group_id;
    if (gid !== -1 && gid != null) {
      if (!buckets.has(gid)) buckets.set(gid, []);
      buckets.get(gid).push(liveTabs[i].id);
    }
  }

  const savedGroups = {};
  for (const g of savedWindow.groups || []) savedGroups[g.id] = g;

  for (const [savedGid, tabIds] of buckets) {
    try {
      const newGroupId = await chrome.tabs.group({
        createProperties: { windowId: createdWindow.id },
        tabIds,
      });
      const meta = savedGroups[savedGid];
      if (meta) {
        await chrome.tabGroups.update(newGroupId, {
          title: meta.title || undefined,
          color: meta.color || undefined,
          collapsed: !!meta.collapsed,
        });
      }
    } catch (_) {}
  }

  // Etkin sekme: pencere başlığını belirlediği için masaüstü tarafındaki
  // eşleştirmenin de doğru çalışmasını sağlar.
  const activeIdx = savedTabs.findIndex((t) => t.active);
  if (activeIdx >= 0 && activeIdx < n) {
    try {
      await chrome.tabs.update(liveTabs[activeIdx].id, { active: true });
    } catch (_) {}
  }
}

/** Geri yüklemeden önce var olan, içinde yalnızca boş bir yeni sekme bulunan
 *  pencereleri kapatır. Kullanıcının gerçek pencerelerine dokunulmaz. */
async function closeLeftoverBlankWindows(beforeIds) {
  try {
    const wins = await chrome.windows.getAll({
      populate: true,
      windowTypes: ["normal"],
    });
    for (const w of wins) {
      if (!beforeIds.has(w.id)) continue;
      const tabs = w.tabs || [];
      if (tabs.length !== 1) continue;
      if (!isBlankTab(tabs[0])) continue;
      await chrome.windows.remove(w.id);
    }
  } catch (_) {}
}

function isBlankTab(t) {
  const u = tabUrl(t);
  return (
    u === "" ||
    u === "about:blank" ||
    /^chrome:\/\/(newtab|new-tab-page)\/?$/i.test(u)
  );
}

// ---------------------------------------------------------------------------
// Yardımcılar
// ---------------------------------------------------------------------------
function isRestorableUrl(url) {
  if (!url) return false;
  // Yeniden açılması anlamlı olmayan dâhilî sayfaları atla.
  return /^(https?|file|ftp):/i.test(url);
}

function numOrNull(v) {
  return typeof v === "number" ? v : null;
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function getJson(path) {
  const res = await fetch(BRIDGE + path, { method: "GET" });
  if (!res.ok) throw new Error("geçersiz durum " + res.status);
  return res.json();
}

async function postJson(path, body) {
  const res = await fetch(BRIDGE + path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error("geçersiz durum " + res.status);
  return res.json();
}

// Açılır pencerenin anında yoklama tetiklemesine izin ver.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  const type = typeof msg === "string" ? msg : msg && msg.type;

  if (type === "poll-now") {
    pollOnce().then(async () => {
      const id = await getIdentity();
      sendResponse({ connected, label: id.label });
    });
    return true;
  }
  if (type === "status") {
    getIdentity().then((id) => sendResponse({ connected, label: id.label }));
    return true;
  }
  if (type === "set-label") {
    setLabel(msg.label || "").then(() => sendResponse({ ok: true }));
    return true;
  }
});
