/*
 * Workspace Buddy Yardımcısı — arka plan hizmeti (service worker).
 *
 * Masaüstü uygulamasının 127.0.0.1:47615 adresindeki yerel köprüsüyle konuşur.
 * Protokol basit yoklamadan (polling) ibarettir:
 *   - GET  /capture-request  -> { capture: true } ise pencere/sekme anlık
 *                               görüntüsü alınır ve /state adresine gönderilir
 *   - GET  /pending-restore  -> kuyrukta bir görüntü varsa pencereler/sekmeler
 *                               yeniden açılır
 *
 * Yalnızca adresler ve pencere geometrisi okunur ve gönderilir. Çerezlere,
 * depolamaya, parolalara veya oturum anahtarlarına asla erişilmez.
 */

const BRIDGE = "http://127.0.0.1:47615";
const POLL_MS = 1500;

let connected = false;

// --- Canlı tutma: eşzamansız yoklama döngüsü, masaüstü uygulaması çalışırken
// hizmeti etkin tutar; hizmet geri dönüştürülürse alarm yeniden başlatır.
chrome.runtime.onInstalled.addListener(startLoop);
chrome.runtime.onStartup.addListener(startLoop);
chrome.alarms.create("keepalive", { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "keepalive") startLoop();
});

let looping = false;
async function startLoop() {
  if (looping) return;
  looping = true;
  try {
    // Sınırlı sayıda yinelemeden sonra alarmın yeniden başlatmasına izin ver.
    for (let i = 0; i < 40; i++) {
      await pollOnce();
      await sleep(POLL_MS);
    }
  } finally {
    looping = false;
  }
}

async function pollOnce() {
  try {
    const capReq = await getJson("/capture-request");
    setConnected(true);
    if (capReq && capReq.capture) {
      const state = await captureState();
      await postJson("/state", state);
    }

    const pending = await getJson("/pending-restore");
    if (pending && pending.windows) {
      await restoreState(pending);
    }
  } catch (e) {
    setConnected(false);
  }
}

function setConnected(v) {
  connected = v;
  chrome.storage.local.set({ connected: v, lastSeen: Date.now() });
}

// ---------------------------------------------------------------------------
// Yakalama
// ---------------------------------------------------------------------------
/**
 * Açık tüm normal Chrome pencerelerini yakalar. Birden çok pencere, birden çok
 * oturum/profil ve (izin verilmişse) gizli pencereler dâhil edilir.
 *
 * Not: Gizli pencerelerin görünmesi için kullanıcının chrome://extensions
 * sayfasından bu eklentiye "Gizli modda izin ver" yetkisini vermesi gerekir.
 * Aksi hâlde Chrome bu pencereleri eklentiye hiç bildirmez.
 */
async function captureState() {
  const wins = await chrome.windows.getAll({ populate: true });
  const groupsById = await loadGroups();
  const incognitoAllowed = await isIncognitoAllowed();

  const windows = [];
  for (const w of wins) {
    // Kendi açılır penceremizi ve geliştirici araçlarını atla.
    if (w.type && w.type !== "normal") continue;

    const tabs = (w.tabs || [])
      .filter((t) => isRestorableUrl(t.url))
      .map((t) => ({
        url: t.url,
        title: t.title || null,
        pinned: !!t.pinned,
        group_id: typeof t.groupId === "number" ? t.groupId : -1,
        active: !!t.active,
      }));

    if (tabs.length === 0) continue;

    const usedGroupIds = [...new Set(tabs.map((t) => t.group_id))].filter(
      (id) => id !== -1
    );
    const groups = usedGroupIds.map((id) => groupsById[id]).filter(Boolean);

    windows.push({
      // Chrome, profil dizini adını eklentilere açmaz; bu nedenle boş bırakılır.
      // Ayrıntı için BENIOKU dosyasına bakın.
      profile: null,
      incognito: !!w.incognito,
      focused: !!w.focused,
      left: numOrNull(w.left),
      top: numOrNull(w.top),
      width: numOrNull(w.width),
      height: numOrNull(w.height),
      state: w.state || null,
      tabs,
      groups,
    });
  }

  return { captured: true, incognito_allowed: incognitoAllowed, windows };
}

async function loadGroups() {
  const byId = {};
  try {
    const groups = await chrome.tabGroups.query({});
    for (const g of groups) {
      byId[g.id] = {
        id: g.id,
        title: g.title || null,
        color: g.color || null,
        collapsed: !!g.collapsed,
      };
    }
  } catch (_) {
    // tabGroups bazı sürümlerde bulunmayabilir; gruplar isteğe bağlıdır.
  }
  return byId;
}

async function isIncognitoAllowed() {
  try {
    return await chrome.extension.isAllowedIncognitoAccess();
  } catch (_) {
    return false;
  }
}

// ---------------------------------------------------------------------------
// Geri yükleme
// ---------------------------------------------------------------------------
async function restoreState(state) {
  for (const w of state.windows) {
    try {
      await restoreWindow(w);
    } catch (e) {
      console.warn("Workspace Buddy: bir pencere geri yüklenemedi", e);
    }
  }
}

async function restoreWindow(w) {
  const urls = (w.tabs || []).map((t) => t.url).filter(isRestorableUrl);
  if (urls.length === 0) return;

  // Gizli pencereler yalnızca eklentiye gizli modda izin verilmişse yeniden
  // oluşturulabilir (chrome://extensions → Gizli modda izin ver). Kaydedilen
  // adresler yeni bir gizli pencerede açılır; hiçbir çerez veya oturum geri
  // yüklenmez.
  const createOpts = {
    url: urls,
    incognito: !!w.incognito,
    focused: !!w.focused,
  };

  // "maximized"/"minimized"/"fullscreen" durumları tek bir oluşturma çağrısında
  // sınırlarla birlikte verilemez; bu yüzden önce normal pencereler için
  // sınırları uygular, durumu sonradan ayarlarız.
  const isNormalState = !w.state || w.state === "normal";
  if (isNormalState) {
    if (w.left != null) createOpts.left = w.left;
    if (w.top != null) createOpts.top = w.top;
    if (w.width != null) createOpts.width = w.width;
    if (w.height != null) createOpts.height = w.height;
  }

  let created;
  try {
    created = await chrome.windows.create(createOpts);
  } catch (e) {
    // En sık nedeni: eklentiye gizli modda izin verilmemiş olması.
    if (w.incognito) {
      console.warn(
        "Workspace Buddy: gizli pencere açılamadı. Bu eklenti için 'Gizli modda izin ver' seçeneğini etkinleştirin."
      );
    }
    return;
  }

  // Ekran dışında kalmaması ve tam konumlanması için sınırları yeniden uygula.
  if (isNormalState && created && created.id != null) {
    const bounds = {};
    if (w.left != null) bounds.left = w.left;
    if (w.top != null) bounds.top = w.top;
    if (w.width != null) bounds.width = w.width;
    if (w.height != null) bounds.height = w.height;
    if (Object.keys(bounds).length > 0) {
      try {
        await chrome.windows.update(created.id, bounds);
      } catch (_) {}
    }
  }

  if (!isNormalState && w.state) {
    try {
      await chrome.windows.update(created.id, { state: w.state });
    } catch (_) {}
  }

  await applyTabDetails(created, w);
}

// Yeni oluşturulan sekmelere sabitleme durumunu ve sekme gruplarını yeniden
// uygular. Sekmeler kaydedilen adres sırasıyla oluşturulduğu için eşleştirilir.
async function applyTabDetails(createdWindow, savedWindow) {
  const liveTabs = (createdWindow.tabs || []).slice();
  const savedTabs = savedWindow.tabs || [];

  // Önce sabitlenmiş sekmeler.
  for (let i = 0; i < Math.min(liveTabs.length, savedTabs.length); i++) {
    if (savedTabs[i].pinned) {
      try {
        await chrome.tabs.update(liveTabs[i].id, { pinned: true });
      } catch (_) {}
    }
  }

  // Grupları yeniden oluştur: canlı sekme kimliklerini kaydedilen grup
  // kimliğine göre topla, sonra grupla ve başlık/renk uygula.
  const buckets = {};
  for (let i = 0; i < Math.min(liveTabs.length, savedTabs.length); i++) {
    const gid = savedTabs[i].group_id;
    if (gid !== -1) {
      (buckets[gid] = buckets[gid] || []).push(liveTabs[i].id);
    }
  }

  const savedGroups = {};
  for (const g of savedWindow.groups || []) savedGroups[g.id] = g;

  for (const [savedGid, tabIds] of Object.entries(buckets)) {
    try {
      const newGroupId = await chrome.tabs.group({
        createProperties: { windowId: createdWindow.id },
        tabIds,
      });
      const meta = savedGroups[savedGid];
      if (meta) {
        await chrome.tabGroups.update(newGroupId, {
          title: meta.title || undefined,
          color: meta.color || undefined,
          collapsed: !!meta.collapsed,
        });
      }
    } catch (_) {}
  }
}

// ---------------------------------------------------------------------------
// Yardımcılar
// ---------------------------------------------------------------------------
function isRestorableUrl(url) {
  if (!url) return false;
  // Yeniden açılması anlamlı olmayan dâhilî sayfaları atla.
  return /^(https?|file|ftp):/i.test(url);
}

function numOrNull(v) {
  return typeof v === "number" ? v : null;
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function getJson(path) {
  const res = await fetch(BRIDGE + path, { method: "GET" });
  if (!res.ok) throw new Error("geçersiz durum " + res.status);
  return res.json();
}

async function postJson(path, body) {
  const res = await fetch(BRIDGE + path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error("geçersiz durum " + res.status);
  return res.json();
}

// Açılır pencerenin anında yoklama tetiklemesine izin ver.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg === "poll-now") {
    pollOnce().then(() => sendResponse({ connected }));
    return true;
  }
  if (msg === "status") {
    sendResponse({ connected });
  }
});
