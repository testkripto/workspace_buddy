# Workspace Buddy

Windows çalışma ortamınızın tamamını kaydedin ve tek tıkla geri yükleyin: açık
uygulamalar, birden çok monitördeki pencere düzeni, Microsoft Teams
bağlantıları ve Chrome pencereleri/sekmeleri.

**Tauri 2 + Rust** (arka uç, yerel Win32 API'leri) ve **React + TypeScript**
(ön uç) ile geliştirilmiştir. Masaüstü uygulamaları tarayıcı sekmelerini kendi
başına okuyamadığı için sekmeleri bir **Chrome eklentisi** yönetir.

> **Önce gizlilik.** Workspace Buddy parolaları, çerezleri veya oturum
> anahtarlarını asla saklamaz; hiçbir oturum açma işlemini otomatikleştirmez
> veya atlatmaz. Yalnızca uygulama yollarını, pencere/monitör düzenini,
> adresleri ve sizin seçtiğiniz Teams bağlantılarını saklar. Gizli pencereler
> geri yüklenirken yalnızca **adresler** yeni bir gizli pencerede açılır; o
> pencerenin oturumu her zaman sıfırdan başlar.

---

## Dosya biçimi sürümü

`workspace.json` artık **sürüm 2**. Sürüm 1 dosyaları okunur ve çalışır, ancak
pencere geometrileri ham `WINDOWPLACEMENT` koordinatlarıyla yazıldığı için
konumlar yalnızca yaklaşık geri yüklenir. Uygulama bunu ayrıntılar ekranında
uyarı olarak gösterir. Düzeninizi bir kez daha kaydetmek sorunu kalıcı olarak
çözer.

---

## Özellikler

- **Çalışma alanını kaydet** — açık uygulamaları algılar (yürütülebilir dosya
  yolu, işlem adı, pencere başlığı, X/Y/Genişlik/Yükseklik, monitör numarası,
  ekranı kaplamış/simge durumunda).
- **Teams desteği** — Teams'i başlatır, "Lütfen Teams'te oturum açın, ardından
  Devam'a tıklayın" diyerek duraklar, siz onayladıktan sonra kaydettiğiniz
  bağlantıları açar. Hem `teams.live.com` (kişisel) hem `teams.microsoft.com`
  (kurumsal) hem de `msteams:` bağlantıları desteklenir.
- **Chrome bütünleşmesi** — birden çok pencere, **birden çok profil/oturum** ve
  gizli pencereler dâhil sekmeleri, adresleri, grupları ve pencere konumlarını
  kaydeder/geri yükler.
- **Pencere yerleştirme motoru** — konumu, boyutu, monitörü ve pencere durumunu
  Win32 ile birebir geri yükler; çift monitör, farklı çözünürlükler ve farklı
  ölçekleme (DPI) desteklenir.
- **Taşınabilir biçim** — `workspace.json`; dışa/içe aktarma ve yedekleme.

---

## Kurulum (hazır .exe ile)

GitHub Actions derlemesinden inen `workspace-buddy-windows` arşivindeki
**`.exe`** dosyasını çift tıklayın. Uygulama Başlat menüsüne kurulur.

### Chrome eklentisini yükleme

1. Chrome → adres çubuğuna `chrome://extensions` yazın.
2. Sağ üstten **Geliştirici modu**'nu açın.
3. **Paketlenmemiş öğe yükle** → bu projedeki `chrome-extension` klasörünü
   seçin.
4. **Gizli sekmeler için (önemli):** aynı sayfada eklentinin **Ayrıntılar**
   bölümüne girip **Gizli modda izin ver** seçeneğini açın.

> Bu izin verilmezse Chrome, gizli pencereleri eklentiye **hiç bildirmez** —
> bu bir Chrome güvenlik kuralıdır, uygulama bunu aşamaz. İzin verildiğinde
> gizli pencerelerdeki adresler kaydedilir ve geri yüklemede **yeni bir gizli
> pencerede** açılır. Hiçbir çerez veya oturum bilgisi taşınmaz.

Eklenti yüklendiğinde uygulamadaki **Ayarlar** ekranında Chrome köprüsü
**Bağlı** görünür.

---

## Geliştirici derlemesi

Gereksinimler: Rust, Node.js 18+, WebView2 Çalışma Zamanı, Visual Studio Build
Tools ("Desktop development with C++" bileşeni).

```bash
npm install
npm run tauri dev      # geliştirme modunda çalıştır
npm run tauri build    # kurulum dosyalarını üretir
```

Kurulum dosyaları: `src-tauri/target/release/bundle/` (nsis → `.exe`,
msi → `.msi`).

### GitHub ile derleme (bilgisayarınıza hiçbir araç kurmadan)

Depoda `.github/workflows/build.yml` bulunur. Projeyi (veya zip'ini) depoya
gönderdiğinizde GitHub'ın Windows sunucuları derlemeyi yapar ve kurulum
dosyalarını **Actions → çalıştırma → Artifacts** altında sunar.

---

## Geri yükleme sırası

Gecikmeler **Ayrıntılar → Geri yükleme zamanlaması** sekmesinden ayarlanabilir.

1. Teams başlatılır.
2. Uygulama durur ve oturum açmanızı bekler → **Devam**.
3. Teams bağlantıları açılır.
4. Uygulamalar başlatılır (Chrome hariç).
5. Chrome başlatılır ve eklentiye kaydedilen pencereler gönderilir.
6. Eklenti pencereleri ve sekmeleri açar; **bittiğini bildirir**.
7. Pencere konumları ve boyutları uygulanır — Chrome dâhil.

> Chrome'un genel uygulama başlatıcısıyla **başlatılmaması** önemli: aksi hâlde
> eklentinin doldurduğu Chrome'un yanında boş bir Chrome daha açılır ve
> konumlandırma adımı geometri sayısının iki katı pencere görür.

---

## Mimari

| Katman | Dosya | Görev |
| --- | --- | --- |
| Veri modeli | `src-tauri/src/model.rs` | `workspace.json` şeması |
| Monitör/pencere tarama | `src-tauri/src/win/enumerate.rs` | `EnumDisplayMonitors`, `EnumWindows`, `GetWindowPlacement` |
| Yerleştirme motoru | `src-tauri/src/win/placement.rs` | `ShellExecuteExW`, `SetWindowPos`, `ShowWindow`, düzen çevirisi |
| Geri yükleme akışı | `src-tauri/src/restore.rs` | sıralı adımlar, ilerleme olayları, Teams kapısı |
| Chrome köprüsü | `src-tauri/src/chrome_bridge.rs` | `127.0.0.1:47615` yerel HTTP, profil başına birleştirme |
| Depolama | `src-tauri/src/storage.rs` | çalışma alanı dosyaları, içe/dışa aktarma |
| Arayüz | `src/` | React + TypeScript (Türkçe) |
| Eklenti | `chrome-extension/` | MV3 hizmet çalışanı (Türkçe) |

### Çift monitör ve farklı çözünürlük

`placement.rs::translate_geometry()` üç durumu ayırır:

1. **Monitör aynı** (aynı cihaz adı ve aynı sınırlar) → kaydedilen dikdörtgen
   hiç dokunulmadan uygulanır. Ölçekleme yok, kırpma yok.
2. **Monitör var ama değişmiş** → pencerenin boyutu korunur (yalnızca DPI farkı
   kadar ölçeklenir), konumu oransal taşınır, sığmıyorsa küçültülür.
3. **Monitör yok** → birincil monitöre alınır.

Monitörler dizin numarasıyla değil, GDI cihaz adıyla (`\\.\DISPLAY1`)
eşleştirilir; böylece bir ekran çıkarılıp takıldığında numaralar kaysa bile
pencereler doğru ekrana gider.

### Chrome profilleri (birden çok oturum)

Chrome her profilde eklentinin **ayrı bir kopyasını** çalıştırır ve bir profilin
diğerinin pencerelerini görmesine asla izin vermez. Bu nedenle:

1. Eklentiyi **kullandığınız her Chrome profiline** ayrı ayrı yükleyin.
2. Her kopya kendisi için kalıcı bir kimlik üretir; köprü gelen anlık
   görüntüleri bu kimliğe göre **birleştirir**, böylece tüm oturumlar tek bir
   `workspace.json` içinde toplanır.
3. Geri yüklemede her pencere, kaydedildiği profile geri gönderilir. O profil
   açık değilse pencereler bağlı olan ilk profilde açılır (hiçbir şey
   kaybolmaz).

Chrome, profil **dizini** adını eklentilere açmadığı için profillere kendiniz
ad verirsiniz: eklenti simgesine tıklayıp "Bu profilin adı" alanını doldurun.
Adlar Ayarlar ekranında ve çalışma alanı ayrıntılarında görünür.

### Pencere konumları nasıl birebir geri yükleniyor

Üç ayrıntı bunu belirliyor:

- **Koordinat dönüşümü.** `GetWindowPlacement`, `rcNormalPosition` alanını
  ekran koordinatlarında değil, *çalışma alanı* (workspace) koordinatlarında
  döndürür — birincil monitörün çalışma alanı başlangıcı kadar kaymıştır.
  Microsoft'un kendi belgeleri de bu değerlerin doğrudan `SetWindowPos`'a
  verilmesinin pencereleri kaydıracağı konusunda uyarır. Kaydedilen her şey
  gerçek ekran koordinatına çevrilir, geri yüklerken tersi yapılır.
- **Pencere eşleştirme.** Aynı uygulamanın birden çok penceresi başlık, pencere
  sınıfı ve z-sırası puanlanarak eşleştirilir. Eskiden listeler sırayla
  eşleniyordu; z-sırası kayıt sırasıyla ilgisiz olduğu için pencereler
  birbirinin boyutunu alıyordu.
- **Doğrula ve yinele.** Electron, Office ve Chrome pencereleri açıldıktan kısa
  süre sonra kendilerini bir kez yeniden boyutlandırır. Konum uygulandıktan
  sonra doğrulanır ve gerekirse birkaç kez yinelenir (Ayrıntılar → Geri yükleme
  zamanlaması → "Konumu yeniden uygulama sayısı").

---

## Güvenlik

- Parola, çerez veya oturum anahtarı **saklanmaz**.
- Oturum açma **otomatikleştirilmez ve atlatılmaz** (Teams dâhil).
- Köprü yalnızca `127.0.0.1` üzerinde dinler; veri bilgisayardan çıkmaz.
- Saklananlar: uygulama yolları, pencere/monitör düzeni, adresler, Teams
  bağlantıları ve seçenekleriniz.
