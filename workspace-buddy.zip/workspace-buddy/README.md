# Workspace Buddy

Windows çalışma ortamınızın tamamını kaydedin ve tek tıkla geri yükleyin: açık
uygulamalar, birden çok monitördeki pencere düzeni, Microsoft Teams
bağlantıları ve Chrome pencereleri/sekmeleri.

**Tauri 2 + Rust** (arka uç, yerel Win32 API'leri) ve **React + TypeScript**
(ön uç) ile geliştirilmiştir. Masaüstü uygulamaları tarayıcı sekmelerini kendi
başına okuyamadığı için sekmeleri bir **Chrome eklentisi** yönetir.

> **Önce gizlilik.** Workspace Buddy parolaları, çerezleri veya oturum
> anahtarlarını asla saklamaz; hiçbir oturum açma işlemini otomatikleştirmez
> veya atlatmaz. Yalnızca uygulama yollarını, pencere/monitör düzenini,
> adresleri ve sizin seçtiğiniz Teams bağlantılarını saklar.

---

## Özellikler

- **Çalışma alanını kaydet** — açık uygulamaları algılar (yürütülebilir dosya
  yolu, işlem adı, pencere başlığı, X/Y/Genişlik/Yükseklik, monitör numarası,
  ekranı kaplamış/simge durumunda).
- **Teams desteği** — Teams'i başlatır, "Lütfen Teams'te oturum açın, ardından
  Devam'a tıklayın" diyerek duraklar, siz onayladıktan sonra kaydettiğiniz
  bağlantıları açar. Hem `teams.live.com` (kişisel) hem `teams.microsoft.com`
  (kurumsal) hem de `msteams:` bağlantıları desteklenir.
- **Chrome bütünleşmesi** — birden çok pencere, birden çok oturum ve gizli
  pencereler dâhil sekmeleri, adresleri, grupları ve pencere konumlarını
  kaydeder/geri yükler.
- **Pencere yerleştirme motoru** — konumu, boyutu, monitörü ve pencere durumunu
  Win32 ile birebir geri yükler; çift monitör ve farklı çözünürlükler
  desteklenir.
- **Taşınabilir biçim** — `workspace.json`; dışa/içe aktarma ve yedekleme.

---

## Kurulum (hazır .exe ile)

GitHub Actions derlemesinden inen `workspace-buddy-windows` arşivindeki
**`.exe`** dosyasını çift tıklayın. Uygulama Başlat menüsüne kurulur.

### Chrome eklentisini yükleme

1. Chrome → adres çubuğuna `chrome://extensions` yazın.
2. Sağ üstten **Geliştirici modu**'nu açın.
3. **Paketlenmemiş öğe yükle** → bu projedeki `chrome-extension` klasörünü
   seçin.
4. **Gizli sekmeler için (önemli):** aynı sayfada eklentinin **Ayrıntılar**
   bölümüne girip **Gizli modda izin ver** seçeneğini açın.

> Bu izin verilmezse Chrome, gizli pencereleri eklentiye **hiç bildirmez** —
> bu bir Chrome güvenlik kuralıdır, uygulama bunu aşamaz. İzin verildiğinde
> gizli pencerelerdeki adresler kaydedilir ve geri yüklemede **yeni bir gizli
> pencerede** açılır. Hiçbir çerez veya oturum bilgisi taşınmaz.

Eklenti yüklendiğinde uygulamadaki **Ayarlar** ekranında Chrome köprüsü
**Bağlı** görünür.

---

## Geliştirici derlemesi

Gereksinimler: Rust, Node.js 18+, WebView2 Çalışma Zamanı, Visual Studio Build
Tools ("Desktop development with C++" bileşeni).

```bash
npm install
npm run tauri dev      # geliştirme modunda çalıştır
npm run tauri build    # kurulum dosyalarını üretir
```

Kurulum dosyaları: `src-tauri/target/release/bundle/` (nsis → `.exe`,
msi → `.msi`).

### GitHub ile derleme (bilgisayarınıza hiçbir araç kurmadan)

Depoda `.github/workflows/build.yml` bulunur. Projeyi (veya zip'ini) depoya
gönderdiğinizde GitHub'ın Windows sunucuları derlemeyi yapar ve kurulum
dosyalarını **Actions → çalıştırma → Artifacts** altında sunar.

---

## Geri yükleme sırası

Gecikmeler **Ayrıntılar → Geri yükleme zamanlaması** sekmesinden ayarlanabilir.

1. Teams başlatılır.
2. Uygulama durur ve oturum açmanızı bekler → **Devam**.
3. Teams bağlantıları açılır.
4. Uygulamalar başlatılır.
5. Chrome pencereleri açılır.
6. Chrome sekmeleri geri yüklenir.
7. Pencere konumları ve boyutları uygulanır.

---

## Mimari

| Katman | Dosya | Görev |
| --- | --- | --- |
| Veri modeli | `src-tauri/src/model.rs` | `workspace.json` şeması |
| Monitör/pencere tarama | `src-tauri/src/win/enumerate.rs` | `EnumDisplayMonitors`, `EnumWindows`, `GetWindowPlacement` |
| Yerleştirme motoru | `src-tauri/src/win/placement.rs` | `ShellExecuteExW`, `SetWindowPos`, `ShowWindow`, düzen çevirisi |
| Geri yükleme akışı | `src-tauri/src/restore.rs` | sıralı adımlar, ilerleme olayları, Teams kapısı |
| Chrome köprüsü | `src-tauri/src/chrome_bridge.rs` | `127.0.0.1:47615` yerel HTTP |
| Depolama | `src-tauri/src/storage.rs` | çalışma alanı dosyaları, içe/dışa aktarma |
| Arayüz | `src/` | React + TypeScript (Türkçe) |
| Eklenti | `chrome-extension/` | MV3 hizmet çalışanı (Türkçe) |

### Çift monitör ve farklı çözünürlük

Kaydedilen monitör düzeni ile geçerli düzen farklıysa
`placement.rs::translate_geometry()` pencere konumunu ve boyutunu oransal
olarak yeniden hesaplar ve pencerenin ekran dışında kalmamasını sağlar.

### Chrome profilleri

Chrome, profil dizini adını eklentilere açmaz; bu nedenle `profile` alanı boş
kalır. Birden çok pencere ve oturum yine de ayrı ayrı kaydedilip geri yüklenir.

---

## Güvenlik

- Parola, çerez veya oturum anahtarı **saklanmaz**.
- Oturum açma **otomatikleştirilmez ve atlatılmaz** (Teams dâhil).
- Köprü yalnızca `127.0.0.1` üzerinde dinler; veri bilgisayardan çıkmaz.
- Saklananlar: uygulama yolları, pencere/monitör düzeni, adresler, Teams
  bağlantıları ve seçenekleriniz.
