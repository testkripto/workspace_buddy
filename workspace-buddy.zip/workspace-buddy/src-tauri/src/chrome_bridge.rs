//! Local bridge between the desktop app and the Chrome companion extension.
//!
//! A desktop app cannot read Chrome tabs directly, so a small HTTP server runs
//! on `127.0.0.1` and the extension talks to it. The protocol is deliberately
//! simple polling — no websockets, no persistent auth — because all data is
//! non-sensitive (URLs and window bounds only).
//!
//! ## One instance per Chrome profile
//!
//! Chrome runs a separate copy of an extension in every profile, and never lets
//! one profile see another's windows. So "capture every open Chrome session"
//! means several extension instances reporting in at once, and the bridge has
//! to **merge** them. Each instance generates a `client_id` once and keeps it in
//! `chrome.storage.local`; captures and restores are keyed by it.
//!
//! Endpoints (all JSON):
//!   GET  /health                     -> `{ ok, version }`
//!   GET  /capture-request?client=ID  -> `{ capture: bool }`   (extension polls)
//!   POST /state                      <- extension pushes its windows/tabs
//!   GET  /pending-restore?client=ID  -> windows this profile should open
//!   POST /restored                   <- extension reports what it opened
//!
//! Binds to a loopback address only, so it is never reachable off-machine.

use crate::model::{ChromeProfile, ChromeState, ChromeWindow};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::io::{BufRead, BufReader, Read, Write};
use std::net::{Ipv4Addr, TcpListener, TcpStream};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};

/// Fixed loopback port. Chosen in the dynamic/private range and matched by the
/// extension. If it is busy the server reports the error to the UI so the user
/// can free the port.
pub const BRIDGE_PORT: u16 = 47615;

/// An extension instance is considered gone if it has not polled for this long.
/// It polls every 1.5 s; the slack covers Chrome suspending the MV3 service
/// worker and its keepalive alarm bringing it back.
const CLIENT_TTL: Duration = Duration::from_secs(20);

/// What one extension instance pushes to `/state`.
#[derive(Debug, Clone, Deserialize)]
pub struct ClientCapture {
    pub client_id: String,
    #[serde(default)]
    pub label: String,
    #[serde(default)]
    pub incognito_allowed: bool,
    #[serde(default)]
    pub windows: Vec<ChromeWindow>,
}

/// What one extension instance reports back after a restore.
#[derive(Debug, Clone, Deserialize)]
pub struct RestoreReport {
    pub client_id: String,
    #[serde(default)]
    pub opened: usize,
    #[serde(default)]
    pub failed: usize,
    #[serde(default)]
    pub errors: Vec<String>,
}

#[derive(Debug, Clone, Serialize)]
struct PendingPayload {
    windows: Vec<ChromeWindow>,
}

#[derive(Debug, Clone)]
struct Client {
    label: String,
    incognito_allowed: bool,
    last_seen: Instant,
}

/// Shared state between the HTTP server and the rest of the app.
#[derive(Default)]
pub struct BridgeState {
    /// Extension instances currently polling us, keyed by client id.
    clients: HashMap<String, Client>,
    /// Latest snapshot from each instance.
    captures: HashMap<String, ClientCapture>,
    /// Instances we are waiting on for a fresh capture.
    capture_wanted: HashMap<String, bool>,
    /// Windows queued for each instance to open.
    pending_restore: HashMap<String, Vec<ChromeWindow>>,
    /// Restore results, keyed by client id.
    restore_reports: HashMap<String, RestoreReport>,
}

pub type SharedBridge = Arc<Mutex<BridgeState>>;

pub fn new_shared() -> SharedBridge {
    Arc::new(Mutex::new(BridgeState::default()))
}

impl BridgeState {
    fn touch(&mut self, client_id: &str, label: Option<&str>, incognito: Option<bool>) {
        if client_id.is_empty() {
            return;
        }
        let e = self.clients.entry(client_id.to_string()).or_insert(Client {
            label: String::new(),
            incognito_allowed: false,
            last_seen: Instant::now(),
        });
        e.last_seen = Instant::now();
        if let Some(l) = label {
            if !l.is_empty() {
                e.label = l.to_string();
            }
        }
        if let Some(i) = incognito {
            e.incognito_allowed = i;
        }
    }

    fn live_clients(&self) -> Vec<String> {
        let now = Instant::now();
        let mut v: Vec<String> = self
            .clients
            .iter()
            .filter(|(_, c)| now.duration_since(c.last_seen) < CLIENT_TTL)
            .map(|(id, _)| id.clone())
            .collect();
        v.sort();
        v
    }
}

/// Start the bridge server on a background thread. Returns immediately.
pub fn start(shared: SharedBridge) -> Result<(), String> {
    let listener = TcpListener::bind((Ipv4Addr::LOCALHOST, BRIDGE_PORT))
        .map_err(|e| format!("could not bind bridge port {BRIDGE_PORT}: {e}"))?;

    thread::spawn(move || {
        for stream in listener.incoming() {
            match stream {
                Ok(s) => {
                    let shared = shared.clone();
                    thread::spawn(move || {
                        let _ = handle_client(s, shared);
                    });
                }
                Err(_) => continue,
            }
        }
    });

    Ok(())
}

fn handle_client(stream: TcpStream, shared: SharedBridge) -> std::io::Result<()> {
    stream.set_read_timeout(Some(Duration::from_secs(10)))?;
    let mut reader = BufReader::new(stream.try_clone()?);
    let mut out = stream;

    // --- request line ---
    let mut line = String::new();
    if reader.read_line(&mut line)? == 0 {
        return Ok(());
    }
    let mut parts = line.split_whitespace();
    let method = parts.next().unwrap_or("").to_string();
    let target = parts.next().unwrap_or("").to_string();

    // --- headers ---
    let mut content_length: usize = 0;
    loop {
        let mut h = String::new();
        if reader.read_line(&mut h)? == 0 {
            break;
        }
        let h = h.trim_end();
        if h.is_empty() {
            break;
        }
        if let Some(v) = h.split_once(':') {
            if v.0.trim().eq_ignore_ascii_case("content-length") {
                content_length = v.1.trim().parse().unwrap_or(0);
            }
        }
    }

    // --- body ---
    //
    // This used to be a single `read()` into an 8 KB buffer. A capture of a
    // couple of dozen tabs comfortably exceeds 8 KB, so the JSON arrived
    // truncated, failed to parse, and the whole Chrome capture silently came
    // back empty. Read exactly Content-Length bytes.
    let mut body = Vec::new();
    if content_length > 0 {
        // 32 MB ceiling: this is loopback-only, but an unbounded allocation
        // driven by a header is still a bad idea.
        let capped = content_length.min(32 * 1024 * 1024);
        body.resize(capped, 0);
        reader.read_exact(&mut body)?;
    }
    let body = String::from_utf8_lossy(&body).to_string();

    if method == "OPTIONS" {
        return write_response(&mut out, 204, "", "text/plain");
    }

    let (path, query) = match target.split_once('?') {
        Some((p, q)) => (p.to_string(), q.to_string()),
        None => (target.clone(), String::new()),
    };

    let (status, content) = route(&method, &path, &query, &body, &shared);
    write_response(&mut out, status, &content, "application/json")
}

fn query_param(query: &str, key: &str) -> String {
    for pair in query.split('&') {
        if let Some((k, v)) = pair.split_once('=') {
            if k == key {
                return url_decode(v);
            }
        }
    }
    String::new()
}

fn url_decode(s: &str) -> String {
    let b = s.as_bytes();
    let mut out = Vec::with_capacity(b.len());
    let mut i = 0;
    while i < b.len() {
        match b[i] {
            b'%' if i + 2 < b.len() => {
                let hex = std::str::from_utf8(&b[i + 1..i + 3]).unwrap_or("");
                match u8::from_str_radix(hex, 16) {
                    Ok(v) => {
                        out.push(v);
                        i += 3;
                    }
                    Err(_) => {
                        out.push(b[i]);
                        i += 1;
                    }
                }
            }
            b'+' => {
                out.push(b' ');
                i += 1;
            }
            c => {
                out.push(c);
                i += 1;
            }
        }
    }
    String::from_utf8_lossy(&out).to_string()
}

fn route(
    method: &str,
    path: &str,
    query: &str,
    body: &str,
    shared: &SharedBridge,
) -> (u16, String) {
    match (method, path) {
        ("GET", "/health") => (
            200,
            format!(
                "{{\"ok\":true,\"version\":\"{}\"}}",
                env!("CARGO_PKG_VERSION")
            ),
        ),

        ("GET", "/capture-request") => {
            let client = query_param(query, "client");
            let label = query_param(query, "label");
            let mut b = shared.lock().unwrap();
            b.touch(&client, Some(&label), None);
            let want = *b.capture_wanted.get(&client).unwrap_or(&false);
            (200, format!("{{\"capture\":{want}}}"))
        }

        ("POST", "/state") => match serde_json::from_str::<ClientCapture>(body) {
            Ok(cap) => {
                let mut b = shared.lock().unwrap();
                b.touch(
                    &cap.client_id,
                    Some(&cap.label),
                    Some(cap.incognito_allowed),
                );
                b.capture_wanted.insert(cap.client_id.clone(), false);
                b.captures.insert(cap.client_id.clone(), cap);
                (200, "{\"ok\":true}".to_string())
            }
            Err(e) => (
                400,
                format!("{{\"ok\":false,\"error\":\"{}\"}}", escape(&e.to_string())),
            ),
        },

        ("GET", "/pending-restore") => {
            let client = query_param(query, "client");
            let mut b = shared.lock().unwrap();
            b.touch(&client, None, None);
            match b.pending_restore.remove(&client) {
                Some(windows) => (
                    200,
                    serde_json::to_string(&PendingPayload { windows })
                        .unwrap_or_else(|_| "null".into()),
                ),
                None => (200, "null".to_string()),
            }
        }

        ("POST", "/restored") => match serde_json::from_str::<RestoreReport>(body) {
            Ok(rep) => {
                let mut b = shared.lock().unwrap();
                b.touch(&rep.client_id, None, None);
                b.restore_reports.insert(rep.client_id.clone(), rep);
                (200, "{\"ok\":true}".to_string())
            }
            Err(e) => (
                400,
                format!("{{\"ok\":false,\"error\":\"{}\"}}", escape(&e.to_string())),
            ),
        },

        _ => (404, "{\"ok\":false,\"error\":\"not found\"}".to_string()),
    }
}

// ---------------------------------------------------------------------------
// App-facing API
// ---------------------------------------------------------------------------

/// Ask every connected Chrome profile for a fresh capture and merge the
/// answers into a single [`ChromeState`].
pub fn request_capture(shared: &SharedBridge, timeout_ms: u64) -> Option<ChromeState> {
    let expect: Vec<String> = {
        let mut b = shared.lock().unwrap();
        let live = b.live_clients();
        if live.is_empty() {
            return None;
        }
        for id in &live {
            b.capture_wanted.insert(id.clone(), true);
            b.captures.remove(id);
        }
        live
    };

    let deadline = Instant::now() + Duration::from_millis(timeout_ms);
    loop {
        {
            let b = shared.lock().unwrap();
            let all_in = expect.iter().all(|id| b.captures.contains_key(id));
            if all_in || Instant::now() >= deadline {
                let state = merge_captures(&b, &expect);
                drop(b);
                let mut b = shared.lock().unwrap();
                for id in &expect {
                    b.capture_wanted.insert(id.clone(), false);
                }
                return if state.windows.is_empty() && state.profiles.is_empty() {
                    None
                } else {
                    Some(state)
                };
            }
        }
        thread::sleep(Duration::from_millis(120));
    }
}

fn merge_captures(b: &BridgeState, expect: &[String]) -> ChromeState {
    let mut profiles = Vec::new();
    let mut windows = Vec::new();

    for id in expect {
        let Some(cap) = b.captures.get(id) else {
            continue;
        };
        let incog = cap.windows.iter().filter(|w| w.incognito).count();
        profiles.push(ChromeProfile {
            client_id: cap.client_id.clone(),
            label: if cap.label.is_empty() {
                format!("Chrome profili {}", profiles.len() + 1)
            } else {
                cap.label.clone()
            },
            incognito_allowed: cap.incognito_allowed,
            window_count: cap.windows.len(),
            incognito_window_count: incog,
        });
        for w in &cap.windows {
            let mut w = w.clone();
            w.client_id = cap.client_id.clone();
            if w.profile.is_none() && !cap.label.is_empty() {
                w.profile = Some(cap.label.clone());
            }
            windows.push(w);
        }
    }

    ChromeState {
        captured: !profiles.is_empty(),
        incognito_allowed: !profiles.is_empty() && profiles.iter().all(|p| p.incognito_allowed),
        profiles,
        windows,
    }
}

/// Which Chrome profiles are polling us right now.
pub fn connected_clients(shared: &SharedBridge) -> Vec<(String, String, bool)> {
    let b = shared.lock().unwrap();
    let now = Instant::now();
    let mut v: Vec<(String, String, bool)> = b
        .clients
        .iter()
        .filter(|(_, c)| now.duration_since(c.last_seen) < CLIENT_TTL)
        .map(|(id, c)| (id.clone(), c.label.clone(), c.incognito_allowed))
        .collect();
    v.sort_by(|a, b| a.1.cmp(&b.1));
    v
}

/// Queue saved windows for the extension instances to open.
///
/// Windows are routed back to the profile they were captured from. If that
/// profile is not running (or the file predates per-profile capture), they go
/// to the first connected profile instead, so nothing is silently dropped.
///
/// Returns the client ids we expect a report from.
pub fn queue_restore(shared: &SharedBridge, state: &ChromeState) -> Vec<String> {
    let mut b = shared.lock().unwrap();
    let live = b.live_clients();
    if live.is_empty() {
        return Vec::new();
    }
    let fallback = live[0].clone();

    b.restore_reports.clear();
    b.pending_restore.clear();

    let mut targets: Vec<String> = Vec::new();
    for w in &state.windows {
        let target = if !w.client_id.is_empty() && live.contains(&w.client_id) {
            w.client_id.clone()
        } else {
            fallback.clone()
        };
        b.pending_restore
            .entry(target.clone())
            .or_default()
            .push(w.clone());
        if !targets.contains(&target) {
            targets.push(target);
        }
    }
    targets
}

/// Block until every expected profile has reported its restore result, or the
/// timeout expires. Returns `(opened, failed, errors)`.
pub fn await_restore_reports(
    shared: &SharedBridge,
    expect: &[String],
    timeout_ms: u64,
) -> (usize, usize, Vec<String>) {
    let deadline = Instant::now() + Duration::from_millis(timeout_ms);
    loop {
        {
            let b = shared.lock().unwrap();
            let all_in = expect.iter().all(|id| b.restore_reports.contains_key(id));
            if all_in || Instant::now() >= deadline {
                let mut opened = 0;
                let mut failed = 0;
                let mut errors = Vec::new();
                for id in expect {
                    match b.restore_reports.get(id) {
                        Some(r) => {
                            opened += r.opened;
                            failed += r.failed;
                            errors.extend(r.errors.iter().cloned());
                        }
                        None => errors.push(
                            "Bir Chrome profili zamanında yanıt vermedi.".to_string(),
                        ),
                    }
                }
                return (opened, failed, errors);
            }
        }
        thread::sleep(Duration::from_millis(150));
    }
}

/// True when at least one extension instance has polled us recently.
///
/// This used to latch to `true` forever after the first poll, so the UI kept
/// claiming Chrome was connected long after the browser had been closed.
pub fn is_connected(shared: &SharedBridge) -> bool {
    !shared.lock().unwrap().live_clients().is_empty()
}

/// Wait (briefly) for an extension instance to appear — used right after we
/// launch Chrome ourselves.
pub fn wait_for_connection(shared: &SharedBridge, timeout_ms: u64) -> bool {
    let deadline = Instant::now() + Duration::from_millis(timeout_ms);
    loop {
        if is_connected(shared) {
            return true;
        }
        if Instant::now() >= deadline {
            return false;
        }
        thread::sleep(Duration::from_millis(250));
    }
}

// --- tiny HTTP helpers (no external framework needed for loopback JSON) ---

fn write_response(
    stream: &mut TcpStream,
    status: u16,
    body: &str,
    content_type: &str,
) -> std::io::Result<()> {
    let reason = match status {
        200 => "OK",
        204 => "No Content",
        400 => "Bad Request",
        404 => "Not Found",
        _ => "OK",
    };
    // Allow the extension origin. Chrome extensions send Origin
    // `chrome-extension://<id>`; we allow all origins because the server is
    // loopback-only and carries no secrets.
    let response = format!(
        "HTTP/1.1 {status} {reason}\r\n\
         Content-Type: {content_type}\r\n\
         Content-Length: {len}\r\n\
         Access-Control-Allow-Origin: *\r\n\
         Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n\
         Access-Control-Allow-Headers: Content-Type\r\n\
         Connection: close\r\n\r\n{body}",
        len = body.len(),
    );
    stream.write_all(response.as_bytes())?;
    stream.flush()
}

fn escape(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"")
}
