//! Local bridge between the desktop app and the Chrome companion extension.
//!
//! A desktop app cannot read Chrome tabs directly, so a small HTTP server runs
//! on `127.0.0.1` and the extension talks to it. The protocol is deliberately
//! simple polling — no websockets, no persistent auth — because all data is
//! non-sensitive (URLs and window bounds only).
//!
//! Endpoints (all JSON):
//!   GET  /health              -> `{ "ok": true, "version": "..." }`
//!   GET  /capture-request     -> `{ "capture": <bool> }`  (extension polls)
//!   POST /state               <- extension pushes current Chrome windows/tabs
//!   GET  /pending-restore      -> chrome state queued for the extension to open
//!
//! Binds to a loopback address only, so it is never reachable off-machine.

use crate::model::ChromeState;
use std::io::{Read, Write};
use std::net::{Ipv4Addr, TcpListener, TcpStream};
use std::sync::{Arc, Mutex};
use std::thread;

/// Fixed loopback port. Chosen in the dynamic/private range and matched by the
/// extension. If it is busy the server reports the error to the UI so the user
/// can free the port.
pub const BRIDGE_PORT: u16 = 47615;

/// Shared state between the HTTP server and the rest of the app.
#[derive(Default)]
pub struct BridgeState {
    /// Latest Chrome snapshot pushed by the extension.
    pub last_capture: Option<ChromeState>,
    /// True when the desktop app has asked the extension for a fresh capture.
    pub capture_requested: bool,
    /// Chrome state waiting to be opened by the extension, if any.
    pub pending_restore: Option<ChromeState>,
    /// Whether the extension has contacted us recently.
    pub extension_connected: bool,
}

pub type SharedBridge = Arc<Mutex<BridgeState>>;

pub fn new_shared() -> SharedBridge {
    Arc::new(Mutex::new(BridgeState::default()))
}

/// Start the bridge server on a background thread. Returns immediately.
pub fn start(shared: SharedBridge) -> Result<(), String> {
    let listener = TcpListener::bind((Ipv4Addr::LOCALHOST, BRIDGE_PORT))
        .map_err(|e| format!("could not bind bridge port {BRIDGE_PORT}: {e}"))?;

    thread::spawn(move || {
        for stream in listener.incoming() {
            match stream {
                Ok(s) => {
                    let shared = shared.clone();
                    thread::spawn(move || {
                        let _ = handle_client(s, shared);
                    });
                }
                Err(_) => continue,
            }
        }
    });

    Ok(())
}

fn handle_client(mut stream: TcpStream, shared: SharedBridge) -> std::io::Result<()> {
    let mut buf = [0u8; 8192];
    let n = stream.read(&mut buf)?;
    let raw = String::from_utf8_lossy(&buf[..n]);

    let (method, path, body) = parse_request(&raw);

    // Preflight support so the extension's fetch() calls are allowed.
    if method == "OPTIONS" {
        return write_response(&mut stream, 204, "", "text/plain");
    }

    let (status, content) = route(&method, &path, body, &shared);
    write_response(&mut stream, status, &content, "application/json")
}

fn route(method: &str, path: &str, body: &str, shared: &SharedBridge) -> (u16, String) {
    match (method, path) {
        ("GET", "/health") => {
            let mut b = shared.lock().unwrap();
            b.extension_connected = true;
            (200, format!("{{\"ok\":true,\"version\":\"{}\"}}", env!("CARGO_PKG_VERSION")))
        }
        ("GET", "/capture-request") => {
            let b = shared.lock().unwrap();
            (200, format!("{{\"capture\":{}}}", b.capture_requested))
        }
        ("POST", "/state") => {
            match serde_json::from_str::<ChromeState>(body) {
                Ok(mut state) => {
                    state.captured = true;
                    let mut b = shared.lock().unwrap();
                    b.last_capture = Some(state);
                    b.capture_requested = false;
                    b.extension_connected = true;
                    (200, "{\"ok\":true}".to_string())
                }
                Err(e) => (400, format!("{{\"ok\":false,\"error\":\"{}\"}}", escape(&e.to_string()))),
            }
        }
        ("GET", "/pending-restore") => {
            let mut b = shared.lock().unwrap();
            b.extension_connected = true;
            match b.pending_restore.take() {
                Some(state) => (
                    200,
                    serde_json::to_string(&state).unwrap_or_else(|_| "null".into()),
                ),
                None => (200, "null".to_string()),
            }
        }
        _ => (404, "{\"ok\":false,\"error\":\"not found\"}".to_string()),
    }
}

/// Ask the extension for a fresh capture and wait (briefly) for it to arrive.
pub fn request_capture(shared: &SharedBridge, timeout_ms: u64) -> Option<ChromeState> {
    {
        let mut b = shared.lock().unwrap();
        b.capture_requested = true;
        b.last_capture = None;
    }

    let deadline = std::time::Instant::now() + std::time::Duration::from_millis(timeout_ms);
    loop {
        {
            let b = shared.lock().unwrap();
            if let Some(state) = &b.last_capture {
                return Some(state.clone());
            }
        }
        if std::time::Instant::now() >= deadline {
            let mut b = shared.lock().unwrap();
            b.capture_requested = false;
            return None;
        }
        thread::sleep(std::time::Duration::from_millis(150));
    }
}

/// Queue Chrome state for the extension to open on its next poll.
pub fn queue_restore(shared: &SharedBridge, state: ChromeState) {
    let mut b = shared.lock().unwrap();
    b.pending_restore = Some(state);
}

pub fn is_connected(shared: &SharedBridge) -> bool {
    shared.lock().unwrap().extension_connected
}

// --- tiny HTTP helpers (no external framework needed for loopback JSON) ---

fn parse_request(raw: &str) -> (String, String, &str) {
    let mut lines = raw.split("\r\n");
    let request_line = lines.next().unwrap_or("");
    let mut parts = request_line.split_whitespace();
    let method = parts.next().unwrap_or("").to_string();
    let path = parts.next().unwrap_or("").to_string();
    let body = raw.split("\r\n\r\n").nth(1).unwrap_or("");
    (method, path, body)
}

fn write_response(
    stream: &mut TcpStream,
    status: u16,
    body: &str,
    content_type: &str,
) -> std::io::Result<()> {
    let reason = match status {
        200 => "OK",
        204 => "No Content",
        400 => "Bad Request",
        404 => "Not Found",
        _ => "OK",
    };
    // Allow the extension origin. Chrome extensions send Origin
    // `chrome-extension://<id>`; we allow all origins because the server is
    // loopback-only and carries no secrets.
    let response = format!(
        "HTTP/1.1 {status} {reason}\r\n\
         Content-Type: {content_type}\r\n\
         Content-Length: {len}\r\n\
         Access-Control-Allow-Origin: *\r\n\
         Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n\
         Access-Control-Allow-Headers: Content-Type\r\n\
         Connection: close\r\n\r\n{body}",
        len = body.len(),
    );
    stream.write_all(response.as_bytes())?;
    stream.flush()
}

fn escape(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"")
}
