//! Data model for the Workspace Buddy portable workspace file.
//!
//! The on-disk representation is `workspace.json`. Everything here is plain
//! data: paths, window geometry, URLs and user-authored configuration. No
//! passwords, tokens or session material are ever represented in this model.

use serde::{Deserialize, Serialize};

/// Current schema version. Bump when the format changes in a breaking way so
/// that importers can migrate or warn.
pub const SCHEMA_VERSION: u32 = 1;

/// A complete saved workspace.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Workspace {
    /// Schema version of the file. Defaults to the current version when absent.
    #[serde(default = "default_schema_version")]
    pub schema_version: u32,

    /// Human-friendly name, e.g. "Morning Work".
    pub name: String,

    /// Unix millisecond timestamp of when this workspace was saved.
    #[serde(default)]
    pub saved_at: i64,

    /// Snapshot of the monitor layout at save time. Used by the placement
    /// engine to translate coordinates when the current layout differs.
    #[serde(default)]
    pub monitors: Vec<MonitorInfo>,

    /// Regular desktop applications with their windows.
    #[serde(default)]
    pub apps: Vec<AppEntry>,

    /// Microsoft Teams deep links to open after the user has authenticated.
    #[serde(default)]
    pub teams: Vec<TeamsLink>,

    /// Chrome state captured by the companion extension.
    #[serde(default)]
    pub chrome: ChromeState,

    /// Per-workspace restore tuning (delays, toggles).
    #[serde(default)]
    pub restore_options: RestoreOptions,
}

fn default_schema_version() -> u32 {
    SCHEMA_VERSION
}

impl Workspace {
    pub fn new(name: impl Into<String>) -> Self {
        Self {
            schema_version: SCHEMA_VERSION,
            name: name.into(),
            saved_at: 0,
            monitors: Vec::new(),
            apps: Vec::new(),
            teams: Vec::new(),
            chrome: ChromeState::default(),
            restore_options: RestoreOptions::default(),
        }
    }
}

/// A single monitor as reported by the OS.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MonitorInfo {
    /// 1-based index assigned by the enumerator (stable within a single
    /// enumeration pass, ordered by the virtual-desktop coordinates).
    pub number: u32,
    /// Whether this is the primary monitor.
    pub is_primary: bool,
    /// Bounding rectangle in virtual-desktop coordinates.
    pub x: i32,
    pub y: i32,
    pub width: i32,
    pub height: i32,
    /// Work area (excludes taskbar) in virtual-desktop coordinates.
    pub work_x: i32,
    pub work_y: i32,
    pub work_width: i32,
    pub work_height: i32,
}

/// Window placement state.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum WindowState {
    Normal,
    Maximized,
    Minimized,
}

impl Default for WindowState {
    fn default() -> Self {
        WindowState::Normal
    }
}

/// Geometry + state for one top-level window.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WindowGeometry {
    pub title: String,
    /// Normal-position rectangle (restored size), in virtual-desktop coords.
    pub x: i32,
    pub y: i32,
    pub width: i32,
    pub height: i32,
    /// 1-based monitor number the window primarily occupies.
    pub monitor: u32,
    pub state: WindowState,
}

/// A regular application detected at save time.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppEntry {
    /// Full path to the executable, e.g. `C:\\Program Files\\...\\Code.exe`.
    pub exe_path: String,
    /// Process image name, e.g. `Code.exe`.
    pub process_name: String,
    /// All top-level windows that belonged to this executable.
    pub windows: Vec<WindowGeometry>,
    /// If true, the restore engine will not re-launch this app (used for
    /// apps the user wants positioned but not started, or shell processes).
    #[serde(default)]
    pub skip_launch: bool,
}

/// A Microsoft Teams deep link the user chose to save.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TeamsLink {
    pub id: String,
    /// Friendly name, e.g. "Project Alpha Channel".
    pub name: String,
    /// Deep link URL. Either an `https://teams.microsoft.com/l/...` link or a
    /// `msteams:` protocol link.
    pub url: String,
}

/// Chrome state captured by the extension.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ChromeState {
    /// True once the extension has ever pushed data for this workspace.
    #[serde(default)]
    pub captured: bool,
    /// Whether the extension is permitted to see incognito windows. When false,
    /// Chrome hides incognito windows from the extension entirely.
    #[serde(default)]
    pub incognito_allowed: bool,
    #[serde(default)]
    pub windows: Vec<ChromeWindow>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChromeWindow {
    /// Chrome profile directory name (e.g. "Default", "Profile 1") if the
    /// extension could determine it, else null.
    #[serde(default)]
    pub profile: Option<String>,
    #[serde(default)]
    pub incognito: bool,
    #[serde(default)]
    pub focused: bool,
    /// Window bounds as reported by chrome.windows (screen coordinates).
    #[serde(default)]
    pub left: Option<i32>,
    #[serde(default)]
    pub top: Option<i32>,
    #[serde(default)]
    pub width: Option<i32>,
    #[serde(default)]
    pub height: Option<i32>,
    #[serde(default)]
    pub state: Option<String>,
    #[serde(default)]
    pub tabs: Vec<ChromeTab>,
    /// Tab groups (Chrome's grouped tabs), keyed by group id.
    #[serde(default)]
    pub groups: Vec<ChromeGroup>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChromeTab {
    pub url: String,
    #[serde(default)]
    pub title: Option<String>,
    #[serde(default)]
    pub pinned: bool,
    /// Chrome tab group id this tab belongs to, or -1 when ungrouped.
    #[serde(default)]
    pub group_id: i64,
    #[serde(default)]
    pub active: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChromeGroup {
    pub id: i64,
    #[serde(default)]
    pub title: Option<String>,
    #[serde(default)]
    pub color: Option<String>,
    #[serde(default)]
    pub collapsed: bool,
}

/// Restore tuning knobs. Delays are in milliseconds.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RestoreOptions {
    pub launch_teams: bool,
    pub open_teams_links: bool,
    pub launch_apps: bool,
    pub restore_chrome: bool,
    pub restore_positions: bool,
    /// Delay after launching Teams before opening links (post-confirmation).
    pub teams_link_delay_ms: u64,
    /// Delay between launching each regular application.
    pub app_launch_delay_ms: u64,
    /// Time to wait for a launched app's window to appear before giving up.
    pub window_wait_timeout_ms: u64,
    /// Delay before the final positioning pass, letting windows settle.
    pub position_settle_delay_ms: u64,
}

impl Default for RestoreOptions {
    fn default() -> Self {
        Self {
            launch_teams: true,
            open_teams_links: true,
            launch_apps: true,
            restore_chrome: true,
            restore_positions: true,
            teams_link_delay_ms: 1500,
            app_launch_delay_ms: 800,
            window_wait_timeout_ms: 15000,
            position_settle_delay_ms: 1200,
        }
    }
}
