//! Data model for the Workspace Buddy portable workspace file.
//!
//! The on-disk representation is `workspace.json`. Everything here is plain
//! data: paths, window geometry, URLs and user-authored configuration. No
//! passwords, tokens or session material are ever represented in this model.

use serde::{Deserialize, Serialize};

/// Current schema version.
///
/// v2 changes (breaking for geometry, forward-compatible for readers):
///  * `WindowGeometry` coordinates are now true **screen** coordinates. v1 wrote
///    raw `WINDOWPLACEMENT` "workspace" coordinates, which are offset by the
///    primary monitor's work-area origin — that was the cause of windows
///    drifting on restore.
///  * `MonitorInfo` carries a stable `device_id` so monitors are matched by
///    identity instead of by sort index.
///  * Chrome windows carry the profile (`client_id`) they came from, so several
///    signed-in Chrome profiles can be captured and restored independently.
pub const SCHEMA_VERSION: u32 = 2;

/// A complete saved workspace.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Workspace {
    /// Schema version of the file. Defaults to the current version when absent.
    #[serde(default = "default_schema_version")]
    pub schema_version: u32,

    /// Human-friendly name, e.g. "Morning Work".
    pub name: String,

    /// Unix millisecond timestamp of when this workspace was saved.
    #[serde(default)]
    pub saved_at: i64,

    /// Snapshot of the monitor layout at save time. Used by the placement
    /// engine to translate coordinates when the current layout differs.
    #[serde(default)]
    pub monitors: Vec<MonitorInfo>,

    /// Regular desktop applications with their windows.
    #[serde(default)]
    pub apps: Vec<AppEntry>,

    /// Microsoft Teams deep links to open after the user has authenticated.
    #[serde(default)]
    pub teams: Vec<TeamsLink>,

    /// Chrome state captured by the companion extension.
    #[serde(default)]
    pub chrome: ChromeState,

    /// Per-workspace restore tuning (delays, toggles).
    #[serde(default)]
    pub restore_options: RestoreOptions,
}

fn default_schema_version() -> u32 {
    SCHEMA_VERSION
}

impl Workspace {
    pub fn new(name: impl Into<String>) -> Self {
        Self {
            schema_version: SCHEMA_VERSION,
            name: name.into(),
            saved_at: 0,
            monitors: Vec::new(),
            apps: Vec::new(),
            teams: Vec::new(),
            chrome: ChromeState::default(),
            restore_options: RestoreOptions::default(),
        }
    }

    /// True when this file predates the screen-coordinate fix and its geometry
    /// therefore cannot be trusted for exact placement.
    pub fn geometry_is_legacy(&self) -> bool {
        self.schema_version < 2
    }
}

/// A single monitor as reported by the OS.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MonitorInfo {
    /// 1-based index assigned by the enumerator, ordered by virtual-desktop
    /// coordinates. Convenient for humans, but *not* stable across replugs —
    /// use `device_id` for matching.
    pub number: u32,
    /// GDI device name, e.g. `\\.\DISPLAY1`. Stable for as long as the display
    /// stays attached in the same port, which makes it a far better key than
    /// the positional index.
    #[serde(default)]
    pub device_id: String,
    /// Whether this is the primary monitor.
    pub is_primary: bool,
    /// Effective DPI of this monitor (96 = 100% scaling).
    #[serde(default = "default_dpi")]
    pub dpi: u32,
    /// Bounding rectangle in virtual-desktop coordinates.
    pub x: i32,
    pub y: i32,
    pub width: i32,
    pub height: i32,
    /// Work area (excludes taskbar) in virtual-desktop coordinates.
    pub work_x: i32,
    pub work_y: i32,
    pub work_width: i32,
    pub work_height: i32,
}

fn default_dpi() -> u32 {
    96
}

impl MonitorInfo {
    /// Same physical layout slot: identical device name *and* identical bounds.
    pub fn same_as(&self, other: &MonitorInfo) -> bool {
        self.x == other.x
            && self.y == other.y
            && self.width == other.width
            && self.height == other.height
            && (self.device_id.is_empty()
                || other.device_id.is_empty()
                || self.device_id == other.device_id)
    }
}

/// Window placement state.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum WindowState {
    Normal,
    Maximized,
    Minimized,
}

impl Default for WindowState {
    fn default() -> Self {
        WindowState::Normal
    }
}

/// Geometry + state for one top-level window.
///
/// `x/y/width/height` describe the **restored** ("normal") rectangle in true
/// screen coordinates, even when `state` is maximized or minimized — that is
/// what the user gets back when they un-maximize the window.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WindowGeometry {
    pub title: String,
    /// Win32 window class, e.g. `Chrome_WidgetWin_1`. Used to tell a real app
    /// window from a helper window of the same process at restore time.
    #[serde(default)]
    pub class_name: String,
    /// Restored-size rectangle in true screen coordinates.
    pub x: i32,
    pub y: i32,
    pub width: i32,
    pub height: i32,
    /// 1-based monitor number the window primarily occupies.
    pub monitor: u32,
    /// Device name of that monitor, for identity-based matching.
    #[serde(default)]
    pub monitor_device: String,
    pub state: WindowState,
    /// Position in top-down z-order at save time. Used as a tie-breaker when
    /// several windows of one app have interchangeable titles.
    #[serde(default)]
    pub z_order: u32,
}

/// A regular application detected at save time.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppEntry {
    /// Full path to the executable, e.g. `C:\\Program Files\\...\\Code.exe`.
    pub exe_path: String,
    /// Process image name, e.g. `Code.exe`.
    pub process_name: String,
    /// All top-level windows that belonged to this executable.
    pub windows: Vec<WindowGeometry>,
    /// If true, the restore engine will not re-launch this app (used for
    /// apps the user wants positioned but not started, or shell processes).
    #[serde(default)]
    pub skip_launch: bool,
    /// True for Chrome. Chrome windows are opened by the companion extension
    /// (only it can restore tabs and incognito), so the generic launcher must
    /// not start a second, empty Chrome alongside it. Positioning still happens
    /// through the Win32 engine, after the extension is done.
    #[serde(default)]
    pub is_browser: bool,
}

/// A Microsoft Teams deep link the user chose to save.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TeamsLink {
    pub id: String,
    /// Friendly name, e.g. "Project Alpha Channel".
    pub name: String,
    /// Deep link URL. Either an `https://teams.microsoft.com/l/...` link or a
    /// `msteams:` protocol link.
    pub url: String,
}

/// One Chrome profile that reported in. Chrome runs a separate extension
/// instance per profile and never lets one see another's windows, so each
/// profile is captured and restored on its own.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ChromeProfile {
    /// Random id the extension generated once and keeps in `chrome.storage`.
    pub client_id: String,
    /// Label shown in the UI, editable from the extension popup.
    #[serde(default)]
    pub label: String,
    /// Whether this profile's extension instance is allowed to see incognito
    /// windows. When false, Chrome hides them from the extension entirely.
    #[serde(default)]
    pub incognito_allowed: bool,
    #[serde(default)]
    pub window_count: usize,
    #[serde(default)]
    pub incognito_window_count: usize,
}

/// Chrome state captured by the extension(s).
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ChromeState {
    /// True once at least one extension instance has pushed data.
    #[serde(default)]
    pub captured: bool,
    /// True when *every* reporting profile had incognito access. Kept for
    /// backwards compatibility with v1 files.
    #[serde(default)]
    pub incognito_allowed: bool,
    /// One entry per Chrome profile that reported in.
    #[serde(default)]
    pub profiles: Vec<ChromeProfile>,
    #[serde(default)]
    pub windows: Vec<ChromeWindow>,
}

impl ChromeState {
    pub fn incognito_window_count(&self) -> usize {
        self.windows.iter().filter(|w| w.incognito).count()
    }
    pub fn tab_count(&self) -> usize {
        self.windows.iter().map(|w| w.tabs.len()).sum()
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChromeWindow {
    /// Which Chrome profile this window belongs to. Empty on v1 files.
    #[serde(default)]
    pub client_id: String,
    /// Human label of that profile at save time (for the UI only).
    #[serde(default)]
    pub profile: Option<String>,
    #[serde(default)]
    pub incognito: bool,
    #[serde(default)]
    pub focused: bool,
    /// Window bounds as reported by `chrome.windows` (Chrome's own DIP-ish
    /// screen coordinates). Used as a hint when the extension creates the
    /// window; the exact placement is done afterwards over Win32.
    #[serde(default)]
    pub left: Option<i32>,
    #[serde(default)]
    pub top: Option<i32>,
    #[serde(default)]
    pub width: Option<i32>,
    #[serde(default)]
    pub height: Option<i32>,
    #[serde(default)]
    pub state: Option<String>,
    /// Title of the active tab. This is what Chrome puts in the OS window
    /// title, so it is the link between a `chrome.windows` window and its HWND.
    #[serde(default)]
    pub active_tab_title: Option<String>,
    #[serde(default)]
    pub tabs: Vec<ChromeTab>,
    /// Tab groups (Chrome's grouped tabs).
    #[serde(default)]
    pub groups: Vec<ChromeGroup>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChromeTab {
    pub url: String,
    #[serde(default)]
    pub title: Option<String>,
    #[serde(default)]
    pub pinned: bool,
    /// Chrome tab group id this tab belongs to, or -1 when ungrouped.
    #[serde(default)]
    pub group_id: i64,
    #[serde(default)]
    pub active: bool,
    /// Tab index within its window, so ordering survives the round trip.
    #[serde(default)]
    pub index: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChromeGroup {
    pub id: i64,
    #[serde(default)]
    pub title: Option<String>,
    #[serde(default)]
    pub color: Option<String>,
    #[serde(default)]
    pub collapsed: bool,
}

/// Restore tuning knobs. Delays are in milliseconds.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RestoreOptions {
    #[serde(default = "yes")]
    pub launch_teams: bool,
    #[serde(default = "yes")]
    pub open_teams_links: bool,
    #[serde(default = "yes")]
    pub launch_apps: bool,
    #[serde(default = "yes")]
    pub restore_chrome: bool,
    #[serde(default = "yes")]
    pub restore_positions: bool,
    /// Delay after launching Teams before opening links (post-confirmation).
    #[serde(default = "d_teams_link")]
    pub teams_link_delay_ms: u64,
    /// Delay between launching each regular application.
    #[serde(default = "d_app_launch")]
    pub app_launch_delay_ms: u64,
    /// Time to wait for a launched app's window to appear before giving up.
    #[serde(default = "d_window_wait")]
    pub window_wait_timeout_ms: u64,
    /// Delay before the final positioning pass, letting windows settle.
    #[serde(default = "d_settle")]
    pub position_settle_delay_ms: u64,
    /// How long to wait for the Chrome extension to finish opening windows
    /// before moving on to the positioning pass.
    #[serde(default = "d_chrome_wait")]
    pub chrome_restore_timeout_ms: u64,
    /// How many times to re-apply geometry to a window that snapped back.
    /// Many apps (Electron, Office, Chrome) resize themselves once after
    /// their window first appears, so a single pass is not enough.
    #[serde(default = "d_retries")]
    pub position_retries: u32,
}

fn yes() -> bool {
    true
}
fn d_teams_link() -> u64 {
    1500
}
fn d_app_launch() -> u64 {
    800
}
fn d_window_wait() -> u64 {
    15000
}
fn d_settle() -> u64 {
    1500
}
fn d_chrome_wait() -> u64 {
    20000
}
fn d_retries() -> u32 {
    3
}

impl Default for RestoreOptions {
    fn default() -> Self {
        Self {
            launch_teams: true,
            open_teams_links: true,
            launch_apps: true,
            restore_chrome: true,
            restore_positions: true,
            teams_link_delay_ms: d_teams_link(),
            app_launch_delay_ms: d_app_launch(),
            window_wait_timeout_ms: d_window_wait(),
            position_settle_delay_ms: d_settle(),
            chrome_restore_timeout_ms: d_chrome_wait(),
            position_retries: d_retries(),
        }
    }
}

/// Executable names treated as Chrome (opened by the extension, not by us).
pub fn is_chrome_exe(process_name: &str) -> bool {
    process_name.eq_ignore_ascii_case("chrome.exe")
}
