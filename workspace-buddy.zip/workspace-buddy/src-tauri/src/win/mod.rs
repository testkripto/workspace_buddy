//! Windows-specific functionality: monitor/window enumeration and the window
//! placement engine. Everything in this module is guarded by `#[cfg(windows)]`
//! at the call sites so the crate still type-checks on other platforms during
//! development (the app itself targets Windows 10/11).

pub mod enumerate;
pub mod placement;

use windows::Win32::UI::HiDpi::{
    SetProcessDpiAwarenessContext, DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2,
};

/// Make the process per-monitor DPI aware so that all window coordinates we
/// read and write are in consistent physical pixels. Call once at startup,
/// before any window is created.
pub fn init_dpi_awareness() {
    unsafe {
        // Ignore the result: if a manifest already set awareness this fails
        // harmlessly, and the manifest value wins either way.
        let _ = SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
    }
}
