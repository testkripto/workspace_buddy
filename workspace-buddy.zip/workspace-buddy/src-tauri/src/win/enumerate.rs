//! Enumeration of monitors, top-level windows and their owning processes.
//!
//! All of this is read-only inspection of the current desktop using the Win32
//! API via the `windows` crate. Nothing here launches or modifies anything.
//!
//! ## The coordinate trap
//!
//! `GetWindowPlacement` fills `rcNormalPosition` in *workspace* coordinates,
//! not screen coordinates. Workspace coordinates are screen coordinates offset
//! by the origin of the **primary monitor's work area**. Microsoft's own docs
//! warn about this: feeding those numbers to `SetWindowPos` makes windows creep
//! by the taskbar's size on every save/restore round trip, and puts them on the
//! wrong monitor once the offset is large enough.
//!
//! Everything leaving this module is therefore converted to true screen
//! coordinates via [`workspace_origin`], and [`crate::win::placement`] converts
//! back when it needs to talk to `SetWindowPlacement`.

use crate::model::{AppEntry, MonitorInfo, WindowGeometry, WindowState};
use std::collections::HashMap;
use std::ffi::c_void;
use std::path::Path;

use windows::core::PWSTR;
use windows::Win32::Foundation::{BOOL, HWND, LPARAM, MAX_PATH, RECT, TRUE};
use windows::Win32::Graphics::Dwm::{DwmGetWindowAttribute, DWMWA_CLOAKED};
use windows::Win32::Graphics::Gdi::{
    EnumDisplayMonitors, GetMonitorInfoW, MonitorFromPoint, MonitorFromWindow, HDC, HMONITOR,
    MONITORINFO, MONITORINFOEXW, MONITOR_DEFAULTTONEAREST,
};
use windows::Win32::System::Threading::{
    OpenProcess, QueryFullProcessImageNameW, PROCESS_NAME_WIN32, PROCESS_QUERY_LIMITED_INFORMATION,
};
use windows::Win32::UI::HiDpi::{GetDpiForMonitor, MDT_EFFECTIVE_DPI};
use windows::Win32::UI::WindowsAndMessaging::{
    EnumWindows, GetClassNameW, GetWindow, GetWindowLongW, GetWindowPlacement, GetWindowTextLengthW,
    GetWindowTextW, GetWindowThreadProcessId, IsWindowVisible, SystemParametersInfoW, GWL_EXSTYLE,
    GWL_STYLE, GW_OWNER, SPI_GETWORKAREA, SW_SHOWMAXIMIZED, SW_SHOWMINIMIZED,
    SYSTEM_PARAMETERS_INFO_UPDATE_FLAGS, WINDOWPLACEMENT, WS_EX_TOOLWINDOW, WS_VISIBLE,
};

/// A live top-level application window, with everything needed to match it to
/// a saved [`WindowGeometry`].
#[derive(Debug, Clone)]
pub struct LiveWindow {
    pub hwnd: isize,
    pub pid: u32,
    pub title: String,
    pub class_name: String,
    pub exe_path: String,
    pub process_name: String,
    /// Index in top-down z-order at the time of enumeration.
    pub z_order: u32,
}

// ---------------------------------------------------------------------------
// Coordinate conversion
// ---------------------------------------------------------------------------

/// Origin of the primary monitor's work area, in screen coordinates.
///
/// This is the offset between `WINDOWPLACEMENT` workspace coordinates and real
/// screen coordinates. It is (0, 0) for the common "taskbar at the bottom"
/// setup, which is why this bug hides so well — it only appears once the
/// taskbar is docked left or top, or auto-hide is toggled.
pub fn workspace_origin() -> (i32, i32) {
    let mut rc = RECT::default();
    unsafe {
        let ok = SystemParametersInfoW(
            SPI_GETWORKAREA,
            0,
            Some(&mut rc as *mut RECT as *mut c_void),
            SYSTEM_PARAMETERS_INFO_UPDATE_FLAGS(0),
        );
        if ok.is_err() {
            return (0, 0);
        }
    }
    (rc.left, rc.top)
}

/// Workspace coordinates -> screen coordinates.
pub fn workspace_to_screen(rc: RECT) -> RECT {
    let (ox, oy) = workspace_origin();
    RECT {
        left: rc.left + ox,
        top: rc.top + oy,
        right: rc.right + ox,
        bottom: rc.bottom + oy,
    }
}

/// Screen coordinates -> workspace coordinates.
pub fn screen_to_workspace(rc: RECT) -> RECT {
    let (ox, oy) = workspace_origin();
    RECT {
        left: rc.left - ox,
        top: rc.top - oy,
        right: rc.right - ox,
        bottom: rc.bottom - oy,
    }
}

// ---------------------------------------------------------------------------
// Monitors
// ---------------------------------------------------------------------------

thread_local! {
    static COLLECTED_MONITORS: std::cell::RefCell<Vec<RawMonitor>> =
        std::cell::RefCell::new(Vec::new());
}

struct RawMonitor {
    rc: RECT,
    work: RECT,
    primary: bool,
    device: String,
    dpi: u32,
}

/// Enumerate all monitors in virtual-desktop coordinates.
///
/// Monitors are numbered 1..=N ordered left-to-right then top-to-bottom so the
/// numbering is stable and human-intuitive across saves. Matching at restore
/// time uses `device_id`, not this number.
pub fn enumerate_monitors() -> Vec<MonitorInfo> {
    COLLECTED_MONITORS.with(|c| c.borrow_mut().clear());

    unsafe {
        // Null HDC + null clip rect => enumerate every monitor on the desktop.
        let _ = EnumDisplayMonitors(HDC::default(), None, Some(monitor_enum_proc), LPARAM(0));
    }

    let mut raw: Vec<RawMonitor> = COLLECTED_MONITORS.with(|c| std::mem::take(&mut *c.borrow_mut()));

    // Stable ordering: by x, then y.
    raw.sort_by(|a, b| (a.rc.left, a.rc.top).cmp(&(b.rc.left, b.rc.top)));

    raw.into_iter()
        .enumerate()
        .map(|(i, m)| MonitorInfo {
            number: (i as u32) + 1,
            device_id: m.device,
            is_primary: m.primary,
            dpi: m.dpi,
            x: m.rc.left,
            y: m.rc.top,
            width: m.rc.right - m.rc.left,
            height: m.rc.bottom - m.rc.top,
            work_x: m.work.left,
            work_y: m.work.top,
            work_width: m.work.right - m.work.left,
            work_height: m.work.bottom - m.work.top,
        })
        .collect()
}

unsafe extern "system" fn monitor_enum_proc(
    hmonitor: HMONITOR,
    _hdc: HDC,
    _rect: *mut RECT,
    _lparam: LPARAM,
) -> BOOL {
    let mut info = MONITORINFOEXW::default();
    info.monitorInfo.cbSize = std::mem::size_of::<MONITORINFOEXW>() as u32;

    let ok = GetMonitorInfoW(hmonitor, &mut info as *mut MONITORINFOEXW as *mut MONITORINFO);
    if ok.as_bool() {
        let device = wide_to_string(&info.szDevice);

        let mut dpi_x: u32 = 96;
        let mut dpi_y: u32 = 96;
        let _ = GetDpiForMonitor(hmonitor, MDT_EFFECTIVE_DPI, &mut dpi_x, &mut dpi_y);

        COLLECTED_MONITORS.with(|c| {
            c.borrow_mut().push(RawMonitor {
                rc: info.monitorInfo.rcMonitor,
                work: info.monitorInfo.rcWork,
                // MONITORINFOF_PRIMARY (0x00000001) — defined inline to avoid
                // per-version differences in where the constant is exported.
                primary: (info.monitorInfo.dwFlags & 0x0000_0001) != 0,
                device,
                dpi: dpi_x,
            });
        });
    }
    TRUE
}

fn wide_to_string(buf: &[u16]) -> String {
    let end = buf.iter().position(|&c| c == 0).unwrap_or(buf.len());
    String::from_utf16_lossy(&buf[..end])
}

// ---------------------------------------------------------------------------
// Windows
// ---------------------------------------------------------------------------

thread_local! {
    static COLLECTED_WINDOWS: std::cell::RefCell<Vec<HWND>> =
        std::cell::RefCell::new(Vec::new());
}

/// Every live top-level app window on the desktop, in top-down z-order.
///
/// This is the single source of truth for "what counts as an app window". Save
/// and restore both go through it, so the two can never disagree about which
/// windows exist — an earlier version had two different predicates, and restore
/// happily resized invisible helper windows it had matched by accident.
pub fn enumerate_windows() -> Vec<LiveWindow> {
    COLLECTED_WINDOWS.with(|c| c.borrow_mut().clear());
    unsafe {
        let _ = EnumWindows(Some(window_enum_proc), LPARAM(0));
    }
    let hwnds: Vec<HWND> = COLLECTED_WINDOWS.with(|c| std::mem::take(&mut *c.borrow_mut()));

    let mut out = Vec::new();
    for (z, hwnd) in hwnds.into_iter().enumerate() {
        let mut pid: u32 = 0;
        unsafe { GetWindowThreadProcessId(hwnd, Some(&mut pid)) };
        if pid == 0 {
            continue;
        }
        let Some(exe_path) = process_image_path(pid) else {
            continue;
        };
        let process_name = Path::new(&exe_path)
            .file_name()
            .map(|s| s.to_string_lossy().to_string())
            .unwrap_or_else(|| exe_path.clone());

        // Never touch our own windows.
        if process_name.eq_ignore_ascii_case("workspace-buddy.exe") {
            continue;
        }

        out.push(LiveWindow {
            hwnd: hwnd.0 as isize,
            pid,
            title: window_title(hwnd),
            class_name: window_class(hwnd),
            exe_path,
            process_name,
            z_order: z as u32,
        });
    }
    out
}

/// Enumerate application windows and group them into [`AppEntry`] records.
pub fn enumerate_apps(monitors: &[MonitorInfo]) -> Vec<AppEntry> {
    let live = enumerate_windows();

    let mut by_exe: HashMap<String, AppEntry> = HashMap::new();
    for w in live {
        let Some(geometry) = geometry_of(w.hwnd, monitors, &w.title, &w.class_name, w.z_order)
        else {
            continue;
        };

        let is_browser = crate::model::is_chrome_exe(&w.process_name);
        let entry = by_exe
            .entry(w.exe_path.to_lowercase())
            .or_insert_with(|| AppEntry {
                exe_path: w.exe_path.clone(),
                process_name: w.process_name.clone(),
                windows: Vec::new(),
                // Chrome is launched by the extension path, the shell is never
                // relaunched at all.
                skip_launch: is_system_shell(&w.process_name),
                is_browser,
            });
        entry.windows.push(geometry);
    }

    let mut apps: Vec<AppEntry> = by_exe.into_values().collect();
    for a in &mut apps {
        a.windows.sort_by_key(|w| w.z_order);
    }
    apps.sort_by(|a, b| {
        a.process_name
            .to_lowercase()
            .cmp(&b.process_name.to_lowercase())
    });
    apps
}

/// Read the saved geometry of one live window, in true screen coordinates.
pub fn geometry_of(
    hwnd_raw: isize,
    monitors: &[MonitorInfo],
    title: &str,
    class_name: &str,
    z_order: u32,
) -> Option<WindowGeometry> {
    let hwnd = HWND(hwnd_raw as *mut _);
    unsafe {
        // Placement gives us both the restore rect and the show state, which is
        // more reliable than GetWindowRect for maximized windows (that returns
        // the maximized rect, losing the size the user actually chose).
        let mut placement = WINDOWPLACEMENT::default();
        placement.length = std::mem::size_of::<WINDOWPLACEMENT>() as u32;
        if GetWindowPlacement(hwnd, &mut placement).is_err() {
            return None;
        }

        let show = placement.showCmd;
        let state = if show == SW_SHOWMAXIMIZED.0 as u32 {
            WindowState::Maximized
        } else if show == SW_SHOWMINIMIZED.0 as u32 {
            WindowState::Minimized
        } else {
            WindowState::Normal
        };

        // The conversion that makes the whole thing work.
        let rc = workspace_to_screen(placement.rcNormalPosition);

        let width = rc.right - rc.left;
        let height = rc.bottom - rc.top;
        if width <= 0 || height <= 0 {
            return None;
        }

        // Pick the monitor from the restore rect's centre rather than from the
        // window handle: a minimized window reports a bogus HMONITOR, and a
        // maximized one reports the monitor it is maximized on, which is not
        // necessarily where its restore rect lives.
        let (monitor, monitor_device) = monitor_for_rect(hwnd, state, rc, monitors);

        Some(WindowGeometry {
            title: title.to_string(),
            class_name: class_name.to_string(),
            x: rc.left,
            y: rc.top,
            width,
            height,
            monitor,
            monitor_device,
            state,
            z_order,
        })
    }
}

/// Filter to windows that are meaningful to save: visible, titled, top-level,
/// application (not tool/utility, not cloaked) windows.
unsafe extern "system" fn window_enum_proc(hwnd: HWND, _lparam: LPARAM) -> BOOL {
    if is_app_window(hwnd) {
        COLLECTED_WINDOWS.with(|c| c.borrow_mut().push(hwnd));
    }
    TRUE
}

/// The one predicate used by both save and restore.
pub fn is_app_window(hwnd: HWND) -> bool {
    unsafe {
        if !IsWindowVisible(hwnd).as_bool() {
            return false;
        }

        // Only top-level windows (no owner) qualify as real app windows.
        if let Ok(owner) = GetWindow(hwnd, GW_OWNER) {
            if !owner.0.is_null() {
                return false;
            }
        }

        // Must have a non-empty title.
        if GetWindowTextLengthW(hwnd) == 0 {
            return false;
        }

        let style = GetWindowLongW(hwnd, GWL_STYLE) as u32;
        let ex_style = GetWindowLongW(hwnd, GWL_EXSTYLE) as u32;

        if (style & WS_VISIBLE.0) == 0 {
            return false;
        }
        // Tool windows (floating palettes) are not primary app windows.
        if (ex_style & WS_EX_TOOLWINDOW.0) != 0 {
            return false;
        }
        // Cloaked windows are the nasty ones: suspended UWP apps and Chrome's
        // hidden helpers report themselves as visible but are not on screen.
        // Positioning them wastes a slot that a real window needed — which is
        // how a real window ended up keeping its default size.
        if is_cloaked(hwnd) {
            return false;
        }
        true
    }
}

fn is_cloaked(hwnd: HWND) -> bool {
    let mut cloaked: u32 = 0;
    unsafe {
        let hr = DwmGetWindowAttribute(
            hwnd,
            DWMWA_CLOAKED,
            &mut cloaked as *mut u32 as *mut c_void,
            std::mem::size_of::<u32>() as u32,
        );
        hr.is_ok() && cloaked != 0
    }
}

/// Resolve the full image path of a process id.
fn process_image_path(pid: u32) -> Option<String> {
    unsafe {
        let handle = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, pid).ok()?;

        let mut buf = vec![0u16; MAX_PATH as usize];
        let mut size = buf.len() as u32;
        let ok = QueryFullProcessImageNameW(
            handle,
            PROCESS_NAME_WIN32,
            PWSTR(buf.as_mut_ptr()),
            &mut size,
        );
        let _ = windows::Win32::Foundation::CloseHandle(handle);

        if ok.is_err() || size == 0 {
            return None;
        }
        buf.truncate(size as usize);
        Some(String::from_utf16_lossy(&buf))
    }
}

fn window_title(hwnd: HWND) -> String {
    unsafe {
        let len = GetWindowTextLengthW(hwnd);
        if len <= 0 {
            return String::new();
        }
        let mut buf = vec![0u16; (len + 1) as usize];
        let read = GetWindowTextW(hwnd, &mut buf);
        buf.truncate(read as usize);
        String::from_utf16_lossy(&buf)
    }
}

fn window_class(hwnd: HWND) -> String {
    unsafe {
        let mut buf = [0u16; 256];
        let read = GetClassNameW(hwnd, &mut buf);
        if read <= 0 {
            return String::new();
        }
        String::from_utf16_lossy(&buf[..read as usize])
    }
}

/// Which saved monitor (1-based) a window primarily lives on, plus its device
/// name.
fn monitor_for_rect(
    hwnd: HWND,
    state: WindowState,
    rc: RECT,
    monitors: &[MonitorInfo],
) -> (u32, String) {
    let hmon = unsafe {
        if state == WindowState::Normal {
            MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST)
        } else {
            // Centre of the restore rect.
            MonitorFromPoint(
                windows::Win32::Foundation::POINT {
                    x: (rc.left + rc.right) / 2,
                    y: (rc.top + rc.bottom) / 2,
                },
                MONITOR_DEFAULTTONEAREST,
            )
        }
    };

    unsafe {
        let mut info = MONITORINFOEXW::default();
        info.monitorInfo.cbSize = std::mem::size_of::<MONITORINFOEXW>() as u32;
        if GetMonitorInfoW(hmon, &mut info as *mut MONITORINFOEXW as *mut MONITORINFO).as_bool() {
            let device = wide_to_string(&info.szDevice);
            if let Some(m) = monitors.iter().find(|m| m.device_id == device) {
                return (m.number, device);
            }
            let r = info.monitorInfo.rcMonitor;
            if let Some(m) = monitors.iter().find(|m| m.x == r.left && m.y == r.top) {
                return (m.number, m.device_id.clone());
            }
        }
    }

    monitors
        .iter()
        .find(|m| m.is_primary)
        .map(|m| (m.number, m.device_id.clone()))
        .unwrap_or((1, String::new()))
}

/// Executables we position but never relaunch (the desktop shell etc.).
fn is_system_shell(process_name: &str) -> bool {
    matches!(
        process_name.to_lowercase().as_str(),
        "explorer.exe" | "applicationframehost.exe" | "systemsettings.exe"
    )
}
