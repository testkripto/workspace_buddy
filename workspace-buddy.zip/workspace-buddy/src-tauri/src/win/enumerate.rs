//! Enumeration of monitors, top-level windows and their owning processes.
//!
//! All of this is read-only inspection of the current desktop using the Win32
//! API via the `windows` crate. Nothing here launches or modifies anything.

use crate::model::{AppEntry, MonitorInfo, WindowGeometry, WindowState};
use std::collections::HashMap;
use std::path::Path;

use windows::core::PWSTR;
use windows::Win32::Foundation::{BOOL, HWND, LPARAM, MAX_PATH, RECT, TRUE};
use windows::Win32::Graphics::Gdi::{
    EnumDisplayMonitors, GetMonitorInfoW, MonitorFromWindow, HDC, HMONITOR, MONITORINFO,
    MONITORINFOEXW, MONITOR_DEFAULTTONEAREST,
};
use windows::Win32::System::Threading::{
    OpenProcess, QueryFullProcessImageNameW, PROCESS_NAME_WIN32,
    PROCESS_QUERY_LIMITED_INFORMATION,
};
use windows::Win32::UI::WindowsAndMessaging::{
    EnumWindows, GetWindow, GetWindowLongW, GetWindowPlacement, GetWindowTextLengthW,
    GetWindowTextW, GetWindowThreadProcessId, IsWindowVisible, GWL_EXSTYLE, GWL_STYLE, GW_OWNER,
    SW_SHOWMAXIMIZED, SW_SHOWMINIMIZED, WINDOWPLACEMENT, WS_EX_TOOLWINDOW, WS_VISIBLE,
};

/// Raw information collected for a single window before grouping.
struct RawWindow {
    pid: u32,
    exe_path: String,
    process_name: String,
    geometry: WindowGeometry,
}

thread_local! {
    static COLLECTED_MONITORS: std::cell::RefCell<Vec<RawMonitor>> =
        std::cell::RefCell::new(Vec::new());
}

struct RawMonitor {
    rc: RECT,
    work: RECT,
    primary: bool,
}

/// Enumerate all monitors in virtual-desktop coordinates.
///
/// Monitors are numbered 1..=N ordered left-to-right then top-to-bottom so the
/// numbering is stable and human-intuitive across saves.
pub fn enumerate_monitors() -> Vec<MonitorInfo> {
    COLLECTED_MONITORS.with(|c| c.borrow_mut().clear());

    unsafe {
        // Null HDC + null clip rect => enumerate every monitor on the desktop.
        let _ = EnumDisplayMonitors(
            HDC::default(),
            None,
            Some(monitor_enum_proc),
            LPARAM(0),
        );
    }

    let mut raw: Vec<RawMonitor> =
        COLLECTED_MONITORS.with(|c| std::mem::take(&mut *c.borrow_mut()));

    // Stable ordering: by x, then y.
    raw.sort_by(|a, b| {
        (a.rc.left, a.rc.top).cmp(&(b.rc.left, b.rc.top))
    });

    raw.into_iter()
        .enumerate()
        .map(|(i, m)| MonitorInfo {
            number: (i as u32) + 1,
            is_primary: m.primary,
            x: m.rc.left,
            y: m.rc.top,
            width: m.rc.right - m.rc.left,
            height: m.rc.bottom - m.rc.top,
            work_x: m.work.left,
            work_y: m.work.top,
            work_width: m.work.right - m.work.left,
            work_height: m.work.bottom - m.work.top,
        })
        .collect()
}

unsafe extern "system" fn monitor_enum_proc(
    hmonitor: HMONITOR,
    _hdc: HDC,
    _rect: *mut RECT,
    _lparam: LPARAM,
) -> BOOL {
    let mut info = MONITORINFOEXW::default();
    info.monitorInfo.cbSize = std::mem::size_of::<MONITORINFOEXW>() as u32;

    let ok = GetMonitorInfoW(
        hmonitor,
        &mut info as *mut MONITORINFOEXW as *mut MONITORINFO,
    );
    if ok.as_bool() {
        COLLECTED_MONITORS.with(|c| {
            c.borrow_mut().push(RawMonitor {
                rc: info.monitorInfo.rcMonitor,
                work: info.monitorInfo.rcWork,
                // MONITORINFOF_PRIMARY (0x00000001) — defined inline to avoid
                // per-version differences in where the constant is exported.
                primary: (info.monitorInfo.dwFlags & 0x0000_0001) != 0,
            });
        });
    }
    TRUE
}

thread_local! {
    static COLLECTED_WINDOWS: std::cell::RefCell<Vec<HWND>> =
        std::cell::RefCell::new(Vec::new());
}

/// Enumerate application windows and group them into [`AppEntry`] records.
///
/// `monitors` is supplied so each window can be tagged with the monitor it
/// primarily sits on.
pub fn enumerate_apps(monitors: &[MonitorInfo]) -> Vec<AppEntry> {
    COLLECTED_WINDOWS.with(|c| c.borrow_mut().clear());

    unsafe {
        let _ = EnumWindows(Some(window_enum_proc), LPARAM(0));
    }

    let hwnds: Vec<HWND> =
        COLLECTED_WINDOWS.with(|c| std::mem::take(&mut *c.borrow_mut()));

    let mut raws: Vec<RawWindow> = Vec::new();
    for hwnd in hwnds {
        if let Some(raw) = inspect_window(hwnd, monitors) {
            raws.push(raw);
        }
    }

    // Group windows by executable path.
    let mut by_exe: HashMap<String, AppEntry> = HashMap::new();
    for raw in raws {
        let entry = by_exe.entry(raw.exe_path.clone()).or_insert_with(|| AppEntry {
            exe_path: raw.exe_path.clone(),
            process_name: raw.process_name.clone(),
            windows: Vec::new(),
            skip_launch: is_system_shell(&raw.process_name),
        });
        entry.windows.push(raw.geometry);
    }

    let mut apps: Vec<AppEntry> = by_exe.into_values().collect();
    apps.sort_by(|a, b| a.process_name.to_lowercase().cmp(&b.process_name.to_lowercase()));
    apps
}

/// Filter to windows that are meaningful to save: visible, titled, top-level,
/// application (not tool/utility) windows.
unsafe extern "system" fn window_enum_proc(hwnd: HWND, _lparam: LPARAM) -> BOOL {
    if !IsWindowVisible(hwnd).as_bool() {
        return TRUE;
    }

    // Only top-level windows (no owner) qualify as real app windows.
    // GetWindow returns Ok(owner) when there is one; a non-null owner means
    // this is a dialog/popup we should skip.
    if let Ok(owner) = GetWindow(hwnd, GW_OWNER) {
        if !owner.0.is_null() {
            return TRUE;
        }
    }

    // Must have a non-empty title.
    if GetWindowTextLengthW(hwnd) == 0 {
        return TRUE;
    }

    let style = GetWindowLongW(hwnd, GWL_STYLE) as u32;
    let ex_style = GetWindowLongW(hwnd, GWL_EXSTYLE) as u32;

    if (style & WS_VISIBLE.0) == 0 {
        return TRUE;
    }
    // Tool windows (floating palettes) are not primary app windows.
    if (ex_style & WS_EX_TOOLWINDOW.0) != 0 {
        return TRUE;
    }

    COLLECTED_WINDOWS.with(|c| c.borrow_mut().push(hwnd));
    TRUE
}

fn inspect_window(hwnd: HWND, monitors: &[MonitorInfo]) -> Option<RawWindow> {
    unsafe {
        // Owning process id.
        let mut pid: u32 = 0;
        GetWindowThreadProcessId(hwnd, Some(&mut pid));
        if pid == 0 {
            return None;
        }

        let exe_path = process_image_path(pid)?;
        let process_name = Path::new(&exe_path)
            .file_name()
            .map(|s| s.to_string_lossy().to_string())
            .unwrap_or_else(|| exe_path.clone());

        // Skip our own process windows.
        if process_name.eq_ignore_ascii_case("workspace-buddy.exe") {
            return None;
        }

        let title = window_title(hwnd);

        // Placement gives us both the normal rect and the show state, which is
        // more reliable than GetWindowRect for maximized windows.
        let mut placement = WINDOWPLACEMENT::default();
        placement.length = std::mem::size_of::<WINDOWPLACEMENT>() as u32;
        if GetWindowPlacement(hwnd, &mut placement).is_err() {
            return None;
        }

        let show = placement.showCmd;
        let state = if show == SW_SHOWMAXIMIZED.0 as u32 {
            WindowState::Maximized
        } else if show == SW_SHOWMINIMIZED.0 as u32 {
            WindowState::Minimized
        } else {
            WindowState::Normal
        };

        let rc = placement.rcNormalPosition;
        let geometry = WindowGeometry {
            title,
            x: rc.left,
            y: rc.top,
            width: rc.right - rc.left,
            height: rc.bottom - rc.top,
            monitor: monitor_number_for(hwnd, monitors),
            state,
        };

        Some(RawWindow {
            pid,
            exe_path,
            process_name,
            geometry,
        })
    }
}

/// Resolve the full image path of a process id.
fn process_image_path(pid: u32) -> Option<String> {
    unsafe {
        let handle = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, pid).ok()?;

        let mut buf = vec![0u16; MAX_PATH as usize];
        let mut size = buf.len() as u32;
        let ok = QueryFullProcessImageNameW(
            handle,
            PROCESS_NAME_WIN32,
            PWSTR(buf.as_mut_ptr()),
            &mut size,
        );
        let _ = windows::Win32::Foundation::CloseHandle(handle);

        if ok.is_err() || size == 0 {
            return None;
        }
        buf.truncate(size as usize);
        Some(String::from_utf16_lossy(&buf))
    }
}

fn window_title(hwnd: HWND) -> String {
    unsafe {
        let len = GetWindowTextLengthW(hwnd);
        if len <= 0 {
            return String::new();
        }
        let mut buf = vec![0u16; (len + 1) as usize];
        let read = GetWindowTextW(hwnd, &mut buf);
        buf.truncate(read as usize);
        String::from_utf16_lossy(&buf)
    }
}

/// Determine which saved monitor (1-based) a window primarily lives on.
fn monitor_number_for(hwnd: HWND, monitors: &[MonitorInfo]) -> u32 {
    unsafe {
        let hmon = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);
        let mut info = MONITORINFOEXW::default();
        info.monitorInfo.cbSize = std::mem::size_of::<MONITORINFOEXW>() as u32;
        if GetMonitorInfoW(hmon, &mut info as *mut MONITORINFOEXW as *mut MONITORINFO)
            .as_bool()
        {
            let rc = info.monitorInfo.rcMonitor;
            for m in monitors {
                if m.x == rc.left && m.y == rc.top {
                    return m.number;
                }
            }
        }
    }
    // Fall back to the primary monitor.
    monitors
        .iter()
        .find(|m| m.is_primary)
        .map(|m| m.number)
        .unwrap_or(1)
}

/// Executables we position but never relaunch (the desktop shell etc.).
fn is_system_shell(process_name: &str) -> bool {
    matches!(
        process_name.to_lowercase().as_str(),
        "explorer.exe" | "applicationframehost.exe" | "systemsettings.exe"
    )
}
