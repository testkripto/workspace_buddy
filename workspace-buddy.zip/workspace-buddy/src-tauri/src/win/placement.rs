//! Window placement engine.
//!
//! Responsibilities:
//!  * launch an executable (optionally via the shell for protocol handlers),
//!  * wait for an app's windows to appear,
//!  * decide *which* live window is *which* saved window,
//!  * move/size/maximize windows onto the correct monitor, translating
//!    coordinates when the current monitor layout differs from the saved one.

use crate::model::{MonitorInfo, WindowGeometry, WindowState};
use crate::win::enumerate::{self, LiveWindow};
use std::thread;
use std::time::{Duration, Instant};

use windows::core::HSTRING;
use windows::Win32::Foundation::{HWND, RECT};
use windows::Win32::UI::Shell::{ShellExecuteExW, SEE_MASK_NOCLOSEPROCESS, SHELLEXECUTEINFOW};
use windows::Win32::UI::WindowsAndMessaging::{
    GetWindowPlacement, GetWindowRect, IsIconic, IsZoomed, SetWindowPlacement, SetWindowPos,
    ShowWindow, HWND_TOP, SWP_NOACTIVATE, SWP_NOZORDER, SW_MINIMIZE, SW_RESTORE, SW_SHOWMAXIMIZED,
    SW_SHOWNOACTIVATE, SW_SHOWNORMAL, WINDOWPLACEMENT,
};

/// Launch an executable. Returns the OS process id when available.
///
/// Uses `ShellExecuteExW` with the "open" verb so that both `.exe` paths and
/// protocol/deep links (`msteams:`, `https:`) work through the same code path.
pub fn launch(target: &str, args: Option<&str>) -> Result<u32, String> {
    let verb = HSTRING::from("open");
    let file = HSTRING::from(target);
    let params = args.map(HSTRING::from);

    let mut info = SHELLEXECUTEINFOW {
        cbSize: std::mem::size_of::<SHELLEXECUTEINFOW>() as u32,
        fMask: SEE_MASK_NOCLOSEPROCESS,
        lpVerb: windows::core::PCWSTR(verb.as_ptr()),
        lpFile: windows::core::PCWSTR(file.as_ptr()),
        lpParameters: params
            .as_ref()
            .map(|p| windows::core::PCWSTR(p.as_ptr()))
            .unwrap_or_else(|| windows::core::PCWSTR::null()),
        nShow: SW_SHOWNORMAL.0,
        ..Default::default()
    };

    unsafe {
        ShellExecuteExW(&mut info).map_err(|e| format!("launch failed for {target}: {e}"))?;
    }

    if info.hProcess.is_invalid() {
        // Protocol handlers routed to an already-running app won't return a
        // process handle; that's fine, there's simply no new pid to report.
        return Ok(0);
    }

    let pid = unsafe { windows::Win32::System::Threading::GetProcessId(info.hProcess) };
    unsafe {
        let _ = windows::Win32::Foundation::CloseHandle(info.hProcess);
    }
    Ok(pid)
}

/// Open a URL or protocol link through the shell (Teams links, Chrome URLs).
pub fn open_link(url: &str) -> Result<(), String> {
    launch(url, None).map(|_| ())
}

/// Live windows belonging to a given executable.
///
/// Matching is on the **full path** when the saved path still exists, falling
/// back to the image name. Matching on the image name alone confused two
/// different apps that happened to ship the same filename.
pub fn find_windows_for_exe(exe_path: &str) -> Vec<LiveWindow> {
    let want_path = exe_path.to_lowercase();
    let want_name = std::path::Path::new(exe_path)
        .file_name()
        .map(|s| s.to_string_lossy().to_lowercase())
        .unwrap_or_default();

    let all = enumerate::enumerate_windows();
    let exact: Vec<LiveWindow> = all
        .iter()
        .filter(|w| w.exe_path.to_lowercase() == want_path)
        .cloned()
        .collect();
    if !exact.is_empty() {
        return exact;
    }
    all.into_iter()
        .filter(|w| w.process_name.to_lowercase() == want_name)
        .collect()
}

/// Wait until at least `want` windows for `exe_path` exist, or the timeout
/// elapses. Returns whatever was found.
///
/// Waiting for the expected *count* rather than "at least one" matters: an app
/// that restores three windows shows them one at a time, and the old code
/// grabbed the first one it saw and positioned only that.
pub fn wait_for_windows(exe_path: &str, want: usize, timeout: Duration) -> Vec<LiveWindow> {
    let deadline = Instant::now() + timeout;
    let mut best: Vec<LiveWindow> = Vec::new();

    loop {
        let found = find_windows_for_exe(exe_path);
        if found.len() > best.len() {
            best = found;
        }
        if best.len() >= want.max(1) {
            return best;
        }
        if Instant::now() >= deadline {
            return best;
        }
        thread::sleep(Duration::from_millis(200));
    }
}

// ---------------------------------------------------------------------------
// Matching saved windows to live windows
// ---------------------------------------------------------------------------

/// Pair each saved geometry with the live window it most likely belongs to.
///
/// The old implementation zipped the two lists together in enumeration order.
/// That order is z-order, which has nothing to do with the order the windows
/// were saved in — so with two Explorer windows or three Chrome windows open,
/// each one got a geometry meant for a different window. This is the single
/// biggest reason restored windows came back the wrong size.
///
/// Returns `(saved_index, live_index)` pairs. Each side is used at most once.
pub fn match_windows(saved: &[WindowGeometry], live: &[LiveWindow]) -> Vec<(usize, usize)> {
    let mut scored: Vec<(i64, usize, usize)> = Vec::new();
    for (si, s) in saved.iter().enumerate() {
        for (li, l) in live.iter().enumerate() {
            scored.push((score(s, l), si, li));
        }
    }
    // Best score first; stable tie-break on the saved order.
    scored.sort_by(|a, b| b.0.cmp(&a.0).then(a.1.cmp(&b.1)).then(a.2.cmp(&b.2)));

    let mut used_saved = vec![false; saved.len()];
    let mut used_live = vec![false; live.len()];
    let mut out = Vec::new();

    for (sc, si, li) in scored {
        if used_saved[si] || used_live[li] || sc <= 0 {
            continue;
        }
        used_saved[si] = true;
        used_live[li] = true;
        out.push((si, li));
    }

    // Anything still unmatched gets paired up in z-order, so a renamed window
    // (a document that was saved under a different name, say) still lands
    // somewhere sensible instead of being dropped.
    let mut rest_saved: Vec<usize> = (0..saved.len()).filter(|i| !used_saved[*i]).collect();
    let mut rest_live: Vec<usize> = (0..live.len()).filter(|i| !used_live[*i]).collect();
    rest_saved.sort_by_key(|i| saved[*i].z_order);
    rest_live.sort_by_key(|i| live[*i].z_order);
    for (si, li) in rest_saved.into_iter().zip(rest_live) {
        out.push((si, li));
    }

    out.sort();
    out
}

/// How confident we are that `live` is the window `saved` describes.
fn score(saved: &WindowGeometry, live: &LiveWindow) -> i64 {
    let mut s: i64 = 0;

    let st = saved.title.trim();
    let lt = live.title.trim();

    if !st.is_empty() && st == lt {
        s += 1000;
    } else if !st.is_empty() && st.eq_ignore_ascii_case(lt) {
        s += 900;
    } else if !st.is_empty() && !lt.is_empty() {
        // Titles routinely drift by a prefix or suffix: "* untitled - Editor"
        // once it has unsaved changes, "(2) Inbox - Mail" as mail arrives,
        // "Page - Google Chrome" when the tab finishes loading. Longest common
        // affix handles all of those without special-casing any app.
        let pre = common_prefix_len(st, lt) as i64;
        let suf = common_suffix_len(st, lt) as i64;
        let longest = st.chars().count().max(lt.chars().count()) as i64;
        if longest > 0 {
            s += (pre.max(suf) * 700) / longest;
        }
    }

    if !saved.class_name.is_empty() {
        if saved.class_name == live.class_name {
            s += 250;
        } else {
            // A different window class is strong evidence this is a different
            // kind of window entirely, even inside one process.
            s -= 200;
        }
    }

    // Nudge towards the window that was in a similar z-order slot.
    let dz = (saved.z_order as i64 - live.z_order as i64).abs();
    s += (20 - dz.min(20)) * 2;

    s
}

fn common_prefix_len(a: &str, b: &str) -> usize {
    a.chars().zip(b.chars()).take_while(|(x, y)| x == y).count()
}

fn common_suffix_len(a: &str, b: &str) -> usize {
    a.chars()
        .rev()
        .zip(b.chars().rev())
        .take_while(|(x, y)| x == y)
        .count()
}

// ---------------------------------------------------------------------------
// Applying geometry
// ---------------------------------------------------------------------------

/// Apply a saved geometry to a specific window handle.
///
/// `saved_monitors` are the monitors recorded at save time; `current_monitors`
/// are today's monitors.
pub fn apply_geometry(
    hwnd_raw: isize,
    geom: &WindowGeometry,
    saved_monitors: &[MonitorInfo],
    current_monitors: &[MonitorInfo],
    retries: u32,
) -> Result<(), String> {
    let hwnd = HWND(hwnd_raw as *mut _);
    let rect = translate_geometry(geom, saved_monitors, current_monitors);

    // Step 1: set the *restore* rectangle through SetWindowPlacement. This is
    // the only API that writes rcNormalPosition, so it is the only way to give
    // a maximized window the right size to un-maximize back to — and it is the
    // API whose coordinate space we saved in, so it round-trips exactly.
    // SW_SHOWNOACTIVATE keeps focus where the user left it while we work.
    unsafe {
        let mut pl = WINDOWPLACEMENT {
            length: std::mem::size_of::<WINDOWPLACEMENT>() as u32,
            ..Default::default()
        };
        // Start from the window's current placement so its own flags survive.
        let _ = GetWindowPlacement(hwnd, &mut pl);
        pl.length = std::mem::size_of::<WINDOWPLACEMENT>() as u32;
        pl.showCmd = SW_SHOWNOACTIVATE.0 as u32;
        pl.rcNormalPosition = enumerate::screen_to_workspace(rect);
        let _ = SetWindowPlacement(hwnd, &pl);

        // If the app ignored the placement call and stayed maximized or
        // minimized, SetWindowPos below would have nothing to move.
        if IsZoomed(hwnd).as_bool() || IsIconic(hwnd).as_bool() {
            let _ = ShowWindow(hwnd, SW_RESTORE);
        }
    }

    // Step 2: drive the normal rect home and check that it stuck. Electron
    // apps, Office and Chrome all resize themselves once shortly after their
    // window first appears, so a single SetWindowPos gets silently undone a
    // moment later — which is what "it restores the wrong size" looked like.
    // Verify, retry a few times, then give up quietly rather than fight.
    let want_w = rect.right - rect.left;
    let want_h = rect.bottom - rect.top;
    let attempts = retries.max(1);
    for attempt in 0..attempts {
        unsafe {
            let _ = SetWindowPos(
                hwnd,
                HWND_TOP,
                rect.left,
                rect.top,
                want_w,
                want_h,
                SWP_NOZORDER | SWP_NOACTIVATE,
            );
        }
        thread::sleep(Duration::from_millis(120));
        if rect_matches(hwnd, &rect, 4) {
            break;
        }
        if attempt + 1 < attempts {
            thread::sleep(Duration::from_millis(200));
        }
    }

    // Step 3: apply the final show state. Maximizing *after* the window is
    // sitting on the target monitor is what makes it maximize onto that
    // monitor rather than onto the primary one.
    unsafe {
        match geom.state {
            WindowState::Maximized => {
                if !IsZoomed(hwnd).as_bool() {
                    let _ = ShowWindow(hwnd, SW_SHOWMAXIMIZED);
                }
            }
            WindowState::Minimized => {
                if !IsIconic(hwnd).as_bool() {
                    let _ = ShowWindow(hwnd, SW_MINIMIZE);
                }
            }
            WindowState::Normal => {}
        }
    }

    Ok(())
}

fn rect_matches(hwnd: HWND, want: &RECT, tol: i32) -> bool {
    let mut got = RECT::default();
    unsafe {
        if GetWindowRect(hwnd, &mut got).is_err() {
            return false;
        }
    }
    (got.left - want.left).abs() <= tol
        && (got.top - want.top).abs() <= tol
        && ((got.right - got.left) - (want.right - want.left)).abs() <= tol
        && ((got.bottom - got.top) - (want.bottom - want.top)).abs() <= tol
}

/// Compute on-screen geometry, remapping across monitor layouts.
///
/// Three cases, in order of preference:
///  1. The monitor is still there, unchanged -> use the saved rectangle exactly
///     as it was. No scaling, no clamping, no "helpful" adjustment.
///  2. The monitor is there but resized -> keep the window's size, move it
///     proportionally, shrink only if it no longer fits.
///  3. The monitor is gone -> place it on the primary monitor.
///
/// Case 1 is the one that matters, and the previous version never took it: it
/// scaled and clamped every window on every restore, so windows that were
/// slightly off the work area, or spanning two monitors, came back resized.
pub fn translate_geometry(
    geom: &WindowGeometry,
    saved: &[MonitorInfo],
    current: &[MonitorInfo],
) -> RECT {
    let saved_mon = find_monitor(saved, geom);
    let current_mon = saved_mon
        .and_then(|sm| match_monitor(current, sm))
        .or_else(|| current.iter().find(|m| m.is_primary))
        .or_else(|| current.first());

    let (Some(sm), Some(cm)) = (saved_mon, current_mon) else {
        // No monitor metadata at all: trust the saved coordinates.
        return rect_of(geom.x, geom.y, geom.width, geom.height);
    };

    // Case 1: nothing moved. Verbatim.
    if sm.same_as(cm) {
        return rect_of(geom.x, geom.y, geom.width, geom.height);
    }

    // Cases 2 and 3: keep the window's size (a 1200px-wide editor should stay
    // 1200px wide on a bigger screen, not be stretched to 2400), move it
    // proportionally, and only shrink when it genuinely does not fit.
    let rel_x = geom.x - sm.x;
    let rel_y = geom.y - sm.y;
    let fx = if sm.width > 0 {
        rel_x as f64 / sm.width as f64
    } else {
        0.0
    };
    let fy = if sm.height > 0 {
        rel_y as f64 / sm.height as f64
    } else {
        0.0
    };

    // Different DPI on the new monitor: physical pixels for the same logical
    // size differ, so scale the size by the DPI ratio, not by the resolution
    // ratio.
    let dpi_scale = if sm.dpi > 0 {
        cm.dpi as f64 / sm.dpi as f64
    } else {
        1.0
    };

    let mut w = ((geom.width as f64) * dpi_scale).round() as i32;
    let mut h = ((geom.height as f64) * dpi_scale).round() as i32;
    w = w.clamp(200.min(cm.width), cm.width);
    h = h.clamp(150.min(cm.height), cm.height);

    let mut x = cm.x + (fx * cm.width as f64).round() as i32;
    let mut y = cm.y + (fy * cm.height as f64).round() as i32;
    x = x.clamp(cm.x, cm.x + cm.width - w);
    y = y.clamp(cm.y, cm.y + cm.height - h);

    rect_of(x, y, w, h)
}

fn rect_of(x: i32, y: i32, w: i32, h: i32) -> RECT {
    RECT {
        left: x,
        top: y,
        right: x + w.max(1),
        bottom: y + h.max(1),
    }
}

fn find_monitor<'a>(monitors: &'a [MonitorInfo], geom: &WindowGeometry) -> Option<&'a MonitorInfo> {
    if !geom.monitor_device.is_empty() {
        if let Some(m) = monitors
            .iter()
            .find(|m| m.device_id == geom.monitor_device)
        {
            return Some(m);
        }
    }
    monitors.iter().find(|m| m.number == geom.monitor)
}

/// Find today's monitor corresponding to a saved one: by device name first,
/// then by identical bounds, then by index.
fn match_monitor<'a>(current: &'a [MonitorInfo], saved: &MonitorInfo) -> Option<&'a MonitorInfo> {
    if !saved.device_id.is_empty() {
        if let Some(m) = current.iter().find(|m| m.device_id == saved.device_id) {
            return Some(m);
        }
    }
    if let Some(m) = current.iter().find(|m| m.same_as(saved)) {
        return Some(m);
    }
    current.iter().find(|m| m.number == saved.number)
}
