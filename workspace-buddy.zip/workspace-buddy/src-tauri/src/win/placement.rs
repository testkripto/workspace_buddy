//! Window placement engine.
//!
//! Responsibilities:
//!  * launch an executable (optionally via the shell for protocol handlers),
//!  * wait for its main window to appear,
//!  * move/size/maximize windows onto the correct monitor, translating
//!    coordinates when the current monitor layout differs from the saved one.

use crate::model::{MonitorInfo, WindowGeometry, WindowState};
use std::path::Path;
use std::thread;
use std::time::{Duration, Instant};

use windows::core::{HSTRING, PWSTR};
use windows::Win32::Foundation::{BOOL, HWND, LPARAM, MAX_PATH, TRUE};
use windows::Win32::System::Threading::{
    OpenProcess, QueryFullProcessImageNameW, PROCESS_NAME_WIN32,
    PROCESS_QUERY_LIMITED_INFORMATION,
};
use windows::Win32::UI::Shell::{ShellExecuteExW, SEE_MASK_NOCLOSEPROCESS, SHELLEXECUTEINFOW};
use windows::Win32::UI::WindowsAndMessaging::{
    EnumWindows, GetWindowThreadProcessId, IsWindowVisible, SetForegroundWindow, SetWindowPos,
    ShowWindow, HWND_TOP, SWP_NOACTIVATE, SWP_NOZORDER, SW_MINIMIZE, SW_RESTORE, SW_SHOWMAXIMIZED,
    SW_SHOWNORMAL,
};

/// Launch an executable. Returns the OS process id when available.
///
/// Uses `ShellExecuteExW` with the "open" verb so that both `.exe` paths and
/// protocol/deep links (`msteams:`, `https:`) work through the same code path.
pub fn launch(target: &str, args: Option<&str>) -> Result<u32, String> {
    let verb = HSTRING::from("open");
    let file = HSTRING::from(target);
    let params = args.map(HSTRING::from);

    let mut info = SHELLEXECUTEINFOW {
        cbSize: std::mem::size_of::<SHELLEXECUTEINFOW>() as u32,
        fMask: SEE_MASK_NOCLOSEPROCESS,
        lpVerb: windows::core::PCWSTR(verb.as_ptr()),
        lpFile: windows::core::PCWSTR(file.as_ptr()),
        lpParameters: params
            .as_ref()
            .map(|p| windows::core::PCWSTR(p.as_ptr()))
            .unwrap_or_else(|| windows::core::PCWSTR::null()),
        nShow: SW_SHOWNORMAL.0,
        ..Default::default()
    };

    unsafe {
        ShellExecuteExW(&mut info).map_err(|e| format!("launch failed for {target}: {e}"))?;
    }

    if info.hProcess.is_invalid() {
        // Protocol handlers routed to an already-running app won't return a
        // process handle; that's fine, there's simply no new pid to report.
        return Ok(0);
    }

    let pid = unsafe { windows::Win32::System::Threading::GetProcessId(info.hProcess) };
    unsafe {
        let _ = windows::Win32::Foundation::CloseHandle(info.hProcess);
    }
    Ok(pid)
}

/// Open a URL or protocol link through the shell (Teams links, Chrome URLs).
pub fn open_link(url: &str) -> Result<(), String> {
    launch(url, None).map(|_| ())
}

thread_local! {
    static FOUND: std::cell::RefCell<Vec<HWND>> = std::cell::RefCell::new(Vec::new());
    static MATCH_EXE: std::cell::RefCell<String> = std::cell::RefCell::new(String::new());
}

/// Wait until at least one visible top-level window belonging to `exe_path`
/// exists, or the timeout elapses. Returns the matching window handles.
///
/// Matching by executable path (rather than a single pid) handles multi-process
/// apps such as Electron-based editors where the visible window may belong to a
/// child process that shares the same image name.
pub fn wait_for_windows(exe_path: &str, timeout: Duration) -> Vec<isize> {
    let deadline = Instant::now() + timeout;
    let target_name = Path::new(exe_path)
        .file_name()
        .map(|s| s.to_string_lossy().to_lowercase())
        .unwrap_or_default();

    loop {
        let found = find_windows_for_exe(&target_name);
        if !found.is_empty() {
            return found.into_iter().map(|h| h.0 as isize).collect();
        }
        if Instant::now() >= deadline {
            return Vec::new();
        }
        thread::sleep(Duration::from_millis(250));
    }
}

fn find_windows_for_exe(exe_name_lower: &str) -> Vec<HWND> {
    FOUND.with(|f| f.borrow_mut().clear());
    MATCH_EXE.with(|m| *m.borrow_mut() = exe_name_lower.to_string());

    unsafe {
        let _ = EnumWindows(Some(match_enum_proc), LPARAM(0));
    }
    FOUND.with(|f| f.borrow().clone())
}

unsafe extern "system" fn match_enum_proc(hwnd: HWND, _lparam: LPARAM) -> BOOL {
    if !IsWindowVisible(hwnd).as_bool() {
        return TRUE;
    }
    let mut pid: u32 = 0;
    GetWindowThreadProcessId(hwnd, Some(&mut pid));
    if pid == 0 {
        return TRUE;
    }
    if let Some(name) = image_name_for_pid(pid) {
        let want = MATCH_EXE.with(|m| m.borrow().clone());
        if name == want {
            FOUND.with(|f| f.borrow_mut().push(hwnd));
        }
    }
    TRUE
}

fn image_name_for_pid(pid: u32) -> Option<String> {
    unsafe {
        let handle = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, pid).ok()?;
        let mut buf = vec![0u16; MAX_PATH as usize];
        let mut size = buf.len() as u32;
        let ok = QueryFullProcessImageNameW(
            handle,
            PROCESS_NAME_WIN32,
            PWSTR(buf.as_mut_ptr()),
            &mut size,
        );
        let _ = windows::Win32::Foundation::CloseHandle(handle);
        if ok.is_err() || size == 0 {
            return None;
        }
        buf.truncate(size as usize);
        let full = String::from_utf16_lossy(&buf);
        Path::new(&full)
            .file_name()
            .map(|s| s.to_string_lossy().to_lowercase())
    }
}

/// Apply a saved geometry to a specific window handle.
///
/// `saved_monitors` are the monitors recorded at save time; `current_monitors`
/// are today's monitors. When the target monitor still exists we translate the
/// window's offset within that monitor; otherwise we clamp onto the primary
/// monitor so nothing lands off-screen.
pub fn apply_geometry(
    hwnd_raw: isize,
    geom: &WindowGeometry,
    saved_monitors: &[MonitorInfo],
    current_monitors: &[MonitorInfo],
) -> Result<(), String> {
    let hwnd = HWND(hwnd_raw as *mut _);

    let (x, y, w, h, target) =
        translate_geometry(geom, saved_monitors, current_monitors);

    unsafe {
        match geom.state {
            WindowState::Minimized => {
                let _ = ShowWindow(hwnd, SW_MINIMIZE);
            }
            WindowState::Maximized => {
                // Position the restored rect on the correct monitor first, then
                // maximize so the OS maximizes onto that monitor.
                let _ = ShowWindow(hwnd, SW_RESTORE);
                let _ = SetWindowPos(
                    hwnd,
                    HWND_TOP,
                    x,
                    y,
                    w,
                    h,
                    SWP_NOZORDER | SWP_NOACTIVATE,
                );
                let _ = ShowWindow(hwnd, SW_SHOWMAXIMIZED);
            }
            WindowState::Normal => {
                let _ = ShowWindow(hwnd, SW_RESTORE);
                let _ = SetWindowPos(
                    hwnd,
                    HWND_TOP,
                    x,
                    y,
                    w,
                    h,
                    SWP_NOZORDER | SWP_NOACTIVATE,
                );
            }
        }
        // Bring intended foreground app forward without stealing on maximize.
        let _ = SetForegroundWindow(hwnd);
    }

    let _ = target; // reserved for future DPI-scaling refinements
    Ok(())
}

/// Compute on-screen geometry, remapping across monitor layouts.
fn translate_geometry(
    geom: &WindowGeometry,
    saved: &[MonitorInfo],
    current: &[MonitorInfo],
) -> (i32, i32, i32, i32, u32) {
    let saved_mon = saved.iter().find(|m| m.number == geom.monitor);
    let current_mon = current
        .iter()
        .find(|m| m.number == geom.monitor)
        .or_else(|| current.iter().find(|m| m.is_primary))
        .or_else(|| current.first());

    let (Some(sm), Some(cm)) = (saved_mon, current_mon) else {
        // No monitor metadata; use the raw saved coordinates.
        return (geom.x, geom.y, geom.width.max(200), geom.height.max(150), geom.monitor);
    };

    // Offset of the window within its saved monitor.
    let rel_x = geom.x - sm.x;
    let rel_y = geom.y - sm.y;

    // Scale offsets and size proportionally to resolution differences.
    let sx = cm.width as f64 / sm.width.max(1) as f64;
    let sy = cm.height as f64 / sm.height.max(1) as f64;

    let mut new_x = cm.x + (rel_x as f64 * sx).round() as i32;
    let mut new_y = cm.y + (rel_y as f64 * sy).round() as i32;
    let mut new_w = (geom.width as f64 * sx).round() as i32;
    let mut new_h = (geom.height as f64 * sy).round() as i32;

    // Keep a sane minimum size and clamp fully on-screen.
    new_w = new_w.clamp(200, cm.width);
    new_h = new_h.clamp(150, cm.height);
    new_x = new_x.clamp(cm.x, cm.x + cm.width - new_w);
    new_y = new_y.clamp(cm.y, cm.y + cm.height - new_h);

    (new_x, new_y, new_w, new_h, cm.number)
}
