//! Persistence: workspace files live as individual JSON documents under the
//! app data directory. A workspace's file name is derived from its id.

use crate::model::Workspace;
use serde::{Deserialize, Serialize};
use std::fs;
use std::path::{Path, PathBuf};

/// A lightweight summary shown in the workspace list without loading the whole
/// file into the UI.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkspaceSummary {
    pub id: String,
    pub name: String,
    pub saved_at: i64,
    pub app_count: usize,
    pub teams_count: usize,
    pub chrome_window_count: usize,
    pub monitor_count: usize,
}

/// Root directory for all persisted data, e.g.
/// `%APPDATA%\WorkspaceBuddy\workspaces`.
pub fn workspaces_dir(app_data: &Path) -> PathBuf {
    let dir = app_data.join("workspaces");
    let _ = fs::create_dir_all(&dir);
    dir
}

fn workspace_path(app_data: &Path, id: &str) -> PathBuf {
    workspaces_dir(app_data).join(format!("{id}.json"))
}

/// Save a workspace under the given id, pretty-printed for portability.
pub fn save_workspace(app_data: &Path, id: &str, ws: &Workspace) -> Result<(), String> {
    let path = workspace_path(app_data, id);
    let json = serde_json::to_string_pretty(ws).map_err(|e| e.to_string())?;
    fs::write(&path, json).map_err(|e| format!("writing {}: {e}", path.display()))
}

/// Load a workspace by id.
pub fn load_workspace(app_data: &Path, id: &str) -> Result<Workspace, String> {
    let path = workspace_path(app_data, id);
    let data = fs::read_to_string(&path).map_err(|e| format!("reading {}: {e}", path.display()))?;
    serde_json::from_str(&data).map_err(|e| format!("parsing {}: {e}", path.display()))
}

/// Delete a workspace by id.
pub fn delete_workspace(app_data: &Path, id: &str) -> Result<(), String> {
    let path = workspace_path(app_data, id);
    fs::remove_file(&path).map_err(|e| e.to_string())
}

/// List all workspaces as summaries, newest first.
pub fn list_workspaces(app_data: &Path) -> Result<Vec<WorkspaceSummary>, String> {
    let dir = workspaces_dir(app_data);
    let mut out = Vec::new();

    for entry in fs::read_dir(&dir).map_err(|e| e.to_string())? {
        let entry = entry.map_err(|e| e.to_string())?;
        let path = entry.path();
        if path.extension().and_then(|e| e.to_str()) != Some("json") {
            continue;
        }
        let id = match path.file_stem().and_then(|s| s.to_str()) {
            Some(s) => s.to_string(),
            None => continue,
        };
        if let Ok(ws) = load_workspace(app_data, &id) {
            out.push(WorkspaceSummary {
                id,
                name: ws.name,
                saved_at: ws.saved_at,
                app_count: ws.apps.len(),
                teams_count: ws.teams.len(),
                chrome_window_count: ws.chrome.windows.len(),
                monitor_count: ws.monitors.len(),
            });
        }
    }

    out.sort_by(|a, b| b.saved_at.cmp(&a.saved_at));
    Ok(out)
}

/// Export a workspace to an arbitrary path chosen by the user.
pub fn export_to(app_data: &Path, id: &str, dest: &Path) -> Result<(), String> {
    let ws = load_workspace(app_data, id)?;
    let json = serde_json::to_string_pretty(&ws).map_err(|e| e.to_string())?;
    fs::write(dest, json).map_err(|e| format!("exporting to {}: {e}", dest.display()))
}

/// Import a workspace from a file, returning the new id it was stored under.
pub fn import_from(app_data: &Path, src: &Path) -> Result<String, String> {
    let data = fs::read_to_string(src).map_err(|e| format!("reading {}: {e}", src.display()))?;
    let ws: Workspace = serde_json::from_str(&data)
        .map_err(|e| format!("{} is not a valid workspace file: {e}", src.display()))?;
    let id = new_id();
    save_workspace(app_data, &id, &ws)?;
    Ok(id)
}

/// Generate a new opaque id based on the current timestamp plus a counter, so
/// that ids sort roughly chronologically and never collide within a session.
pub fn new_id() -> String {
    use std::sync::atomic::{AtomicU32, Ordering};
    static COUNTER: AtomicU32 = AtomicU32::new(0);
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis())
        .unwrap_or(0);
    let n = COUNTER.fetch_add(1, Ordering::Relaxed);
    format!("ws_{now}_{n}")
}

/// Current time in unix milliseconds.
pub fn now_ms() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as i64)
        .unwrap_or(0)
}
