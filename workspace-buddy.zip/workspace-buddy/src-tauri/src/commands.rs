//! Tauri command layer: the typed API the React frontend calls via `invoke`.

use crate::chrome_bridge::{self, SharedBridge};
use crate::model::{TeamsLink, Workspace};
use crate::restore::{self, ContinueGate};
use crate::storage::{self, WorkspaceSummary};
use crate::win::enumerate;
use std::path::PathBuf;
use std::sync::Arc;
use tauri::{AppHandle, Manager, State};

/// App-wide state shared across commands.
pub struct AppState {
    pub app_data: PathBuf,
    pub bridge: SharedBridge,
    pub continue_gate: Arc<ContinueGate>,
}

fn app_data_dir(app: &AppHandle) -> Result<PathBuf, String> {
    app.path()
        .app_data_dir()
        .map_err(|e| format!("could not resolve app data dir: {e}"))
}

/// List all saved workspaces (summaries only).
#[tauri::command]
pub fn list_workspaces(state: State<AppState>) -> Result<Vec<WorkspaceSummary>, String> {
    storage::list_workspaces(&state.app_data)
}

/// Load a full workspace by id (used by editors and the restore screen).
#[tauri::command]
pub fn get_workspace(state: State<AppState>, id: String) -> Result<Workspace, String> {
    storage::load_workspace(&state.app_data, &id)
}

/// Capture the current desktop and save it as a new workspace.
///
/// Regular apps and monitors are read via the Win32 enumerator; Chrome data is
/// requested from the extension (best-effort, with a short timeout). Existing
/// Teams links can be carried over from a template workspace id.
#[tauri::command]
pub fn save_workspace(
    state: State<AppState>,
    name: String,
    teams: Vec<TeamsLink>,
    capture_chrome: bool,
) -> Result<WorkspaceSummary, String> {
    let monitors = enumerate::enumerate_monitors();
    let apps = enumerate::enumerate_apps(&monitors);

    let mut ws = Workspace::new(name);
    ws.saved_at = storage::now_ms();
    ws.monitors = monitors;
    ws.apps = apps;
    ws.teams = teams;

    if capture_chrome {
        if let Some(chrome) = chrome_bridge::request_capture(&state.bridge, 4000) {
            ws.chrome = chrome;
        }
    }

    let id = storage::new_id();
    storage::save_workspace(&state.app_data, &id, &ws)?;

    Ok(WorkspaceSummary {
        id,
        name: ws.name,
        saved_at: ws.saved_at,
        app_count: ws.apps.len(),
        teams_count: ws.teams.len(),
        chrome_window_count: ws.chrome.windows.len(),
        monitor_count: ws.monitors.len(),
    })
}

/// Overwrite an existing workspace's editable fields (name, teams links,
/// restore options) without recapturing the desktop.
#[tauri::command]
pub fn update_workspace_meta(
    state: State<AppState>,
    id: String,
    name: Option<String>,
    teams: Option<Vec<TeamsLink>>,
    restore_options: Option<crate::model::RestoreOptions>,
) -> Result<(), String> {
    let mut ws = storage::load_workspace(&state.app_data, &id)?;
    if let Some(n) = name {
        ws.name = n;
    }
    if let Some(t) = teams {
        ws.teams = t;
    }
    if let Some(o) = restore_options {
        ws.restore_options = o;
    }
    storage::save_workspace(&state.app_data, &id, &ws)
}

#[tauri::command]
pub fn delete_workspace(state: State<AppState>, id: String) -> Result<(), String> {
    storage::delete_workspace(&state.app_data, &id)
}

/// Kick off a full restore for the given workspace. Progress arrives on the
/// `restore://progress` event; the Teams pause is released with `teams_continue`.
#[tauri::command]
pub fn start_restore(app: AppHandle, state: State<AppState>, id: String) -> Result<(), String> {
    let ws = storage::load_workspace(&state.app_data, &id)?;
    restore::run(
        app,
        ws,
        state.bridge.clone(),
        state.continue_gate.clone(),
    );
    Ok(())
}

/// Release the Teams-login pause so restore proceeds to open Teams links.
#[tauri::command]
pub fn teams_continue(state: State<AppState>) {
    state.continue_gate.release();
}

/// Restore only the saved Chrome windows/tabs.
#[tauri::command]
pub fn restore_chrome_only(
    app: AppHandle,
    state: State<AppState>,
    id: String,
) -> Result<(), String> {
    let ws = storage::load_workspace(&state.app_data, &id)?;
    restore::restore_chrome_only(app, &ws, &state.bridge);
    Ok(())
}

/// Whether the Chrome companion extension has contacted the bridge.
#[tauri::command]
pub fn chrome_status(state: State<AppState>) -> bool {
    chrome_bridge::is_connected(&state.bridge)
}

/// The loopback port the extension should talk to (shown in Settings).
#[tauri::command]
pub fn bridge_port() -> u16 {
    chrome_bridge::BRIDGE_PORT
}

/// Export a workspace to a user-chosen file path.
#[tauri::command]
pub fn export_workspace(
    state: State<AppState>,
    id: String,
    dest_path: String,
) -> Result<(), String> {
    storage::export_to(&state.app_data, &id, &PathBuf::from(dest_path))
}

/// Import a workspace from a user-chosen file path. Returns the new id.
#[tauri::command]
pub fn import_workspace(state: State<AppState>, src_path: String) -> Result<String, String> {
    storage::import_from(&state.app_data, &PathBuf::from(src_path))
}

/// Current monitor layout, for the live preview in the UI.
#[tauri::command]
pub fn current_monitors() -> Vec<crate::model::MonitorInfo> {
    enumerate::enumerate_monitors()
}
