//! Restore orchestrator.
//!
//! Implements the required ordered sequence with configurable delays and emits
//! progress events to the frontend. The Teams login step pauses the sequence
//! until the user confirms from the UI.
//!
//! Ordering note: Chrome windows are opened by the companion extension, and the
//! Win32 positioning pass only runs **after** the extension has reported that
//! it is done. Otherwise the pass raced Chrome and positioned whichever windows
//! happened to exist at that instant — usually the wrong ones.

use crate::chrome_bridge::{self, SharedBridge};
use crate::model::{is_chrome_exe, AppEntry, RestoreOptions, Workspace};
use crate::win::{enumerate, placement};
use serde::Serialize;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::thread;
use std::time::Duration;
use tauri::{AppHandle, Emitter};

/// A progress update pushed to the frontend on the `restore://progress` event.
#[derive(Debug, Clone, Serialize)]
pub struct Progress {
    /// One of: teams, teams-links, apps, chrome, positions, done, error, paused.
    pub phase: String,
    pub message: String,
    /// 0.0 .. 1.0 overall progress.
    pub fraction: f32,
}

/// Signal used to release the Teams-login pause.
#[derive(Default)]
pub struct ContinueGate {
    flag: AtomicBool,
}

impl ContinueGate {
    pub fn new() -> Arc<Self> {
        Arc::new(Self {
            flag: AtomicBool::new(false),
        })
    }
    pub fn release(&self) {
        self.flag.store(true, Ordering::SeqCst);
    }
    fn reset(&self) {
        self.flag.store(false, Ordering::SeqCst);
    }
    fn is_released(&self) -> bool {
        self.flag.load(Ordering::SeqCst)
    }
}

fn emit(app: &AppHandle, phase: &str, message: &str, fraction: f32) {
    let _ = app.emit(
        "restore://progress",
        Progress {
            phase: phase.to_string(),
            message: message.to_string(),
            fraction,
        },
    );
}

/// Path to the Microsoft Teams executable, checked in order of likelihood for
/// the new unified Teams client, then classic. Falls back to the `msteams:`
/// protocol which the OS routes to whichever client is installed.
fn teams_launch_target() -> String {
    let candidates = [
        // New Teams (MSIX) stub in WindowsApps is not directly launchable by
        // path for all users; the protocol handler is the reliable route.
        std::env::var("LOCALAPPDATA")
            .ok()
            .map(|p| format!("{p}\\Microsoft\\Teams\\current\\Teams.exe")),
    ];
    for c in candidates.into_iter().flatten() {
        if std::path::Path::new(&c).exists() {
            return c;
        }
    }
    // Protocol handler: opens the installed Teams client.
    "msteams:".to_string()
}

/// Run the full restore on a background thread. Returns immediately; progress
/// is delivered via events. `gate` is released by the `teams_continue` command.
pub fn run(app: AppHandle, ws: Workspace, bridge: SharedBridge, gate: Arc<ContinueGate>) {
    thread::spawn(move || {
        gate.reset();
        let opts = ws.restore_options.clone();

        if ws.geometry_is_legacy() && opts.restore_positions {
            emit(
                &app,
                "positions",
                "Bu çalışma alanı eski bir sürümle kaydedilmiş; pencere \
                 konumları yaklaşık olacak. Düzeni bir kez daha kaydederseniz \
                 bundan sonra birebir geri yüklenir.",
                0.02,
            );
        }

        // 1. Launch Teams.
        if opts.launch_teams && !ws.teams.is_empty() {
            emit(&app, "teams", "Microsoft Teams başlatılıyor…", 0.05);
            let target = teams_launch_target();
            if let Err(e) = placement::launch(&target, None) {
                emit(&app, "error", &format!("Teams başlatılamadı: {e}"), 0.05);
            }

            // 2. Wait for user confirmation after login.
            emit(
                &app,
                "paused",
                "Lütfen Teams'te oturum açın, ardından Devam'a tıklayın",
                0.10,
            );
            while !gate.is_released() {
                thread::sleep(Duration::from_millis(150));
            }

            // 3. Open Teams chat/channel links.
            if opts.open_teams_links {
                thread::sleep(Duration::from_millis(opts.teams_link_delay_ms));
                let n = ws.teams.len().max(1);
                for (i, link) in ws.teams.iter().enumerate() {
                    emit(
                        &app,
                        "teams-links",
                        &format!("Teams bağlantısı açılıyor: {}", link.name),
                        0.10 + 0.12 * (i as f32 / n as f32),
                    );
                    if let Err(e) = placement::open_link(&link.url) {
                        emit(
                            &app,
                            "error",
                            &format!("{} açılamadı: {e}", link.name),
                            0.15,
                        );
                    }
                    thread::sleep(Duration::from_millis(400));
                }
            }
        }

        // Chrome is opened through the extension, not through the generic
        // launcher — otherwise we would start a second, empty Chrome next to
        // the one the extension is filling with the saved tabs, and the
        // positioning pass would then have twice as many windows as geometries.
        let chrome_via_extension = opts.restore_chrome && ws.chrome.captured;
        let (chrome_apps, plain_apps): (Vec<AppEntry>, Vec<AppEntry>) = ws
            .apps
            .iter()
            .cloned()
            .partition(|a| a.is_browser || is_chrome_exe(&a.process_name));

        // 4. Launch normal applications.
        if opts.launch_apps {
            let n = plain_apps.len().max(1);
            for (i, entry) in plain_apps.iter().enumerate() {
                emit(
                    &app,
                    "apps",
                    &format!("{} başlatılıyor", entry.process_name),
                    0.22 + 0.28 * (i as f32 / n as f32),
                );
                if !entry.skip_launch {
                    if let Err(e) = placement::launch(&entry.exe_path, None) {
                        emit(
                            &app,
                            "error",
                            &format!("{} başlatılamadı: {e}", entry.process_name),
                            0.30,
                        );
                    }
                }
                thread::sleep(Duration::from_millis(opts.app_launch_delay_ms));
            }
        }

        // 5 & 6. Chrome: make sure a Chrome is running (so its extension is
        //        alive), then hand the saved windows over and wait for it.
        if chrome_via_extension {
            restore_chrome_phase(&app, &ws, &bridge, &chrome_apps, &opts);
        }

        // 7. Restore all window positions — Chrome included, now that its
        //    windows actually exist.
        if opts.restore_positions {
            emit(&app, "positions", "Pencerelerin yerleşmesi bekleniyor…", 0.72);
            thread::sleep(Duration::from_millis(opts.position_settle_delay_ms));

            let current_monitors = enumerate::enumerate_monitors();
            let mut all: Vec<&AppEntry> = plain_apps.iter().collect();
            if chrome_via_extension || opts.launch_apps {
                all.extend(chrome_apps.iter());
            }

            let n = all.len().max(1);
            for (i, entry) in all.into_iter().enumerate() {
                position_app(&app, entry, &ws, &current_monitors, &opts);
                emit(
                    &app,
                    "positions",
                    &format!("{} yerleştirildi", entry.process_name),
                    0.72 + 0.26 * ((i + 1) as f32 / n as f32),
                );
            }
        }

        emit(&app, "done", "Çalışma alanı geri yüklendi.", 1.0);
    });
}

/// Position every saved window of one app, matching them to the live windows
/// by title and class rather than by enumeration order.
fn position_app(
    app: &AppHandle,
    entry: &AppEntry,
    ws: &Workspace,
    current_monitors: &[crate::model::MonitorInfo],
    opts: &RestoreOptions,
) {
    let live = placement::wait_for_windows(
        &entry.exe_path,
        entry.windows.len(),
        Duration::from_millis(opts.window_wait_timeout_ms),
    );
    if live.is_empty() {
        emit(
            app,
            "error",
            &format!("{} için pencere bulunamadı.", entry.process_name),
            0.8,
        );
        return;
    }

    if live.len() < entry.windows.len() {
        emit(
            app,
            "positions",
            &format!(
                "{}: {} pencere kaydedilmişti, {} tanesi açık.",
                entry.process_name,
                entry.windows.len(),
                live.len()
            ),
            0.8,
        );
    }

    for (si, li) in placement::match_windows(&entry.windows, &live) {
        let _ = placement::apply_geometry(
            live[li].hwnd,
            &entry.windows[si],
            &ws.monitors,
            current_monitors,
            opts.position_retries,
        );
    }
}

/// The Chrome half of a restore: ensure Chrome is up, hand the extension the
/// saved windows, and wait for it to finish before anyone tries to move them.
fn restore_chrome_phase(
    app: &AppHandle,
    ws: &Workspace,
    bridge: &SharedBridge,
    chrome_apps: &[AppEntry],
    opts: &RestoreOptions,
) {
    if !chrome_bridge::is_connected(bridge) {
        // The extension only runs while Chrome does. Start Chrome so it wakes
        // up; it will pick up the queued windows on its next poll.
        if let Some(entry) = chrome_apps.first() {
            emit(app, "chrome", "Chrome başlatılıyor…", 0.55);
            let _ = placement::launch(&entry.exe_path, None);
        } else {
            emit(app, "chrome", "Chrome başlatılıyor…", 0.55);
            let _ = placement::launch("chrome.exe", None);
        }
        if !chrome_bridge::wait_for_connection(bridge, 15000) {
            emit(
                app,
                "error",
                "Chrome yardımcı eklentisi yanıt vermedi — sekmeler atlandı. \
                 Eklentiyi yükleyip etkinleştirdikten sonra 'Yalnızca Chrome'u \
                 geri yükle' seçeneğini kullanabilirsiniz.",
                0.6,
            );
            return;
        }
    }

    let missing_incognito = ws.chrome.incognito_window_count() > 0
        && !chrome_bridge::connected_clients(bridge)
            .iter()
            .any(|(_, _, incog)| *incog);
    if missing_incognito {
        emit(
            app,
            "chrome",
            "Kaydedilmiş gizli pencereler var ancak eklentiye gizli modda izin \
             verilmemiş. chrome://extensions → Ayrıntılar → 'Gizli modda izin \
             ver' seçeneğini açın.",
            0.6,
        );
    }

    let targets = chrome_bridge::queue_restore(bridge, &ws.chrome);
    if targets.is_empty() {
        emit(app, "error", "Chrome eklentisi bağlı değil.", 0.6);
        return;
    }

    emit(
        app,
        "chrome",
        &format!(
            "{} Chrome penceresi ({} sekme) açılıyor…",
            ws.chrome.windows.len(),
            ws.chrome.tab_count()
        ),
        0.62,
    );

    let (opened, failed, errors) =
        chrome_bridge::await_restore_reports(bridge, &targets, opts.chrome_restore_timeout_ms);

    for e in errors.iter().take(3) {
        emit(app, "error", e, 0.68);
    }
    emit(
        app,
        "chrome",
        &format!("{opened} Chrome penceresi açıldı{}.", if failed > 0 {
            format!(", {failed} tanesi açılamadı")
        } else {
            String::new()
        }),
        0.70,
    );
}

/// Restore only the Chrome portion (useful when the extension connects after a
/// normal restore, or the user only wants tabs back).
pub fn restore_chrome_only(app: AppHandle, ws: Workspace, bridge: SharedBridge) {
    thread::spawn(move || {
        if !ws.chrome.captured {
            emit(
                &app,
                "done",
                "Bu çalışma alanında Chrome verisi yok.",
                1.0,
            );
            return;
        }
        let opts = ws.restore_options.clone();
        let chrome_apps: Vec<AppEntry> = ws
            .apps
            .iter()
            .filter(|a| a.is_browser || is_chrome_exe(&a.process_name))
            .cloned()
            .collect();

        restore_chrome_phase(&app, &ws, &bridge, &chrome_apps, &opts);

        if opts.restore_positions && !chrome_apps.is_empty() {
            thread::sleep(Duration::from_millis(opts.position_settle_delay_ms));
            let current = enumerate::enumerate_monitors();
            for entry in &chrome_apps {
                position_app(&app, entry, &ws, &current, &opts);
            }
        }

        emit(&app, "done", "Chrome geri yüklendi.", 1.0);
    });
}

/// Helper for command layer: sensible default options merged with a workspace's
/// stored ones (kept for future per-run overrides).
pub fn effective_options(ws: &Workspace) -> RestoreOptions {
    ws.restore_options.clone()
}
