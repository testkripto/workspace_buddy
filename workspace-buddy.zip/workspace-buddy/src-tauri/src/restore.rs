//! Restore orchestrator.
//!
//! Implements the required ordered sequence with configurable delays and emits
//! progress events to the frontend. The Teams login step pauses the sequence
//! until the user confirms from the UI.

use crate::chrome_bridge::{self, SharedBridge};
use crate::model::{RestoreOptions, Workspace};
use crate::win::placement;
use serde::Serialize;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::thread;
use std::time::Duration;
use tauri::{AppHandle, Emitter};

/// A progress update pushed to the frontend on the `restore://progress` event.
#[derive(Debug, Clone, Serialize)]
pub struct Progress {
    /// One of: teams, teams-links, apps, chrome, positions, done, error, paused.
    pub phase: String,
    pub message: String,
    /// 0.0 .. 1.0 overall progress.
    pub fraction: f32,
}

/// Signal used to release the Teams-login pause.
#[derive(Default)]
pub struct ContinueGate {
    flag: AtomicBool,
}

impl ContinueGate {
    pub fn new() -> Arc<Self> {
        Arc::new(Self {
            flag: AtomicBool::new(false),
        })
    }
    pub fn release(&self) {
        self.flag.store(true, Ordering::SeqCst);
    }
    fn reset(&self) {
        self.flag.store(false, Ordering::SeqCst);
    }
    fn is_released(&self) -> bool {
        self.flag.load(Ordering::SeqCst)
    }
}

fn emit(app: &AppHandle, phase: &str, message: &str, fraction: f32) {
    let _ = app.emit(
        "restore://progress",
        Progress {
            phase: phase.to_string(),
            message: message.to_string(),
            fraction,
        },
    );
}

/// Path to the Microsoft Teams executable, checked in order of likelihood for
/// the new unified Teams client, then classic. Falls back to the `msteams:`
/// protocol which the OS routes to whichever client is installed.
fn teams_launch_target() -> String {
    let candidates = [
        // New Teams (MSIX) stub in WindowsApps is not directly launchable by
        // path for all users; the protocol handler is the reliable route.
        std::env::var("LOCALAPPDATA")
            .ok()
            .map(|p| format!("{p}\\Microsoft\\Teams\\current\\Teams.exe")),
    ];
    for c in candidates.into_iter().flatten() {
        if std::path::Path::new(&c).exists() {
            return c;
        }
    }
    // Protocol handler: opens the installed Teams client.
    "msteams:".to_string()
}

/// Run the full restore on a background thread. Returns immediately; progress
/// is delivered via events. `gate` is released by the `teams_continue` command.
pub fn run(
    app: AppHandle,
    ws: Workspace,
    bridge: SharedBridge,
    gate: Arc<ContinueGate>,
) {
    thread::spawn(move || {
        gate.reset();
        let opts = &ws.restore_options;

        // 1. Launch Teams.
        if opts.launch_teams && !ws.teams.is_empty() {
            emit(&app, "teams", "Launching Microsoft Teams…", 0.05);
            let target = teams_launch_target();
            if let Err(e) = placement::launch(&target, None) {
                emit(&app, "error", &format!("Could not launch Teams: {e}"), 0.05);
            }

            // 2. Wait for user confirmation after login.
            emit(
                &app,
                "paused",
                "Please login to Teams, then click Continue",
                0.10,
            );
            // Block until the UI releases the gate.
            while !gate.is_released() {
                thread::sleep(Duration::from_millis(150));
            }

            // 3. Open Teams chat/channel links.
            if opts.open_teams_links {
                thread::sleep(Duration::from_millis(opts.teams_link_delay_ms));
                let n = ws.teams.len().max(1);
                for (i, link) in ws.teams.iter().enumerate() {
                    emit(
                        &app,
                        "teams-links",
                        &format!("Opening Teams link: {}", link.name),
                        0.10 + 0.15 * (i as f32 / n as f32),
                    );
                    if let Err(e) = placement::open_link(&link.url) {
                        emit(&app, "error", &format!("Failed to open {}: {e}", link.name), 0.15);
                    }
                    thread::sleep(Duration::from_millis(400));
                }
            }
        }

        // 4. Launch normal applications.
        let mut launched: Vec<(String, crate::model::AppEntry)> = Vec::new();
        if opts.launch_apps {
            let n = ws.apps.len().max(1);
            for (i, app_entry) in ws.apps.iter().enumerate() {
                emit(
                    &app,
                    "apps",
                    &format!("Launching {}", app_entry.process_name),
                    0.25 + 0.30 * (i as f32 / n as f32),
                );
                if !app_entry.skip_launch {
                    if let Err(e) = placement::launch(&app_entry.exe_path, None) {
                        emit(
                            &app,
                            "error",
                            &format!("Could not launch {}: {e}", app_entry.process_name),
                            0.30,
                        );
                    }
                }
                launched.push((app_entry.exe_path.clone(), app_entry.clone()));
                thread::sleep(Duration::from_millis(opts.app_launch_delay_ms));
            }
        }

        // 5 & 6. Launch Chrome profiles and restore tabs (handled by the
        //        extension). We queue the saved Chrome state; the extension
        //        polls `/pending-restore` and opens the windows/tabs itself.
        if opts.restore_chrome && ws.chrome.captured {
            if chrome_bridge::is_connected(&bridge) {
                emit(&app, "chrome", "Sending tabs to Chrome extension…", 0.60);
                chrome_bridge::queue_restore(&bridge, ws.chrome.clone());
            } else {
                emit(
                    &app,
                    "chrome",
                    "Chrome extension not connected — skipping tabs. Install/enable it and try Chrome-only restore later.",
                    0.60,
                );
            }
        }

        // 7. Restore all window positions.
        if opts.restore_positions {
            emit(&app, "positions", "Waiting for windows to appear…", 0.70);
            thread::sleep(Duration::from_millis(opts.position_settle_delay_ms));

            let current_monitors = crate::win::enumerate::enumerate_monitors();
            let n = launched.len().max(1);
            for (i, (exe_path, entry)) in launched.iter().enumerate() {
                let handles = placement::wait_for_windows(
                    exe_path,
                    Duration::from_millis(opts.window_wait_timeout_ms),
                );
                // Pair saved windows to live windows by order; both lists are
                // typically length 1, and extra live windows are ignored.
                for (win_geom, hwnd) in entry.windows.iter().zip(handles.iter()) {
                    let _ = placement::apply_geometry(
                        *hwnd,
                        win_geom,
                        &ws.monitors,
                        &current_monitors,
                    );
                }
                emit(
                    &app,
                    "positions",
                    &format!("Positioned {}", entry.process_name),
                    0.70 + 0.28 * (i as f32 / n as f32),
                );
            }
        }

        emit(&app, "done", "Workspace restored.", 1.0);
    });
}

/// Restore only the Chrome portion (useful when the extension connects after a
/// normal restore, or the user only wants tabs back).
pub fn restore_chrome_only(app: AppHandle, ws: &Workspace, bridge: &SharedBridge) {
    if !ws.chrome.captured {
        emit(&app, "done", "No Chrome data saved in this workspace.", 1.0);
        return;
    }
    if !chrome_bridge::is_connected(bridge) {
        emit(&app, "error", "Chrome extension is not connected.", 0.0);
        return;
    }
    emit(&app, "chrome", "Sending tabs to Chrome extension…", 0.5);
    chrome_bridge::queue_restore(bridge, ws.chrome.clone());
    emit(&app, "done", "Sent to Chrome extension.", 1.0);
}

/// Helper for command layer: sensible default options merged with a workspace's
/// stored ones (kept for future per-run overrides).
pub fn effective_options(ws: &Workspace) -> RestoreOptions {
    ws.restore_options.clone()
}
