//! Workspace Buddy — Tauri application entry (library form).
//!
//! Saves and restores a complete Windows work environment: regular apps and
//! their window layout, Microsoft Teams deep links, and Chrome tabs (via a
//! companion extension). No credentials of any kind are ever stored.

mod chrome_bridge;
mod commands;
mod model;
mod restore;
mod storage;

#[cfg(windows)]
mod win;

use commands::AppState;
use tauri::Manager;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    // Ensure consistent physical-pixel coordinates before any window exists.
    #[cfg(windows)]
    win::init_dpi_awareness();

    let bridge = chrome_bridge::new_shared();

    // Start the loopback bridge for the Chrome extension. A bind failure is not
    // fatal — the app still works for everything except Chrome sync — so we log
    // it and continue.
    if let Err(e) = chrome_bridge::start(bridge.clone()) {
        eprintln!("[workspace-buddy] chrome bridge unavailable: {e}");
    }

    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_shell::init())
        .setup(move |app| {
            let app_data = app
                .path()
                .app_data_dir()
                .expect("app data dir must resolve");
            std::fs::create_dir_all(&app_data).ok();

            app.manage(AppState {
                app_data,
                bridge: bridge.clone(),
                continue_gate: restore::ContinueGate::new(),
            });
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            commands::list_workspaces,
            commands::get_workspace,
            commands::save_workspace,
            commands::update_workspace_meta,
            commands::delete_workspace,
            commands::start_restore,
            commands::teams_continue,
            commands::restore_chrome_only,
            commands::chrome_status,
            commands::chrome_profiles,
            commands::bridge_port,
            commands::export_workspace,
            commands::import_workspace,
            commands::current_monitors,
        ])
        .run(tauri::generate_context!())
        .expect("error while running Workspace Buddy");
}
